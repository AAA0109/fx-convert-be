default_app_config = 'daterangefilter.apps.DateRangeFilterAppConfig'
