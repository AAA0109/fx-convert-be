from typing import Tuple

import numpy as np


class PnLCalculator(object):
    @staticmethod
    def calc_realized_pnl(old_amount: float,
                          new_amount: float,
                          old_price_avg: float,
                          new_price_avg: float) -> float:
        """
        Calculate the realized PnL resulting from a change in positions
        :param old_amount: float, the old (signed) amount of the position
        :param new_amount: float, the new (signed) amount of the position
        :param old_price_avg: float, the old average rate/price (positive) at which position was obtained (same
            for a long and short position, it's either the price paid or price received)
        :param new_price_avg: float, the new average rate/price (positive) at which position was obtained (same
            for a long and short position, it's either the price paid or price received)
        :return: float, the realized PnL resulting from the change in positions
        """
        if old_amount == 0 or old_amount is None:
            # No PnL, you've either taken on a new position, or did no trading
            return 0.

        price_change = new_price_avg - old_price_avg

        if old_amount < 0:
            if new_amount < old_amount:
                return 0.  # You've increased your short position

            return -np.abs(old_amount - np.minimum(0, new_amount)) * price_change

        # CASE: Old_position > 0
        if new_amount > old_amount:
            return 0.  # You've increased your long position

        return np.abs(np.maximum(0, new_amount) - old_amount) * price_change

    @staticmethod
    def calc_total_price(old_amount: float,
                         new_amount: float,
                         old_price_avg: float,
                         new_price_avg: float) -> float:
        """
        Calculate the new "Total Price" after a change in positions (always non-zero). The total price is the total
        price at which the positions were obtained, by adding up the price*quantity for all changes in the same direction
        as the current position. Note that when some of a position is unwound, the total price will decrease

        :param old_amount: float, the old (signed) amount of the position
        :param new_amount: float, the new (signed) amount of the position
        :param old_price_avg: float, the old average rate/price (positive) at which position was obtained (same
            for a long and short position, its either the price paid or price received)
        :param new_price_avg: float, the new average rate/price (positive) at which position was obtained (same
            for a long and short position, its either the price paid or price received)
        :return: float, the new total price (always non-zero) after a change in positions
        """
        if new_amount == 0:
            return 0.

        old_total_price = abs(old_amount) * old_price_avg

        # The position has not changed.
        if old_amount == new_amount:
            return old_total_price
        # You've gone in opposite direction (so we restart the total - all the old position becomes realized PnL).
        elif np.sign(old_amount) != np.sign(new_amount):
            return new_price_avg * np.abs(new_amount)
        # We've increased the position, so we just add the cost of the new part of the position to the total cost.
        elif np.abs(old_amount) < np.abs(new_amount):
            return old_total_price + np.abs(new_amount - old_amount) * new_price_avg
        # We've decreased the position. The average price of the new amount does not change, since we are simply
        # selling part of the position. Therefore, the new total price is just a fraction of the old total price.
        else:
            return old_total_price * np.abs(new_amount / old_amount)

