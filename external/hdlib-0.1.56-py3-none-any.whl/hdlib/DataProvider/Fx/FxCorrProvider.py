from hdlib.Core.FxPairInterface import FxPairInterface
from hdlib.DateTime.Date import Date
from hdlib.DataProvider.Fx.FxCorrelations import FxCorrelations

import pandas as pd
from abc import ABC, abstractmethod
from typing import Iterable


class FxCorrProvider(ABC):
    """
    Base class for data providers that can provide spot fx correlation data.
    Note that a provider may be able to provide many types of data, but to qualify as an FxCorrProvider,
    it must simply implement this interface
    """

    @abstractmethod
    def fx_correlations(self, date: Date, fx_pairs: Iterable[FxPairInterface] = None) -> FxCorrelations:
        """
        Get Fx Spot rate on a given date
        :param date: Date, the date to observe the spot
        :param fx_pairs: Iterable[FxPair] (optional), the fx_pairs to retrieve pairwise correlations for.
            If not supplied, retrieve all available
        :return: FxCorrelations, the requested correlations object on given date
        """
        raise NotImplementedError


class CachedFxCorrProvider(FxCorrProvider):
    def __init__(self, corrs: pd.DataFrame):
        self._corrs = corrs

    def fx_correlations(self, date: Date, fx_pairs: Iterable[FxPairInterface] = None) -> FxCorrelations:
        if fx_pairs:
            raise NotImplementedError("TODO: implement for the cached provider")

        try:
            corrs: pd.DataFrame = self._corrs.loc[date]
        except Exception:

            return FxCorrelations(ref_date=date, instant_corr=pd.DataFrame())
        corrs.index = corrs.columns
        return FxCorrelations(ref_date=date, instant_corr=corrs)
