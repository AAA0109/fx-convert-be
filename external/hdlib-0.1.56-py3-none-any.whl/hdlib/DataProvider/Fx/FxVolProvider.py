from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.DateTime.Date import Date
from hdlib.DataProvider.Fx.FxSpotVols import FxSpotVols

import pandas as pd
from abc import ABC, abstractmethod
from typing import Iterable


class FxVolProvider(ABC):
    """
    Base class for data providers that can provide spot fx volatility data.
    Note that a provider may be able to provide many types of data, but to qualify as an FxVolProvider,
    it must simply implement this interface
    """

    @abstractmethod
    def fx_spot_vol(self, date: Date, fx_pair: FxPairInterface) -> float:
        """
        Get Fx Spot vol rate on a given date
        :param date: Date, the date to observe the spot
        :param fx_pair: FxPair, the fx pair
        :return: float, the spot fx volatility
        """
        raise NotImplementedError

    def fx_spot_vols_on_date(self, date: Date, fx_pairs: Iterable[FxPairInterface]) -> FxSpotVols:
        """
        Get an FxSpotVols representation on a given date for a set of fx pairs.
        :param date: Date, the date of vol observation
        :param fx_pairs: Iterable[FxPair], the fx pairs to get
        :return: FxSpotVols, volatilties for pairs
        """
        # Note: override this method as desired for improved performance
        vols = [self.fx_spot_vol(date=date, fx_pair=fx_pair) for fx_pair in fx_pairs]
        pairs = pd.Series(index=fx_pairs, data=vols)
        return FxSpotVols(ref_date=date, vols=pairs)

    @abstractmethod
    def fx_spot_vols_in_range(self, start: Date, end: Date, fx_pair: FxPairInterface) -> pd.Series:
        """
        Get the spot Fx volatilities between a range of dates. The main method to override
        :param start: Date, the start date for spot time series (inclusive)
        :param end: Date, the end date for spot time series (inclusive)
        :param fx_pair: FxPair, the pair for the time series
        :return: pd.Series, a series of Date to values in increasing date order
        """
        raise NotImplementedError


class CachedFxVolProvider(FxVolProvider):
    def __init__(self, vols: pd.DataFrame):
        self._vols = vols

    def fx_spot_vols_full_history(self) -> pd.DataFrame:
        return self._vols

    def fx_spot_vol(self, date: Date, fx_pair: FxPairInterface) -> float:
        return self._vols.loc[date, fx_pair.name]

    def fx_spot_vols_on_date(self, date: Date, fx_pairs: Iterable[FxPairInterface] = None) -> FxSpotVols:
        # TODO: fix this
        try:
            vols: pd.Series = self._vols.loc[date]
        except Exception:
            return FxSpotVols(ref_date=date, vols={})
        if not fx_pairs:
            return FxSpotVols(ref_date=date, vols=vols)

        vols = vols[fx_pairs]
        vols.index = [str(pair) for pair in fx_pairs]
        return FxSpotVols(ref_date=date, vols=vols)

    def fx_spot_vols_in_range(self, start: Date, end: Date, fx_pair: FxPairInterface) -> pd.Series:
        raise NotImplementedError
