from abc import ABC, abstractmethod
import numpy as np

from hdlib.Instrument.CashFlow import CashFlow, CashFlows, Currency, Date
from hdlib.Universe.Universe import Universe, FxAssets, FxAsset
from hdlib.Universe.Risk.CashFlowRiskMetrics import CashFlowRiskMetrics


class CashFlowRiskEngine(ABC):
    """ Base class for CashFlow risk calculations, e.g. VaR """
    @abstractmethod
    def calc_risk_metrics(self,
                          cashflows: CashFlows,
                          domestic_currency: Currency) -> [CashFlowRiskMetrics, np.ndarray]:
        raise NotImplementedError


class CashFlowRiskEngineFactory(ABC):
    """ Base class for the factories which create a new engine tied to a given universe """
    @abstractmethod
    def make_engine(self, universe: Universe) -> CashFlowRiskEngine:
        raise NotImplementedError
