import numpy as np
import pandas as pd

from hdlib.Core.Currency import Currency
from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.Universe.FX.FxAssets import FxAssets
from hdlib.DataProvider.Fx.FxSpotVols import FxSpotVols
from hdlib.DataProvider.Fx.FxCorrelations import FxCorrelations
from hdlib.Hedge.Fx.Util.SpotFxCache import SpotFxCache, FxPairName
from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair

from typing import Optional, Union, Dict


class FxUniverse(SpotFxCache):
    def __init__(self,
                 ref_date: Date,
                 fx_assets: Optional[FxAssets] = None,
                 fx_vols: Optional[FxSpotVols] = None,
                 fx_corrs: Optional[FxCorrelations] = None):
        """
        The universe of data specific to FX. Holds Fx Assets, volatilities, correlations, etc.
        This universe also serves as a SpotFxCache
        :param ref_date: Date, date of reference for the universe
        :param fx_assets: FxAssets, all known FX assets
        :param fx_vols: FxSpotVols, the spot FX volatilities
        :param fx_corrs: FxCorrelations, the spot FX correlations between FX spots
        """
        super().__init__(ref_date=ref_date)
        self._fx_assets = fx_assets or FxAssets(ref_date)
        self._fx_vols = fx_vols or FxSpotVols(ref_date)
        self._fx_corrs = fx_corrs or FxCorrelations(ref_date)

    @property
    def ref_date(self) -> Date:
        return self._fx_assets.ref_date

    @property
    def fx_assets(self) -> FxAssets:
        return self._fx_assets

    @property
    def fx_vols(self) -> FxSpotVols:
        return self._fx_vols

    @fx_vols.setter
    def fx_vols(self, vols: FxSpotVols):
        self._fx_vols = vols

    @property
    def fx_corrs(self) -> FxCorrelations:
        return self._fx_corrs

    @fx_corrs.setter
    def fx_corrs(self, correlations: FxCorrelations):
        self._fx_corrs = correlations

    # ============================
    # SpotFxCache Methods
    # ============================

    def get_fx(self, fx_pair: Union[FxPairInterface, FxPairName], value_if_missing: float = None) -> Optional[float]:
        fx_asset = self.fx_assets.get_asset(pair=fx_pair)
        if fx_asset is not None:
            return fx_asset.spot
        # Try getting the inverse asset. I would really like to use fx_pair.make_inverse(), but the django FxPairs just
        # throw periodically with nonsense errors when you call make_inverse on them. Some error thrown from their
        # __init__ function.
        fx_asset = self.fx_assets.get_asset(pair=(fx_pair.get_quote_currency(), fx_pair.get_base_currency()))
        return 1.0 / fx_asset.spot if fx_asset else None

    def has_fx(self, fx_pair: Union[FxPairInterface, FxPairName]):
        """ Check if the spot map has a non-None entry for this spot. """
        return self.fx_assets.get_asset(name=str(fx_pair)) is not None

    # ============================
    # Other functions
    # ============================

    def get_spot_volatility(self, spot_positions: Union[pd.Series, Dict[FxPair, float]], currency: Currency) -> Optional[float]:
        vols = np.array(self._fx_vols.vols_spots(pairs=spot_positions.keys()))
        corr_matrix = self._fx_corrs.instant_fx_spot_corr_matrix(pairs=spot_positions.keys()).values

        covariance_matrix = np.zeros_like(corr_matrix)
        for i in range(len(vols)):
            for j in range(len(vols)):
                covariance_matrix[i][j] = vols[i] * corr_matrix[i][j] * vols[j]

        if isinstance(spot_positions, pd.Series):
            position_vector = spot_positions.to_numpy()
        else:
            position_vector = spot_positions.values()
        # Convert positions to equivalent currency positions.
        converted_positions = np.zeros_like(position_vector)
        for it, (fx, amount) in enumerate(zip(spot_positions.keys(), position_vector)):
            # Find the value of the position in the quote currency.
            rate = self.get_fx(fx_pair=fx)
            if rate is None:
                return None
            value = amount * rate
            # Convert the value in the quote currency to the value in the requested currency.
            value = self.convert_value(from_currency=fx.get_quote_currency(), to_currency=currency, value=value)
            converted_positions[it] = value

        return np.sqrt(float(np.dot(converted_positions.T, np.dot(covariance_matrix, converted_positions))))
