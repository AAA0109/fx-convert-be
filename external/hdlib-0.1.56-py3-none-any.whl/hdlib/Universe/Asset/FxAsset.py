from typing import Optional

from hdlib.Universe.Asset.Asset import Asset

from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair
from hdlib.TermStructures.ForwardCurve import ForwardCurve
from hdlib.Volatility.VolSurface import VolSurface


class FxAsset(Asset):
    def __init__(self,
                 fx_pair: FxPair,
                 fwd_curve: ForwardCurve,
                 vol_surface: Optional[VolSurface] = None):
        """
        FX asset, representing a currency pair, e.g. USD/EUR (ie USD->EUR, so $1 = FX Euro)
        :param fx_pair: FxPair, foreign->domestic
        :param fwd_curve: ForwardCurve, the term structure of FX forwards (time 0 is spot)
        :param vol_surface: VolSurface, the surface for this FX pair. Optional, can be set later
        """
        super(FxAsset, self).__init__(ref_date=fwd_curve.ref_date,
                                      name=fx_pair.name,
                                      currency=fx_pair.base)
        self._fx_pair = fx_pair
        self._spot = float(fwd_curve(0))  # Comes out of the call operator as a 0-dimensional array.
        self._fwd_curve = fwd_curve
        self._vol_surface: Optional[VolSurface] = vol_surface

    @property
    def fx_pair(self) -> FxPair:
        return self._fx_pair

    @property
    def spot(self) -> float:
        """ Get the spot FX rate """
        return self._spot

    @property
    def fwd_curve(self) -> ForwardCurve:
        return self._fwd_curve

    @property
    def vol_surface(self) -> Optional[VolSurface]:
        return self._vol_surface

    @vol_surface.setter
    def vol_surface(self, vol_surface: VolSurface):
        self._vol_surface = vol_surface
