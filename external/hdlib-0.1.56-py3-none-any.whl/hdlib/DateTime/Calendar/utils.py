from hdlib.DateTime.Calendar.Calendar import NullCalendar, CustomCalendar, Calendar
from hdlib.DateTime.Calendar.USCalendar import USCalendar


def get_calendar(cal_name: str) -> Calendar:
    """
    Convenience method to get a calendar from its name
    :param cal_name: str, the name of calendar (case insensitive)
    :return: Calendar, if found, else raises exception
    """
    cal_name = cal_name.upper()
    if cal_name == 'NULL':
        return NullCalendar()
    if cal_name == 'WESTERN':
        return CustomCalendar.new_western_no_holidays()
    if cal_name[:2] == "US":
        return USCalendar.from_str(cal_name)
    raise NotImplementedError(f"Unknown calendar name: {cal_name}")
