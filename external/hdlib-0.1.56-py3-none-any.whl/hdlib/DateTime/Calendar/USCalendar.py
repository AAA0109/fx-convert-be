from enum import Enum
from typing import Sequence
from abc import ABC, abstractmethod

from hdlib.DateTime.Date import Date
from hdlib.DateTime.Calendar.Calendar import Calendar, WesternCalendarImpl


class USCalendarType(Enum):
    US_SETTLEMENT = 'US_SETTLEMENT'
    US_FEDERAL_RESERVE = 'US_FEDERAL_RESERVE'
    US_NYSE = 'US_NYSE'
    US_NERC = 'US_NERC'  # North American Energy Reliability Council
    US_LIBOR_IMPACT = 'US_LIBOR_IMPACT'
    US_GOVT_BOND = 'US_GOVT_BOND'

    def __str__(self) -> str:
        return self.value


class USCalendar(Calendar):
    def __init__(self, cal_type: USCalendarType):
        self._impl: WesternCalendarImpl = self._make_impl(cal_type)

    def name(self) -> str:
        return self._impl.name()

    def is_weekend(self, weekday: int):
        return weekday == 6 or weekday == 7

    def is_business_day(self, date: Date) -> bool:
        return self._impl.is_business_day(date)

    @staticmethod
    def from_str(cal_name: str) -> 'USCalendar':
        return USCalendar(cal_type=USCalendarType(cal_name))

    def _make_impl(self, cal_type: USCalendarType) -> 'WesternCalendarImpl':
        if cal_type == USCalendarType.US_SETTLEMENT:
            return _settlement_impl
        if cal_type == USCalendarType.US_FEDERAL_RESERVE:
            return _FedReserveImpl()
        if cal_type == USCalendarType.US_NERC:
            return _NercImpl()
        if cal_type == USCalendarType.US_LIBOR_IMPACT:
            return _LiborImpactImpl()
        if cal_type == USCalendarType.US_GOVT_BOND:
            return _GovtBondImpl()
        # Do if needed: Add NYSE Calendar
        raise NotImplementedError("Calendar type not yet supported")


# ====================
# Specific US calendar implementations
# ====================

class _GovtBondImpl(WesternCalendarImpl):
    _name = str(USCalendarType.US_GOVT_BOND)

    def name(self) -> str:
        return self._name

    def _is_business_day(self, date: Date) -> bool:
        w = date.day_of_week()
        d = date.day
        m = date.month
        y = date.year

        if is_new_years(d, m, w, to_fri_if_sat=False) \
                or is_mlk(d, m, y, w) \
                or is_washington_bday(d, m, y, w) \
                or is_memorial_day(d, m, y, w) \
                or is_independence(d, m, w) \
                or is_labor_day(d, m, w) \
                or is_columbus_day(d, m, y, w) \
                or is_veterans_day_no_sat(d, m, y, w) \
                or is_thanksgiving(d, m, w) \
                or is_christmas(d, m, w):
            return False

        dd = date.timetuple().tm_yday
        em = self.easter_monday(y)
        # Good Friday (2015 was half day due to NFP report)
        if dd == em - 3 and y != 2015:
            return False

        return True


class _SettlementImpl(WesternCalendarImpl):
    _name = str(USCalendarType.US_SETTLEMENT)

    def name(self) -> str:
        return self._name

    def _is_business_day(self, date: Date) -> bool:
        w = date.day_of_week()
        d = date.day
        m = date.month
        y = date.year

        if is_new_years(d, m, w, to_fri_if_sat=True) \
                or is_mlk(d, m, y, w) \
                or is_washington_bday(d, m, y, w) \
                or is_memorial_day(d, m, y, w) \
                or is_independence(d, m, w) \
                or is_labor_day(d, m, w) \
                or is_columbus_day(d, m, y, w) \
                or is_veterans_day(d, m, y, w) \
                or is_thanksgiving(d, m, w) \
                or is_christmas(d, m, w):
            return False

        return True


_settlement_impl = _SettlementImpl()


class _LiborImpactImpl(WesternCalendarImpl):
    _name = str(USCalendarType.US_LIBOR_IMPACT)

    def name(self) -> str:
        return self._name

    def _is_business_day(self, date: Date) -> bool:
        w = date.day_of_week()
        d = date.day
        m = date.month
        y = date.year

        if ((d == 5 and w == 1) or (d == 3 and w == 5)) and m == 7 and y >= 2015:
            return True
        return _settlement_impl.is_business_day(date)


class _FedReserveImpl(WesternCalendarImpl):
    _name = str(USCalendarType.US_FEDERAL_RESERVE)

    def name(self) -> str:
        return self._name

    def _is_business_day(self, date: Date) -> bool:
        w = date.day_of_week()
        d = date.day
        m = date.month
        y = date.year

        if is_new_years(d, m, w, to_fri_if_sat=False) \
                or is_mlk(d, m, y, w) \
                or is_washington_bday(d, m, y, w) \
                or is_memorial_day(d, m, y, w) \
                or is_independence(d, m, w) \
                or is_labor_day(d, m, w) \
                or is_columbus_day(d, m, y, w) \
                or is_veterans_day_no_sat(d, m, y, w) \
                or is_thanksgiving(d, m, w) \
                or is_christmas(d, m, w):
            return False

        return True


class _NercImpl(WesternCalendarImpl):
    """ North American Energy Reliability Council """
    _name = str(USCalendarType.US_NERC)

    def name(self) -> str:
        return self._name

    def _is_business_day(self, date: Date) -> bool:
        w = date.day_of_week()
        d = date.day
        m = date.month
        y = date.year

        if is_new_years(d, m, w, to_fri_if_sat=False) \
                or is_memorial_day(d, m, y, w) \
                or is_independence(d, m, w) \
                or is_labor_day(d, m, w) \
                or is_thanksgiving(d, m, w) \
                or is_christmas(d, m, w):
            return False

        return True


# ====================
# Convenience Methods for US holidays
# ====================


def is_washington_bday(d: int, m: int, y: int, w: int) -> bool:
    if y >= 1971:
        # Third monday in February
        return m == 2 and (15 <= d <= 21) and w == 1
    # Feb 22nd, possibly adjusted
    return (d == 22 or (d == 23 and w == 1) or (d == 21 and w == 5)) and m == 2


def is_memorial_day(d: int, m: int, y: int, w: int) -> bool:
    if y >= 1971:
        # last Monday in May
        return d >= 25 and w == 1 and m == 5
    # May 30th, possibly adjusted
    return (d == 30 or (d == 31 and w == 1) or (d == 29 and w == 5)) and m == 5


def is_labor_day(d: int, m: int, w: int) -> bool:
    # first Monday in September
    return d <= 7 and w == 1 and m == 9


def is_columbus_day(d: int, m: int, y: int, w: int) -> bool:
    # second Monday in October
    return 8 <= d <= 14 and w == 1 and m == 10 and y >= 1971


def is_veterans_day(d: int, m: int, y: int, w: int) -> bool:
    if 1970 <= y <= 1978:
        # November 11th, adjusted
        return (d == 11 or (d == 12 and w == 1) or (d == 10 and w == 5)) and m == 11
    # fourth Monday in October
    return 22 <= d <= 28 and w == 1 and m == 10


def is_veterans_day_no_sat(d: int, m: int, y: int, w: int) -> bool:
    if 1970 <= y <= 1978:
        # November 11th, adjusted, but no Saturday to Friday
        return (d == 11 or (d == 12 and w == 1)) and m == 11
    # fourth Monday in October
    return 22 <= d <= 28 and w == 1 and m == 10


def is_thanksgiving(d: int, m: int, w: int) -> bool:
    # fourth Thursday in November
    return 22 <= d <= 28 and w == 4 and m == 11


def is_christmas(d: int, m: int, w: int) -> bool:
    return (d == 25 or (d == 26 and w == 1) or (d == 24 and w == 5)) and m == 12


def is_independence(d: int, m: int, w: int) -> bool:
    # Monday if Sunday or Friday if Saturday
    return (d == 4 or (d == 5 and w == 1) or (d == 3 and w == 5)) and m == 7


def is_mlk(d: int, m: int, y: int, w: int) -> bool:
    # third Monday in January
    return (15 <= d <= 21) and w == 1 and m == 1 and y >= 1983


def is_new_years(d: int, m: int, w: int, to_fri_if_sat: bool = False) -> bool:
    # to_fri_if_sat -> move it to Friday if on Saturday
    is_it = (d == 1 or (d == 2 and w == 1)) and m == 1
    if to_fri_if_sat and not is_it:
        is_it = (d == 31 and w == 5 and m == 12)
    return is_it
