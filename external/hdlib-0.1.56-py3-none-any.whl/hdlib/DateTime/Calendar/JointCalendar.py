from enum import Enum
from typing import Sequence

from hdlib.DateTime.Date import Date
from hdlib.DateTime.Calendar.Calendar import Calendar


class JoinCalendarRule(Enum):
    # Join Holidays: a date is a holiday for joint calendar if it's a holiday for ANY of the calendars
    JOIN_HOLIDAYS = 'JOIN_HOLIDAYS'

    # Join Business days: a date is a business date for joint calendar if it's a business day for ANY of the calendars
    JOIN_BUSINESSDAYS = 'JOIN_BUSINESSDAYS'


class JointCalendar(Calendar):
    def __init__(self,
                 calendars: Sequence[Calendar],
                 rule: JoinCalendarRule = JoinCalendarRule.JOIN_HOLIDAYS,
                 name: str = 'JointCalendar'):
        self._name = name
        self._calendars = calendars
        self._rule = rule

    def name(self) -> str:
        return self._name

    def is_weekend(self, weekday: int):
        if self._rule == JoinCalendarRule.JOIN_HOLIDAYS:
            for cal in self._calendars:
                if cal.is_weekend(weekday):
                    return True
            return False
        if self._rule == JoinCalendarRule.JOIN_BUSINESSDAYS:
            for cal in self._calendars:
                if cal.is_weekend(weekday):
                    return False
            return True

        raise NotImplementedError("This JoinCalendarRule has not been implemented")

    def is_business_day(self, date: Date) -> bool:
        if self._rule == JoinCalendarRule.JOIN_HOLIDAYS:
            for cal in self._calendars:
                if cal.is_holiday(date):
                    return False
            return True
        if self._rule == JoinCalendarRule.JOIN_BUSINESSDAYS:
            for cal in self._calendars:
                if cal.is_holiday(date):
                    return True
            return False

        raise NotImplementedError("This JoinCalendarRule has not been implemented")