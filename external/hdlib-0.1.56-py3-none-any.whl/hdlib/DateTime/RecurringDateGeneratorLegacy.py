from abc import abstractmethod
from typing import Optional, List

from hdlib.DateTime.DateGenerator import DateGenerator
from hdlib.DateTime.Calendar.Calendar import Calendar, RollConvention, NullCalendar
from hdlib.DateTime.Date import Date
from hdlib.DateTime.DayCounter import DayCounter_HD


class RecurringDateGeneratorLegacy(DateGenerator):
    """
    Advanced cash flow generator that can generate cashflows in many ways.

    The periodicity string can be used to specify how to generate cashflows:

    PER:(int X)   -> Repeat every X days.
    PER:(int X)_(int Y) -> Repeat every X days with offset Y. Only used if start_date is None.
        e.g. PER:7, PER:8_4

    WEEKLY:...       -> Repeat weekly on the specified weekdays
                -> Sun, Mon, Tue, Wed, Thu, Fri, Sat
        e.g. WEEKLY:Mon:Wed

    MONTH:...  -> Repeat a pattern monthly
          D_(X) -> Payment on this date of each month
          D_(X)/(roll type) -> Payment on this day of each month, rolling
                            -> roll type = PRE, FOL, MOD
          F     -> First day of the month
          F/(roll type) -> First date of the month, rolling
          L     -> Last day of the month
          L/(roll type) -> Last day of the month, rolling
          WD_(day of week)_(X) -> Payment on the X-th (day of week) of the month.
          WD_(day of week)_(X)/(roll type) -> Payment on the X-th (day of week) of the month, rolling
                            -> roll type = PRE, FOL, MOD

    ANNUALLY:... -> Repeat annually on some set of dates.
        e.g.    ANNUALLY:01.01/MOD:06.01/MOD                    -> semianually,
                ANUALLY:01.01/MOD:04.01/MOD:07.01/MOD:10.01/MOD -> quarterly
            (mm).(dd)                -> Payment on this day, e.g. 0430 for April 30th
            (mm).(dd)/(roll type)    -> Payment on this day, rolling.
    """

    class DayMaker:
        def __init__(self, calendar: Optional[Calendar], roll_convention: Optional[RollConvention] = None):
            self._calendar = calendar
            self._roll_convention = roll_convention

        @abstractmethod
        def make_days_for_month(self, first_day_of_month: Date,
                                start_date: Date, max_days: int, dc: DayCounter_HD) -> List[Date]:
            raise NotImplementedError

        def _check_and_return(self, date: Date, month: int, start_date: Date, max_days: int, dc: DayCounter_HD):
            if self._calendar is not None and self._roll_convention is not None:
                date = self._calendar.adjust(date, self._roll_convention)
            # If the date is in the correct month and not too far in the future, return in.
            if date.month == month and dc.days_between(start_date, date) <= max_days:
                return [date]
            return []

    class DayMakerNth(DayMaker):
        def __init__(self, n: int, roll_convention: Optional[RollConvention] = None,
                     calendar: Optional[Calendar] = None):
            super().__init__(calendar=calendar, roll_convention=roll_convention)
            self._n = n
            self._roll_convention = roll_convention

        def make_days_for_month(self, first_day_of_month: Date,
                                start_date: Date, max_days: int, dc: DayCounter_HD) -> List[Date]:
            date = first_day_of_month + (self._n - 1)
            return self._check_and_return(date, first_day_of_month.month, start_date, max_days, dc)

    class DayMakerLastDay(DayMaker):
        def __init__(self, roll_convention: Optional[RollConvention] = None, calendar: Optional[Calendar] = None):
            super().__init__(calendar=calendar, roll_convention=roll_convention)

        def make_days_for_month(self, first_day_of_month: Date,
                                start_date: Date, max_days: int, dc: DayCounter_HD) -> List[Date]:
            month = first_day_of_month.month
            date = first_day_of_month + 30  # No months have days > 31
            while date.month != month:
                date -= 1
            return self._check_and_return(date, month, start_date, max_days, dc)

    class DayMakerNthWeekday(DayMaker):
        def __init__(self, n: int, day_of_week: int, roll_convention: Optional[RollConvention] = None,
                     calendar: Optional[Calendar] = None):
            super().__init__(calendar=calendar, roll_convention=roll_convention)
            if day_of_week < 1 or 7 < day_of_week:
                raise RuntimeError(f"day of week must be in the range [1, 7], not {day_of_week}")
            if n < 1 or 5 < n:
                raise RuntimeError(f"n for n-th weekday of the month must be in the range [1, 5]")
            self._n = n
            self._day_of_week = day_of_week

        def make_days_for_month(self, first_day_of_month: Date,
                                start_date: Date, max_days: int, dc: DayCounter_HD) -> List[Date]:

            date = first_day_of_month
            while date.day_of_week() != self._day_of_week:
                date += 1
            # We have reached the first day of week of this type in the month.
            date += 7 * (self._n - 1)
            return self._check_and_return(date, first_day_of_month.month, start_date, max_days, dc)

    def __init__(self,
                 periodicity: str,
                 start_date: Optional[Date] = None,
                 end_date: Optional[Date] = None,
                 calendar: Calendar = NullCalendar()):
        super().__init__()
        self._periodicity = periodicity
        self._start_date = start_date
        self._end_date = end_date
        self._calendar = calendar

        segments = periodicity.split(':')
        self._periodic_type = segments[0]
        specifiers = segments[1:]

        # Do checks and extract data.
        self._data = []

        if self._periodic_type == 'PER':
            if len(specifiers) != 1:
                raise RuntimeError("periodic specifier must be one segment long")

            sg = specifiers[0].split('_')
            if self._start_date is not None and len(sg) != 1:
                raise RuntimeError("periodic specifier with displacement cannot be used with ")
            elif 2 < len(sg):
                raise RuntimeError("expect at most two integers in a periodic specifier")
            # Convert segments to data.
            for s in sg:
                self._data.append(int(s))

        elif self._periodic_type == 'WEEKLY':
            # Getting everything as a set takes care of the case that some days are specified multiple times.
            days_of_week = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            for wd in specifiers:
                if wd in days_of_week:
                    day_number = days_of_week.index(wd) + 1
                    if day_number in self._data:
                        raise RuntimeError(f"duplicate weekday '{wd}' in weekday specifier")
                    self._data.append(day_number)
                else:
                    raise RuntimeError(f"unknown weekday specifier '{wd}'")
            self._data = list(sorted(self._data))

        elif self._periodic_type == 'MONTH':
            for x in specifiers:
                if x[0] == 'D':
                    sg = x.split('/')
                    if len(sg) == 1:
                        sg = x.split('_')
                        assert (len(sg) == 2)
                        self._data.append(RecurringDateGeneratorLegacy.DayMakerNth(n=int(sg[1])))
                    elif len(sg) == 2:
                        sg, roll = sg
                        sg = x.split('_')
                        assert (len(sg) == 2)
                        self._data.append(RecurringDateGeneratorLegacy.DayMakerNth(
                            n=int(sg[1]),
                            roll_convention=self._make_roll_convention(roll),
                            calendar=self._calendar
                        ))
                    else:
                        raise RuntimeError(f"segment ill formed: {x}")
                elif x[0] == 'F':
                    # For first day of month, can just use DayMakerNth with n = 1
                    sg = x.split('/')
                    assert (len(sg) in [1, 2])
                    roll = None if len(sg) == 1 else self._make_roll_convention(sg[1])
                    self._data.append(RecurringDateGeneratorLegacy.DayMakerNth(n=1,
                                                                               roll_convention=roll,
                                                                               calendar=self._calendar))
                elif x[0] == 'L':
                    sg = x.split('/')
                    assert (len(sg) in [1, 2])
                    roll = None if len(sg) == 1 else sg[1]
                    self._data.append(RecurringDateGeneratorLegacy.DayMakerLastDay(
                        roll_convention=self._make_roll_convention(roll),
                        calendar=self._calendar))
                elif x[:2] == 'WD':
                    """
                    WD_(day of week)_(X) -> Payment on the X-th (day of week) of the month.
                    WD_(day of week)_(X)/(roll type) -> Payment on the X-th (day of week) of the month, rolling
                    """
                    sg = x.split('_')
                    assert (len(sg) == 3)
                    day = self._make_day_of_week_int(sg[1])
                    n = int(sg[2])
                    sg = sg[2].split('/')
                    assert (len(sg) == 1 or len(sg) == 2)

                    roll = self._make_roll_convention(sg[1]) if len(sg) == 2 else None
                    self._data.append(RecurringDateGeneratorLegacy.DayMakerNthWeekday(
                        n=n, day_of_week=day, roll_convention=roll, calendar=self._calendar
                    ))
        elif self._periodic_type == 'YEARLY':
            for x in specifiers:
                segs = x.split('/')
                assert (0 < len(segs) < 3)
                m, d = segs[0].split(".")
                roll = self._make_roll_convention(None if len(segs) == 1 else segs[1])
                self._data.append((int(m), int(d), roll))
        else:
            raise RuntimeError(f"unrecognized periodicity type '{self._periodic_type}'")

    def increment(self) -> Optional[Date]:
        raise NotImplementedError

    @property
    def periodicity(self) -> str:
        return self._periodicity

    @property
    def start_date(self) -> Date:
        return self._start_date

    @property
    def end_date(self) -> Optional[Date]:
        return self._start_date

    @property
    def calendar(self) -> Calendar:
        return self._calendar

    def _generate_dates(self, date: Date, max_days: Optional[int] = None,
                        include_start: bool = True, include_end: bool = True) -> List[Date]:
        dc = DayCounter_HD()

        # First, generate all dates.
        if self._periodic_type == 'PER':
            all_dates = self._generate_periodic_dates(date, max_days, dc)

        elif self._periodic_type == 'WEEKLY':
            all_dates = self._generate_weekly_cashflows(date, max_days, dc)

        elif self._periodic_type == 'MONTH':
            all_dates = self._generate_monthly_cashflows(date, max_days, dc)
        elif self._periodic_type == 'YEARLY':
            all_dates = self._generate_yearly_cashflows(date, max_days, dc)
        else:
            raise RuntimeError(f"unrecognized periodic type {self._periodic_type}")

        # Now, create cashflows from dates.
        output = []
        for pay_date in all_dates:
            if pay_date == date and not include_start:
                continue
            if pay_date == date + max_days and not include_end:
                continue
            output.append(pay_date)
        return output

    @staticmethod
    def _make_roll_convention(roll: Optional[str]) -> Optional[RollConvention]:
        """
        Create the correct roll convention from a string indicator.
        """
        if roll is None:
            return RollConvention.UNADJUSTED

        if roll == "UNADJ":
            return RollConvention.UNADJUSTED
        if roll == "FOL":
            return RollConvention.FOLLOWING
        if roll == "MODFOL":
            return RollConvention.MODIFIED_FOLLOWING
        if roll == "MODHMMF":
            return RollConvention.HALF_MONTH_MODIFIED_FOLLOWING
        if roll == "PRE":
            return RollConvention.PRECEDING
        if roll == "MODPRE":
            return RollConvention.MODIFIED_PRECEDING
        if roll == "NEAR":
            return RollConvention.NEAREST

        raise RuntimeError(f"unrecognized roll convention {roll}")

    def _get_end_days(self, date: Date, max_days: Optional[int], dc: DayCounter_HD) -> int:
        if max_days is None and self._end_date is None:
            raise RuntimeError("either max_days or self._end_date must be specified in generate_cashflows")

        if max_days is None:
            return dc.days_between(date, self._end_date)
        # -> max_days is NOT None.
        elif self._end_date is not None:
            return min(max_days, dc.days_between(date, self._end_date))
        # -> self._end_date is None.
        else:
            return max_days

    def _generate_periodic_dates(self, date: Date, max_days: Optional[int], dc: DayCounter_HD) -> List[Date]:
        all_dates = []
        repeat = self._data[0]
        # Start cashflows on a particular start date.
        if self._start_date is not None:
            days_since_start = dc.days_between(self._start_date, date)
            # Second mod is so if repeat - days_since_start == repeat, initial_wait is zero.
            initial_wait = (repeat - days_since_start % repeat) % repeat
            diff = initial_wait
            while diff <= max_days:
                next_date = self._start_date + diff
                if self._end_date is not None and self._end_date < next_date:
                    break
                all_dates.append(next_date)
                diff += repeat
        # Start cashflows relative to the input date.
        else:
            diff = self._data[1] if len(self._data) == 2 else 0
            while diff <= max_days:
                next_date = date + diff
                if self._end_date is not None and self._end_date < next_date:
                    break
                all_dates.append(next_date)
                diff += repeat
        return all_dates

    def _generate_weekly_cashflows(self, date: Date, max_days: Optional[int], dc: DayCounter_HD) -> List[Date]:
        all_dates = []

        start_date = date if self._start_date is None else max(date, self._start_date)
        end_days = self._get_end_days(date=date, max_days=max_days, dc=dc)

        for day in range(dc.days_between(date, start_date),
                         end_days + 1):  # TODO: handle inclusive / exclusive cashflows.
            dt = date + day
            day_of_week = dt.day_of_week()
            if day_of_week in self._data:
                all_dates.append(dt)

        return all_dates

    def _generate_monthly_cashflows(self, date: Date, max_days: Optional[int], dc: DayCounter_HD) -> List[Date]:
        all_dates = []

        start_date = date if self._start_date is None else max(date, self._start_date)
        end_days = self._get_end_days(date=date, max_days=max_days, dc=dc)

        # Go back to the first of the month.
        dt = date.first_day_of_month()
        while dc.days_between(start_date, dt) < end_days:
            for gen in self._data:
                all_dates += gen.make_days_for_month(first_day_of_month=dt, start_date=date, max_days=end_days, dc=dc)
            dt = dt.first_of_next_month()
        all_dates = list(set(filter(lambda x: start_date <= x, all_dates)))
        all_dates = list(sorted(all_dates))
        return all_dates

    def _generate_yearly_cashflows(self, date: Date, max_days: Optional[int], dc: DayCounter_HD) -> List[Date]:
        all_dates = []

        start_date = date if self._start_date is None else max(date, self._start_date)
        end_days = self._get_end_days(date=date, max_days=max_days, dc=dc)

        year = start_date.year
        continue_ = True
        while continue_:
            for m, d, roll in self._data:
                dt = Date.create(year=year, month=m, day=d)
                dt = self._calendar.adjust(dt, roll)
                if dc.days_between(start_date, dt) <= end_days:
                    all_dates.append(dt)
                else:
                    continue_ = False
                    break
            year += 1
        return all_dates

    def _make_day_of_week_int(self, day: str):
        days_of_week = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        return days_of_week.index(day) + 1
