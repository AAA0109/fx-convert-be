from typing import Union, Optional
import numpy as np

from hdlib.TermStructures.DiscountCurve import DiscountCurve, EmptyDiscountCurve, DiscountCurve_ConstRate
from hdlib.TermStructures.ForwardCurve import ForwardCurve
from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD, Date


class EquityForward(ForwardCurve):
    def __init__(self,
                 S0: float,
                 discount: DiscountCurve,
                 divDiscount: Optional[DiscountCurve] = None):
        """
        Equity forward curve: spot driven, deterministic forward
        :param S0: float, spot at reference time
        :param discount: DiscountCurve, e.g. OIS discounting curve to calculate NPV of cashflows
        :param divDiscount: DiscountCurve, dividend discounting curve, e.g. exp(-q*T)
        """
        super(EquityForward, self).__init__(ref_date=discount.ref_date, dc=discount.day_counter)
        self._S0 = S0
        self._discount = discount
        self._divDiscount = divDiscount or EmptyDiscountCurve(ref_date=discount.ref_date, dc=discount.day_counter)

    def spot(self) -> float:
        """ Get the spot """
        return self._S0

    @property
    def discountCurve(self) -> DiscountCurve:
        """ Access the discount curve, e.g. OIS discounting curve to calculate NPV of cashflows"""
        return self._discount

    @property
    def divDiscountCurve(self) -> DiscountCurve:
        """ Access the dividend discounting curve, e.g. exp(-q*T) """
        return self._divDiscount

    @staticmethod
    def from_rates(S0: float, r: float, q: float, ref_date: Date, dc: DayCounter = DayCounter_HD()):
        """
        Create an equity forward from constant interest rate and dividend yield (common modeling case)
        :param S0: float, spot
        :param r: float, interest rate
        :param q: float, div yield
        :param ref_date: Date, the valuation date
        :param dc: DayCounter, the day counter
        :return: EquityForward
        """
        return EquityForward(S0=S0,
                             discount=DiscountCurve_ConstRate(rate=r, ref_date=ref_date, dc=dc),
                             divDiscount=DiscountCurve_ConstRate(rate=q, ref_date=ref_date, dc=dc))

    def at_T(self, T: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        """
        Forward at time T in the future
        :param T: float or np.ndarray, time(s) in the future
        :return: float or np.ndarray, forward(s) at time(s) in the future
        """
        return self._S0 * self._divDiscount(T) / self._discount(T)
