from typing import Iterable, Optional, Dict, Tuple

import numpy as np

from hdlib.Core.FxPairInterface import FxPairInterface
from hdlib.Core.Currency import Currency


class VirtualFxPosition:
    def __init__(self,
                 fxpair: FxPairInterface,
                 amount: float,
                 ave_price: float):
        """
        Defines a FX position in terms of the amount of actual cash that the 'fx spot' corresponds to.
        :param fxpair: FxPairInterface, any object that implements this interface, e.g. FxPair
        :param amount: float, amount of the fx pair held, corresponds to amount in base currency
        :param ave_price: float, the average price to accumulate the position (always positive)
        """
        # For safety, make sure that fxpair really is some FxPairInterface object.
        if not isinstance(fxpair, FxPairInterface):
            raise ValueError("the fxpair must inherit from FxPairInterface")

        self.fxpair = fxpair
        self.base_cash = amount
        self.quote_cash = -ave_price * amount

    @property
    def average_price(self) -> float:
        """ Get the average price, which is always positive (base and quote have opposing signs)"""
        return -self.quote_cash / self.base_cash if self.base_cash != 0 else 0

    @property
    def amount(self) -> float:
        """ Amount held in the FX pair, equal to the amount of base currency cash"""
        return self.base_cash

    @property
    def is_empty(self) -> bool:
        """ Check if this is an empty holding, ie zero amount of cash """
        return self.amount == 0

    @property
    def total_price(self) -> float:
        """ Get the total price, which is always positive"""
        return abs(self.amount) * self.average_price

    def unrealized_pnl(self, current_rate: float) -> Tuple[float, Currency]:
        """
        Retrieve the unrealized PnL in the quote currency. This is the PnL that would be generated from selling
            this position, based on the difference between the current FX rate, and the average rate that was paid
        :param current_rate: float, the current FX rate corresponding to this position
        :return: [PnL, Currency], the unrealized pnl of this position at the current rate
        """
        return self.amount * current_rate - np.sign(self.amount) * self.total_price, self.fxpair.quote


class CashPositions:
    """ Stores all cash positions associated with the virtual fx pairs from some set of positions. """

    def __init__(self, cash_by_currency: Optional[Dict[Currency, float]] = None):
        # Map from Currency to amount.
        self.cash_by_currency = cash_by_currency if cash_by_currency else {}

    @staticmethod
    def from_fx_positions(positions: Iterable[VirtualFxPosition]) -> 'CashPositions':
        cash_positions = CashPositions()
        for position in positions:
            cash_positions.add_cash_from_virtual_fx(virtual_fx=position)
        return cash_positions

    def add_cash_from_single_fx_spot(self, fxpair: FxPairInterface, amount: float, ave_price: float):
        self.cash_by_currency[fxpair.base] = self.cash_by_currency.get(fxpair.base, 0) + amount
        self.cash_by_currency[fxpair.quote] = self.cash_by_currency.get(fxpair.quote, 0) - amount * np.abs(ave_price)

    def add_cash_from_virtual_fx(self, virtual_fx: VirtualFxPosition):
        self.add_cash(virtual_fx.fxpair.base, virtual_fx.base_cash)
        self.add_cash(virtual_fx.fxpair.quote, virtual_fx.quote_cash)

    def add_cash(self, currency: Currency, amount: float):
        self.cash_by_currency[currency] = self.cash_by_currency.get(currency, 0) + amount

    @property
    def empty(self):
        return len(self.cash_by_currency) == 0

    def get_currencies(self) -> Iterable[Currency]:
        return self.cash_by_currency.keys()
