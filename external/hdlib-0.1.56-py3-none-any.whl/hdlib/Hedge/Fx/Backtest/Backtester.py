from typing import Sequence, Dict, Optional, Tuple
import numpy as np
import pandas as pd
import os

from hdlib.Core.FxPair import FxPair
from hdlib.DateTime.Date import Date
from hdlib.Core.Currency import Currency
from hdlib.Hedge.Fx.Backtest.ComparativeHistory import ComparativeHistory
from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Universe.Historical.HistUniverseProvider import HistUniverseProvider
from hdlib.Hedge.Fx.Policy import Policy
from hdlib.Hedge.Fx.HedgeCostProvider import HedgeCostProvider
from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccount
from hdlib.Hedge.Fx.Backtest.Report import BTReport, BTReport_SingleRefDate
from hdlib.Hedge.Fx.Backtest.PositionHistory import PositionHistory
from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccountHistoryProvider_Cached

from hdlib.Hedge.Fx.HedgeAccount import (
    HedgeAccountSettings, HedgePositions, CashExposures_Cached
)

import logging

logger = logging.getLogger(__name__)


class Backtester(object):
    def __init__(self,
                 settings: HedgeAccountSettings,
                 policy: Policy,
                 universe_provider: HistUniverseProvider,
                 hedge_costs: HedgeCostProvider,
                 test_dir: Optional[str] = None):
        self._settings = settings
        self._domestic = settings.domestic
        self._policy = policy
        self._universe_provider = universe_provider
        self._hedge_costs = hedge_costs
        self._test_dir = test_dir

        if test_dir is not None:
            os.makedirs(test_dir, exist_ok=True)

        self._comparison: Optional[ComparativeHistory] = None

    def get_comparison(self) -> Optional[ComparativeHistory]:
        return self._comparison

    def run_stylized(self,
                     first_bt_date: Date,
                     num_dates: int,
                     cashflows: Dict[Currency, Sequence[CashFlow]],
                     horizon: Optional[int] = None,
                     stylization_ref_date: Optional[Date] = None,
                     record_history: bool = False,
                     do_plotting: bool = False) -> Tuple[BTReport, pd.Series]:
        """
        Run a stylized backtest of a set of cashflows (ie, stylizes the cashflows to be the same distance from
        each date as the are on the first_bt_date
        :param first_bt_date: Date, first date in the backtest (first date from which we run forward the cashflows)
        :param num_dates: int, number of scenarios that go into the backtest
        :param cashflows: the cashflows, organized by currency
        :param horizon: int (optional), if supplied run each hedge forward this many days from the date in the backtest,
            else the horizon is determined by the last cashflow to be paid
        :param stylization_ref_date: Date (optional), if supplied this determines the reference date for
            sytlizing the cashflows. Else, use the first_bt_date
        :param record_history: bool, if True record the history of each hedge from each starting date
        :return: BTReport
        """
        logger.info(f"Starting stylized backtest for {len(cashflows.keys())} currencies")
        report = BTReport()
        dates = list(self._universe_provider.get_n_uniform_dates(start=first_bt_date, num_dates=num_dates))
        ref_date = stylization_ref_date if stylization_ref_date else first_bt_date

        # Initialize a new comparative history.
        self._comparison = ComparativeHistory(ref_date)

        for i in range(len(dates)):
            date = dates[i]
            print(f'>> Running Backtest Date {i + 1} of {len(dates)}', end='\r')
            # logger.info(f"Running Backtest Date {i + 1} of {len(dates)}")
            stylized_cfs = self._stylize_cashflows(test_start_date=date, ref_date=ref_date, cashflows=cashflows)
            report_for_date, _ = self.run_cashflows_from_date(start_date=date, cashflows=stylized_cfs,
                                                              horizon=horizon, record_history=record_history,
                                                              do_plotting=do_plotting)
            report.add_report(report_for_date)

        logger.info(f"Ran a total of {len(dates)} backtest dates.")

        summary_metrics = self._write_stylized_report(report=report)
        return report, summary_metrics

    def run_cashflows_from_date(self,
                                start_date: Date,
                                cashflows: Dict[Currency, Sequence[CashFlow]],
                                record_history: bool = True,
                                horizon: Optional[int] = None,
                                do_plotting: bool = False) -> Tuple[BTReport_SingleRefDate, PositionHistory]:
        """
        Run evolution of a backtest.
        Runs cashflows as they are from start_date to last cashflow date
        """

        # ================================================
        #  Set up the backtest
        # ================================================

        # Initialize Cash Exposures
        cash_exposures = CashExposures_Cached(date=start_date, cashflows=cashflows, settings=self._settings)

        # Add new entry for this scenario.
        self._comparison.push_new_scenario()

        # Determine Dates for the Test (must align with actual business dates)
        end_date = min(cash_exposures.last_cashflow_date_within_horizon(),
                       self._universe_provider.get_top_date())
        if horizon:
            end_date = min(end_date, start_date + horizon)

        dates = [date for date in self._universe_provider.get_dates(start=start_date, end=end_date)]
        if dates[-1] < end_date:
            dates.append(self._universe_provider.get_next_date(dates[-1]))

        start_date = dates[0]
        end_date = dates[-1]

        if len(dates) < 2:
            raise ValueError("you must have 2 dates in your backtest")

        # Get fx pairs
        fx_pairs = cash_exposures.fx_pairs
        fx_names = [pair.name for pair in fx_pairs]

        universe = self._universe_provider.make_universe(date=start_date)
        spots = universe.fx_universe.fx_assets.get_fx_spots(pairs=fx_pairs)
        initial_cash_fx = float(np.dot(cash_exposures.net_exposures().values, spots.values))

        # Initialize Hedge account with no positions
        hedge_positions = HedgePositions(date=start_date,
                                         domestic=self._domestic,
                                         positions=pd.Series(index=fx_pairs, data=np.zeros(len(fx_pairs))))
        cash_pnl_account = CashPnLAccount(date=start_date - 1)

        # Initialize position history
        position_history = PositionHistory(fx_names=fx_names,
                                           account_name=self._settings.account_name,
                                           policy_name=self._policy.name,
                                           do_plotting=do_plotting)

        # Initialize Account history, starting with one day before we start hedging
        account_history = CashPnLAccountHistoryProvider_Cached()
        num_cashflows = 0  # Track number of cashflows received

        # ================================================
        #  Run the backtest
        # ================================================

        for date in dates:
            # Days since start
            days = Date.days_between(start=start_date, end=date)

            # Old Positions
            old_positions = hedge_positions.positions.copy()

            # 1) Refresh Universe
            universe = self._universe_provider.make_universe(date=date)

            # 2) Update Exposures
            cash_exposures.refresh(date=date)
            num_cashflows += cash_exposures.num_cashflows_since_last_bdate()

            # 3) Get new suggested positions. This updates the hedge.
            new_positions = self._policy.new_positions(positions=old_positions,
                                                       cash_exposures=cash_exposures,
                                                       universe=universe,
                                                       account_history_provider=account_history,
                                                       cost_provider=self._hedge_costs).positions

            # 4) Refresh positions
            hedge_positions.update_positions(date=date, new_positions=new_positions)

            # 5) Calculate Costs / PnL
            spots = universe.fx_universe.fx_assets.get_fx_spots(pairs=fx_pairs)
            net_exposure = cash_exposures.net_exposures()
            cash_pnl_account.update(date=date,
                                    spots=spots,
                                    positions=hedge_positions.positions,
                                    old_positions=old_positions,
                                    cash_on_date=cash_exposures.cash_received_since_last_bdate(),
                                    net_exposure=net_exposure,
                                    cost_provider=self._hedge_costs)

            # Record hedge account value and non-hedge account value.
            current_hedged_account_value = cash_pnl_account.aggregate_cash_and_future_npv
            current_unhedged_account_value = cash_pnl_account.received_and_future_cashflow_npv
            self._comparison.add_values_to_current_scenario(days=days,
                                                            unhedged_value=current_unhedged_account_value,
                                                            hedged_value=current_hedged_account_value)

            if date == end_date:
                # Unwind all positions at the end
                cash_pnl_account.unwind_positions(date=end_date, spots=spots, old_positions=new_positions,
                                                  net_exposure=net_exposure, cost_provider=self._hedge_costs)

            account_history.record_state(cash_pnl_account)

            # 6) Update History
            if record_history:
                position_history.record_positions(hedge_account=hedge_positions,
                                                  spots=spots,
                                                  net_exposures=net_exposure,
                                                  cash_pnl_account=cash_pnl_account)
        if record_history and self._test_dir is not None:
            position_history.write_history(out_dir=f'{self._test_dir}/History/{start_date.to_int()}')

        return BTReport_SingleRefDate(start_date=start_date,
                                      end_date=end_date,
                                      fx_names=fx_names,
                                      num_dates=len(dates),
                                      settings=self._settings,
                                      cash_pnl=cash_pnl_account,
                                      initial_cash_fx=initial_cash_fx,
                                      num_cashflows=num_cashflows), position_history

    def _stylize_cashflows(self,
                           test_start_date: Date,
                           ref_date: Date,
                           cashflows: Dict[Currency, Sequence[CashFlow]]) -> Dict[Currency, Sequence[CashFlow]]:

        stylized: Dict[Currency, Sequence[CashFlow]] = {}
        for currency, c_flows in cashflows.items():
            # stylized[currency] = self._stylize_cashflows_for_currency(test_start_date=test_start_date,
            #                                                           ref_date=ref_date, cashflows=c_flows)
            stylized[currency] = self._stylize_cashflows_for_currency_fixed_value(test_start_date=test_start_date,
                                                                                  ref_date=ref_date,
                                                                                  cashflows=c_flows)
        return stylized

    def _stylize_cashflows_for_currency(self,
                                        test_start_date: Date,
                                        ref_date: Date,
                                        cashflows: Sequence[CashFlow]) -> Sequence[CashFlow]:
        """ Make everything look like it did as of the ref date"""
        new_flows = []
        # dc = self._universe_provider.day_counter
        for cf in cashflows:
            # days_away = dc.days_between(start=ref_date, end=cf.pay_date)
            days_away = Date.days_between(start=ref_date, end=cf.pay_date)
            new_flows.append(CashFlow(amount=cf.amount, currency=cf.currency, pay_date=test_start_date + days_away))

        return new_flows

    def _stylize_cashflows_for_currency_fixed_value(self,
                                                    ref_date: Date,
                                                    test_start_date: Date,
                                                    cashflows: Sequence[CashFlow]):
        ref_universe = self._universe_provider.make_universe(date=ref_date)
        test_universe = self._universe_provider.make_universe(date=test_start_date)

        new_flows = []
        # dc = self._universe_provider.day_counter
        for cf in cashflows:
            fx = FxPair(base=cf.currency, quote=self._domestic)
            fx_spot_ref = ref_universe.fx_universe.fx_assets.get_fx_spot(pair=fx)
            fx_spot_test = test_universe.fx_universe.fx_assets.get_fx_spot(pair=fx)

            # Convert the cashflow to domestic on the reference date, then back to foreign on the test date.
            effective_amount = fx_spot_ref * cf.amount / fx_spot_test

            days_away = Date.days_between(start=ref_date, end=cf.pay_date)
            new_flows.append(CashFlow(amount=effective_amount,
                                      currency=cf.currency,
                                      pay_date=test_start_date + days_away))

        return new_flows

    def _write_stylized_report(self, report: BTReport) -> pd.Series:
        if self._test_dir is not None:
            self._settings.to_file(fpath=f"{self._test_dir}/settings.toml")

        # Write the summary results by backtest date
        if self._test_dir is not None:
            summary = report.to_df()
            summary.to_csv(f'{self._test_dir}/results.csv', index=False)

        # Write the overall summary metrics
        summary_metrics = report.summary_metrics()
        if self._test_dir is not None:
            summary_metrics.to_csv(f'{self._test_dir}/metrics.csv', index=True)

        return summary_metrics
