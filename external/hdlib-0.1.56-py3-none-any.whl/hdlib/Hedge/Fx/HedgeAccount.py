from abc import ABC, abstractmethod
from typing import Sequence, Dict, Optional, List, Iterable
import numpy as np
import pandas as pd
from enum import Enum
import toml
from hdlib.Core.AccountInterface import AccountInterface

from hdlib.DateTime.Date import Date
from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair
from hdlib.Instrument.CashFlow import CashFlow


class HedgeMethod(Enum):
    """ Hedge method, identifies which type of hedge is used (combined with params specific to that method) """
    NO_HEDGE = "NO_HEDGE"
    PERFECT = "PERFECT"
    MIN_VAR = "MIN_VAR"

    def __str__(self) -> str:
        return self.value


class HedgeAccountSettings(object):
    def __init__(self,
                 account: AccountInterface,
                 method: HedgeMethod,
                 margin_budget: float,
                 max_horizon: int = np.inf,
                 custom_settings: dict = None):
        """
        Hedge account settings, used to configure FX hedging
        :param account: AccountInterface, the account the hedge settings are for
        :param margin_budget: float, budget for maximum allowed daily margin in domestic currency across all FX
            holdings in hedge account
        :param max_horizon: int, maximum horizon in days to take a future cashflow into account when determining the
            hedge
        :param custom_settings: dict, custom settings used to guide the hedging algorithm (e.g. settings for MinVar)
        """
        self._account = account
        self._method = method
        self._margin_budget = margin_budget
        self._max_horizon = max_horizon
        self._custom_settings = custom_settings or {}

    def get_account(self) -> AccountInterface:
        return self._account

    @property
    def account_name(self) -> str:
        return self._account.get_name()

    @property
    def method(self) -> HedgeMethod:
        return self._method

    @property
    def margin_budget(self) -> float:
        return self._margin_budget

    @margin_budget.setter
    def margin_budget(self, new_budget: float):
        """
        Set the margin budget to a new value
        :param new_budget: float, the new margin budget
        """
        self._margin_budget = new_budget

    @property
    def domestic(self) -> Currency:
        return self._account.domestic_currency

    @property
    def max_horizon(self) -> int:
        return self._max_horizon

    @property
    def custom_settings(self) -> dict:
        return self._custom_settings

    def to_file(self, fpath: str):
        """ Write the settings to file """
        settings = self.to_dict()
        with open(fpath, 'w') as f:
            toml.dump(settings, f)

    def to_dict(self) -> dict:
        """ Dump the settings to a dictionary """
        return {"account_name": self.account_name,
                "method": str(self.method),
                "margin_budget": self.margin_budget,
                "domestic": self.domestic,
                "max_horizon": self.max_horizon,
                "custom_settings": self.custom_settings}


class HedgePositions(object):
    def __init__(self,
                 date: Date,
                 domestic: Currency,
                 positions: pd.Series,
                 ):
        """
        Represents the spot fx positions in hedge account, used to hedge currency cashflow exposure
        :param date: Date, the current date on which the positions are retrieved
        :param domestic: Currency, the domestic currency
        :param positions: pd.Series, the position in each FX pair in the hedge account
        """
        self._date = date
        self._domestic = domestic
        self._positions = positions

    @property
    def date(self) -> Date:
        return self._date

    @property
    def positions(self) -> pd.Series:
        return self._positions

    def update_positions(self,
                         date: Date,
                         new_positions: pd.Series):
        self._date = date
        self._positions = new_positions


class CashExposures(ABC):
    """ Manages cashflows, provides methods to compute exposure """

    def __init__(self,
                 date: Date,
                 settings: HedgeAccountSettings,
                 fx_pairs: List[FxPair]):
        self._date = date
        self._settings = settings
        self._fx_pairs = fx_pairs

    def __str__(self) -> str:
        return f"Exposures on {self._date}:\n{self.net_exposures()}"

    @abstractmethod
    def get_cashflows(self) -> Dict[Currency, Sequence[CashFlow]]:
        """ Get all cashflows in the range managed by the cash exposures. """
        raise NotImplementedError

    @abstractmethod
    def refresh(self, date: Date):
        """ Refresh cash exposures given a new date """
        raise NotImplementedError

    @abstractmethod
    def cash_received_since_last_bdate(self) -> pd.Series:
        """ All cashflows after the last pay date, up to and including this date (accounts for weekends) """
        raise NotImplementedError

    @abstractmethod
    def net_exposures(self, including_today=False) -> pd.Series:
        """
        Retrieve net exposures for each fx_pair (keys). This includes all zero exposures, ie, all currencies in the
        account settings are returned, with zero exposure for any that has no exposure.
        NOTE(Nate): I don't think its true that this necessarily contains zero exposures.
        """
        raise NotImplementedError

    @property
    def fx_pairs(self) -> List[FxPair]:
        return self._fx_pairs

    @property
    def settings(self) -> HedgeAccountSettings:
        return self._settings

    @property
    def date(self) -> Date:
        return self._date

    def last_cashflow_date_within_horizon(self) -> Date:
        """ Return date of last cashflow, within the max_horizon """
        raise NotImplementedError


class CashExposures_Cached(CashExposures):
    def __init__(self,
                 date: Date,
                 cashflows: Dict[Currency, Sequence[CashFlow]],
                 settings: HedgeAccountSettings,
                 ignore_domestic: bool = True
                 ):
        fx_pairs = [FxPair(base=curr, quote=settings.domestic) for curr in cashflows.keys()]
        super().__init__(date=date, settings=settings, fx_pairs=fx_pairs)
        # NOTE: assumes cashflows are sorted in ascending order of pay day
        if not ignore_domestic or settings.domestic not in cashflows:
            self._cashflows = cashflows
        else:
            self._cashflows = {currency: flows for currency, flows in cashflows.items()
                               if currency != settings.domestic}

        self._last_cash_date: Date = date  # This is refreshed with date to take into account the max_horizon

        # Net cashflow exposures to each currency (in units of that currency)
        self._net_exposures = pd.Series(index=self.fx_pairs, data=np.zeros(len(self.fx_pairs)))

        # Cashflows paid/received on current date / weekend in each currency (in units of that currency)
        self._cash_today = pd.Series(index=self.fx_pairs, data=np.zeros(len(self.fx_pairs)))
        self._cash_weekend = pd.Series(index=self.fx_pairs, data=np.zeros(len(self.fx_pairs)))
        self._num_cashflows_since_last_bdate = 0  # NOTE: today means they could have occurred over the weekend

        # Initialize for this date
        self.refresh(date=date)

    def get_cashflows(self) -> Dict[Currency, Sequence[CashFlow]]:
        return self._cashflows

    def refresh(self, date: Date):
        self._update_net_exposures(new_date=date)

    def cash_flows_since_last_date(self) -> pd.Series:
        """ Returns the cash flows in each currency that occurred since the last date """
        return self._cash_today + self._cash_weekend

    def net_exposures(self, including_today=False) -> pd.Series:
        if including_today:
            return self._net_exposures
        return self._net_exposures - self._cash_today

    def last_cashflow_date_within_horizon(self) -> Date:
        """ Return date of last cashflow, within the max_horizon """
        return self._last_cash_date

    def num_cashflows_since_last_bdate(self) -> int:
        """ Get the number of cashflows between last business date to today (so today + holidays + weekend) """
        return self._num_cashflows_since_last_bdate

    def cash_received_since_last_bdate(self) -> pd.Series:
        """ All cashflows after the last pay date, up to and including this date (accounts for weekends) """
        return self._cash_today + self._cash_weekend

    def _update_net_exposures(self, new_date: Date):
        previous_date = self._date
        self._last_cash_date = previous_date
        self._num_cashflows_since_last_bdate = 0

        for currency, flows in self._cashflows.items():
            fx_pair = FxPair(currency, self._settings.domestic)
            net_exposure = 0
            cash_on_date = 0
            cash_from_weekend = 0
            for cf in flows:
                # This cashflow is in the past
                if cf.pay_date <= previous_date:
                    continue
                # This is a cashflow that occurred since we last checked.
                if cf.pay_date <= new_date:
                    self._num_cashflows_since_last_bdate += 1
                    if cf.pay_date == new_date:
                        cash_on_date += cf.amount
                    else:
                        cash_from_weekend += cf.amount

                if cf.pay_date >= new_date and Date.days_between(new_date, cf.pay_date) <= self._settings.max_horizon:
                    # TODO: introduce discounting
                    net_exposure += cf.amount
                    if cf.pay_date > self._last_cash_date:
                        self._last_cash_date = cf.pay_date

            self._net_exposures[fx_pair] = net_exposure
            self._cash_today[fx_pair] = cash_on_date
            self._cash_weekend[fx_pair] = cash_from_weekend

        self._date = new_date
