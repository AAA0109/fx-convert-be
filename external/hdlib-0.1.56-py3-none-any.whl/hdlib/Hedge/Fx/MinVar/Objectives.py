from typing import List, Tuple, Optional

from hdlib.Hedge.Fx.MinVar.CalibratablePositions import CalibratablePositions
from hdlib.Fit.Calibrator import Calibrator, Objective
from hdlib.Hedge.Fx.MinVar.PnLRiskCalculator import PnLRiskCalculator
import numpy as np


class MinVarianceObjective(Objective):
    def __init__(self,
                 positions: CalibratablePositions,
                 pnl_risk: PnLRiskCalculator,
                 strength: float = 1.0,
                 target_reduction: float = 1.0):
        """
        Primary objective of the minimum variance optimization policy
        :param positions: CalibratablePositions, the calibratable/fittable positions, these are fitted by the
            optimizer
        :param pnl_risk: PnLRiskCalculator, the risk engine, ie the model that supplies the optimizer with metrics
            such as variance, VaR, etc given the proposed positions
        :param strength: float, the strength of this objective
        :param target_reduction: float, the targeted risk reduction, in [0, 1.]
        """
        super().__init__(strength=strength)

        self._positions = positions
        self._pnl_risk = pnl_risk

        self._target_reduction = target_reduction
        self._target_var = self._set_target_var(target_reduction, is_std_dev_target=True)

    def value(self) -> float:
        """
        The value, ie error, corresponding to this objective, which the optimizer seeks to minimize. This is
        volatility reduction target objective, so it seeks to reduce volatility to exactly the target amount
        :return: float, the value of the objective given the proposed positions
        """
        return self._strength * abs(self._pnl_risk.variance(self._positions.weights) - self._target_var)
        # Soft Absolute value (doesnt help, test more)
        # err = self.variance(self._positions.weights) - self._target_var
        # return self._strength * (np.sqrt(err**2 + 0.0001) - 0.01)  # note: we subtract np.sqrt(0.0001) = 0.01

    def _set_target_var(self, target_reduction: float, is_std_dev_target: bool) -> float:
        if target_reduction > 1 or target_reduction < 0:
            raise ValueError("Target reduction must be in [0, 1]")
        if target_reduction == 1:
            return 0  # ie, 100% reduction

        unhedged_var = self._pnl_risk.variance(self._positions.net_cash_exposures)
        if not is_std_dev_target:
            return (1 - target_reduction) * unhedged_var
        return (1 - target_reduction) ** 2 * unhedged_var


class ValueAtRiskTarget(Objective):
    def __init__(self,
                 positions: CalibratablePositions,
                 pnl_risk: PnLRiskCalculator,
                 target_VaR: float,
                 strength: float = 1.0):
        super().__init__(strength=strength)

        self._target_VaR = target_VaR

        self._positions = positions
        self._pnl_risk = pnl_risk

    def value(self) -> float:
        return self._strength * abs(self._pnl_risk.value_at_risk(self._positions.weights) - self._target_VaR)


class ValueAtRiskBound(Objective):
    def __init__(self,
                 positions: CalibratablePositions,
                 pnl_risk: PnLRiskCalculator,
                 target_VaR: float,
                 q: float = 0.95,
                 strength: float = 1.0,
                 days_scale: float = 1.0):
        super().__init__(strength=strength)

        self._q = q
        self._target_VaR = target_VaR
        self._sq_days_scale = np.sqrt(days_scale)

        self._positions = positions
        self._pnl_risk = pnl_risk

    def value(self) -> float:
        # NOTE: could do a soft max here
        val_at_risk = self._sq_days_scale * self._pnl_risk.value_at_risk(self._positions.weights, q=self._q)
        if val_at_risk > self._target_VaR:  # Very negative is bad
            return 0.
        return self._strength * abs(val_at_risk - self._target_VaR)


class RollCostPenalty(Objective):
    def __init__(self,
                 positions: CalibratablePositions,
                 costs_long: np.ndarray,
                 costs_short: np.ndarray,
                 strength: float = 1.0):
        super().__init__(strength=strength)

        self._positions = positions
        self._costs = positions.concat_long_short(longs=costs_long, shorts=costs_short)

    def value(self) -> float:
        # Note: the position params are always positive, so if costs are positive so is the value here
        return self._strength * float(np.dot(self._costs, self._positions.get_params()))


class TradingCostPenalty(Objective):
    def __init__(self,
                 positions: CalibratablePositions,
                 alphas_last: np.ndarray,
                 trans_costs: np.ndarray,
                 strength: float = 1.):
        super().__init__(strength=strength)

        self._positions = positions
        self._alphas_last = alphas_last
        self._trans_costs = trans_costs

    def value(self) -> float:
        return self._strength * float(np.dot(self._trans_costs,
                                             np.abs(self._positions.get_alphas() - self._alphas_last)))

# class EqualCoverageObjective(Objective):
#     """
#     An objective which penalizes deviations of the coverage rate away from the mean coverage...
#     """
#
#     def __init__(self,
#                  positions: CalibratablePositions,
#                  strength: float = 1.):
#         super().__init__(strength=strength)
#         self._positions = positions
#         self._trivial_thresh = 0.1  # net exposures less than this in magnitude are considered trivial
#         self._non_trivial = np.where(np.abs(self._positions.zetas) > self._trivial_thresh, 1, 0)
#         self._mean_mult = self._positions.size / np.sum(self._non_trivial)
#
#     def value(self) -> float:
#         coverage = self._positions.calc_coverage(trivial_thresh=self._trivial_thresh)
#         mean_coverage = np.mean(coverage)  # only compute mean over the ones with non-trivial exposure
#
#
#         return self._strength *
