import pandas as pd
import numpy as np

from hdlib.Fit.Minimizer import OptResult
from hdlib.Hedge.Fx.MinVar.MinVarCalibrator import MinVarCalibrator, VarReductionSummary
from hdlib.Hedge.Fx.HedgeAccount import HedgeAccountSettings
from hdlib.Hedge.Fx.HedgeCostProvider import HedgeCostProvider
from hdlib.Hedge.Fx.MinVar.PnLRiskCalculator import PnLRiskCalculator
from hdlib.Hedge.Fx.Policy import Policy, CashExposures, Universe, PolicySummary
from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccountHistoryProvider, CashPnLAccount
from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair
from typing import Iterable

# Logging.
import logging

logger = logging.getLogger(__name__)


class MinVarPolicy(Policy):
    """
    Constrained minimum variance policy, which optimizes between objective to reduce variance and balance costs
    of fx positions and trade costs, with margin constraints, etc.
    """

    def __init__(self,
                 settings: HedgeAccountSettings,
                 name: str = 'MinVar',
                 include_trade_costs: bool = False,
                 include_roll_costs: bool = True,
                 include_margin_budget: bool = True):
        super().__init__(name=name, settings=settings)

        # Number between [0,1], where 0 means they have no risk reduction, 1.0 means 100% risk reduction
        self._vol_reduction_target = self._settings.custom_settings.get('VolTargetReduction', 1.0)
        if 0 > self._vol_reduction_target or self._vol_reduction_target > 1.0:
            raise ValueError(f"VolTargetReduction must be in [0,1], reduction target was {self._vol_reduction_target}")

        # This is what percentage of the account value that they dont want their 95% VaR to exceed
        # If you supply greater than 1 or less than 0, this will not be enforced
        self._max_VaR95_exposure_percent = self._settings.custom_settings.get('VaR95ExposureRatio', 1.0)

        # The number of days we lookback when computing PnL to determine how much the account has lost/gained ...
        #  the VaR bound wont kick  in until the PnL starts to near it, at which point we will put on
        #  a position to lock in their losses
        self._max_VaR95_exposure_days = self._settings.custom_settings.get('VaR95ExposureWindow', None)
        if self._max_VaR95_exposure_days is not None and self._max_VaR95_exposure_days <= 0:
            raise ValueError("VaR95ExposureWindow must be None or greater than zero")

        # If true, trading costs are included in the objective
        self._include_trade_costs = include_trade_costs

        # If true, include roll costs in the objective
        self._include_roll_costs = include_roll_costs

        # If true, include the margin budget
        self._include_margin_budget = include_margin_budget

    def new_positions(self,
                      positions: pd.Series,
                      raw_exposures: CashExposures,
                      cash_exposures: CashExposures,
                      universe: Universe,
                      account_history_provider: CashPnLAccountHistoryProvider,
                      cost_provider: HedgeCostProvider) -> PolicySummary:
        logger.info(f"Running MinVarPolicy::new_positions.")

        if self._has_VaR_bound() and not account_history_provider:
            raise ValueError(f"there is a VaR bound, but you didnt supply account history provider")

        date = universe.ref_date

        logger.info("  >> MinVarPolicy: setting up the fx pairs to hedge")
        exposures = cash_exposures.net_exposures()

        all_pairs = set()
        for pair in positions.keys():
            all_pairs.add(FxPair.from_str(pair) if isinstance(pair, str) else pair)
        for pair in exposures.keys():
            all_pairs.add(FxPair.from_str(pair) if isinstance(pair, str) else pair)
        all_pairs = list(all_pairs)

        # Any pairs that are in the positions but not in the exposures, we will assume they have zero exposure.
        exposures = self._align_exposures(all_pairs=all_pairs, exposures=exposures)
        raw_exposures = self._align_exposures(all_pairs=all_pairs, exposures=raw_exposures.net_exposures())

        net_future_cashflows = pd.Series(0., index=all_pairs)
        for key, val in exposures.items():
            net_future_cashflows[key] = val

        old_positions = pd.Series(0., index=all_pairs)
        for key, val in positions.items():
            old_positions[key] = val

        # In case where we no longer have any real exposure
        sub_abs_net = np.sum(np.abs(net_future_cashflows))
        if sub_abs_net < 1e-05:
            logger.info(
                f"  >> Abs sum of net future cashflows is small ({sub_abs_net}), returning zero as the position.")
            return PolicySummary(pd.Series(data=np.zeros_like(net_future_cashflows), index=all_pairs))

        logger.info("  >> MinVarPolicy: sourcing the data")
        spots = universe.fx_universe.fx_assets.get_fx_spots(pairs=all_pairs)
        vols = universe.fx_universe.fx_vols.vols_spots(pairs=all_pairs)
        corrs = universe.fx_universe.fx_corrs.instant_fx_spot_corr_matrix(pairs=all_pairs)

        # Calculate the original projected volatility, and volatility accounting for forwards.
        calc = PnLRiskCalculator(forwards=spots.values,
                                 vols=vols.values,
                                 correlations=corrs.values,
                                 dt=1. / 252, spots=None)

        original_var = calc.variance(raw_exposures.values)
        forward_inclusive_var = calc.variance(exposures.values)
        # Calculate the reduction that has already occurred because of forwards.
        reduction = 1 - np.sqrt(forward_inclusive_var / original_var)
        logger.info(f"  >> MinVarPolicy: reduction from forwards: {reduction:.3f}")

        # Calculate: reduction * further_reduction = target_reduction
        if self._vol_reduction_target <= reduction:
            logger.info(f"Variance reduction target already hit, reduction is {reduction} "
                        f"target was {self._vol_reduction_target}")
            effective_vol_reduction_target = 0
        elif reduction == 0:
            effective_vol_reduction_target = self._vol_reduction_target
        elif reduction < 0:
            # Hope we don't hit this case, but in case the raw exposures are *less* volatile.
            # Right now, just using the same vol target.
            effective_vol_reduction_target = self._vol_reduction_target
        else:
            effective_vol_reduction_target = self._vol_reduction_target / reduction

        # Initialize the calibrator / optimizer
        mv = MinVarCalibrator(last_positions=old_positions.values,
                              net_future_cashflows=net_future_cashflows.values,
                              forwards=spots.values,
                              vols=vols.values,
                              correlations=corrs.values,
                              target_reduction=effective_vol_reduction_target)

        # Add additional constraints/penalties
        logger.info("  >> MinVarPolicy: adding constraints")
        self._add_margin_budget(date=date, spots=spots, calibrator=mv, cost_provider=cost_provider)

        try:
            self._add_roll_costs(date=date, spots=spots, calibrator=mv, cost_provider=cost_provider)
        except Exception as ex:
            logger.error(f"  >> Error adding roll costs, will still optimize without: {ex}")

        try:
            self._add_trade_costs(date=date, spots=spots, calibrator=mv, cost_provider=cost_provider)
        except Exception as ex:
            logger.error(f"  >> Error adding trade costs, will still optimize without: {ex}")

        # Optimize Hedge Positions
        logger.info("  >> MinVarPolicy: optimizing")
        new_positions, summary, opt_result = mv.optimize_positions(include_summary=True)
        logger.info("  >> MinVarPolicy: done optimizing")

        if not opt_result.success:
            return self._make_positions(positions=new_positions, summary=summary, result=opt_result,
                                        pairs=all_pairs)

        # Add Max Exposure, if configured, and if previously optimized positions don't satisfy it.
        if self._has_VaR_bound():
            logger.info(f"  >> MinVarPolicy has VaR bound. Getting target.")
            target_VaR = self._get_target_VaR_daily_bound(date=date,
                                                          account_history_provider=account_history_provider,
                                                          spots=spots,
                                                          exposures=net_future_cashflows,
                                                          universe=universe)
            actual_VaR = mv.pnl_risk_calculator.value_at_risk(weights=new_positions + net_future_cashflows)

            # Scale up the
            last_flow = cash_exposures.last_cashflow_date_within_horizon()
            days_til_last = Date.days_between(start=date, end=last_flow)
            look_ahead = max(1, min(days_til_last, 10))

            if actual_VaR < target_VaR <= 0:
                mv.add_value_at_risk_bound(target_VaR=target_VaR, override_target=True, days_scale=look_ahead)
                new_positions, summary, opt_result = mv.optimize_positions(include_summary=True)

        return self._make_positions(positions=new_positions, summary=summary, result=opt_result, pairs=all_pairs)

    def _align_exposures(self, all_pairs, exposures) -> pd.Series:
        """
        Make sure that there is an entry for every pair in all_pairs, if the exposure does not appear in the original
        exposures, then it will be set to zero.
        """
        return pd.Series(data=exposures.reindex(all_pairs).fillna(0).values, index=all_pairs)

    def _add_margin_budget(self,
                           date: Date,
                           spots: pd.Series,
                           calibrator: MinVarCalibrator,
                           cost_provider: HedgeCostProvider):
        try:
            if self._include_margin_budget:
                # Add Margin Cost Budget to the objective
                margin_rates = cost_provider.get_spot_fx_margin_rates(date=date, fx_pairs=spots.index)
                if len(margin_rates) != len(spots):
                    raise RuntimeError(f"Margin rates are size: {len(margin_rates)} "
                                       f"but spots are size: {len(spots)}, can't optimize")
                if np.isnan(margin_rates.values).any():
                    logger.warning("Nan margin rates retrieved (missing data), ignoring in optimizer")
                    return
                calibrator.add_margin_budget(margin_long=margin_rates.values, margin_short=margin_rates.values,
                                             budget=self._settings.margin_budget)
        except Exception as e:
            logger.error(f"Error adding margin budget: {e}")

    def _add_roll_costs(self,
                        date: Date,
                        spots: pd.Series,
                        calibrator: MinVarCalibrator,
                        cost_provider: HedgeCostProvider):
        if self._include_roll_costs:
            # Add Roll Costs to the objective (note: roll cost are not necessarily the negative of the roll rate).
            roll_rates_long, roll_rates_short = cost_provider.get_spot_fx_roll_rates(date=date, fx_pairs=spots.index)
            if len(roll_rates_long) != len(roll_rates_short):
                raise RuntimeError(f"Long roll rates size {len(roll_rates_long)} "
                                   f"not equal to short roll rates size {len(roll_rates_short)}, can't optimize")

            if len(roll_rates_long) > 0:
                if len(roll_rates_long) != len(spots):
                    raise RuntimeError(f"Roll rates size {len(roll_rates_long)} not equal to "
                                       f"spots size {len(spots)}, can't optimize")

                if np.isnan(roll_rates_long).any() or np.isnan(roll_rates_short).any():
                    logger.warning("Nan roll costs retrieved (missing data), ignoring in optimizer")
                    return

                # NOTE: we negate them, so negative "costs" (ie interest paid) is seen as a positive number
                # by the penalty, since the penalty represents a cost as positive number, whereas the cost provider
                # represents costs as negative number
                # NOTE: roll rates are assumed to incorporate ttm already in them, no time calc is done by the
                # calibrator. Its a cost per unit of the FX pair
                calibrator.add_roll_costs(
                    costs_long=-roll_rates_long.values,
                    costs_short=-roll_rates_short.values)
            else:
                logger.warning("No roll costs found by provider (missing data), ignoring in optimizer")

    def _add_trade_costs(self,
                         date: Date,
                         spots: pd.Series,
                         calibrator: MinVarCalibrator,
                         cost_provider: HedgeCostProvider):
        if self._include_trade_costs:
            # Add Trading Costs to the objective
            trade_cost = cost_provider.get_spot_fx_transaction_costs(date=date)
            if len(trade_cost) > 0:
                if len(trade_cost) != len(spots):
                    raise RuntimeError(f"Trade costs size {len(trade_cost)} not equal to "
                                       f"spots size {len(spots)}, can't optimize")

                calibrator.add_trading_costs(costs=trade_cost.values)
            else:
                logger.warning("Include trade costs is on, but no roll costs found by provider, ignoring in optimizer")

    def _make_positions(self,
                        positions: np.ndarray,
                        summary: VarReductionSummary,
                        result: OptResult,
                        pairs: Iterable[FxPair]) -> PolicySummary:
        success = True
        if not result.success:
            success = False
            logger.warning(f"Optimizer failed to optimize, will use reasonable guess instead: {result.message}")

        return PolicySummary(pd.Series(data=positions, index=pairs),
                             success=success,
                             info={'opt_message': result.message,
                                   'reduction_summary': str(summary) if summary else "",
                                   'margin_budget': self._settings.margin_budget,
                                   'num_pairs': len(positions),
                                   'objective_cost': result.value})

    def _has_VaR_bound(self) -> bool:
        if not self._max_VaR95_exposure_percent \
                or self._max_VaR95_exposure_percent < 0 or self._max_VaR95_exposure_percent >= 1.:
            return False
        return True

    def _get_target_VaR_daily_bound(self,
                                    date: Date,
                                    account_history_provider: CashPnLAccountHistoryProvider,
                                    spots: pd.Series,
                                    exposures: pd.Series,
                                    universe: Universe
                                    ) -> float:
        if not self._has_VaR_bound():
            return np.inf

        if self._max_VaR95_exposure_percent < 1. and not account_history_provider:
            raise ValueError("You must supply a CashPnLAccountHistoryProvider to do a max VaR bound")

        # Now check how far to look back to consider (if None, e.g. single cashflow, then goes back to beginning)
        date_start = date - self._max_VaR95_exposure_days if self._max_VaR95_exposure_days else None

        pnl_to_date, exposure_from_start = account_history_provider.get_pnl_and_initial_exposure(
            start_date=date_start, end_date=date, universe=universe)

        if pnl_to_date is None:
            # This account has not yet been hedged
            pnl_to_date = 0
            exposure_from_start = np.dot(spots.values, exposures.values)

        target_VaR = -self._max_VaR95_exposure_percent * exposure_from_start - pnl_to_date

        target_VaR = min(target_VaR, 0)  # Once you've surpassed the max allowed losses, this calls for perfect hedge
        return target_VaR
