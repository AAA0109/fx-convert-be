from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair
from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Core.Currency import Currency

from hdlib.Hedge.Fx.Fill.FxOrderState import FxOrderFlowState
from hdlib.Hedge.Fx.Fill.OneFxPolicy import OneFxPolicy
from hdlib.Hedge.Fx.Fill.Cost import CostOfFxHedge, NoCostOfFxHedge
from hdlib.Hedge.Fx.Fill.Report import FxConversionReport, FxConversionReportSeries
from hdlib.Hedge.Fx.Fill.FxSpotLevelPolicy import FxSpotProvider

import pandas as pd
from typing import Optional, Sequence, Union


class FxHedgeBacktester(object):
    """
    Class for backtesting single currency hedges
    """

    def __init__(self,
                 domestic: Currency,
                 policy: OneFxPolicy,
                 spot_provider: FxSpotProvider,
                 do_fill: bool = True,
                 prevent_overfill: bool = True,
                 cost: CostOfFxHedge = NoCostOfFxHedge()
                 ):
        """

        :param domestic: Currency, the domestic currency that all cashflows should be converted into
        :param policy: CurrencyHedgePolicy, a policy for converting cash into domestic
        :param cost: CostOfCurrencyHedge, a prescription for cacluating the cost of a hedging strategy
        """
        self._policy = policy
        self._domestic = domestic
        self._spot_provider = spot_provider
        self._do_fill = do_fill
        self._prevent_overfill = prevent_overfill
        self._cost = cost

    def test_cashflows_for_date(self,
                                order_date: Date,
                                cashflows: Union[CashFlow, Sequence[CashFlow]],
                                spots: Optional[pd.Series] = None) -> FxConversionReport:
        """
        Run backtest on a one or more cashflows in a single currency
        :param order_date: Date, the date on which the hedge is ordered
        :param cashflows: Sequence[CashFlow], the cashflows to hedge (convert to domestic)
        :return: CurrencyHedgeReport, a report summarizing the results of the hedge
        """
        if isinstance(cashflows, CashFlow):
            cashflows = [cashflows]

        order_state = FxOrderFlowState.from_cashflows(order_date=order_date, domestic=self._domestic,
                                                      cashflows=cashflows,
                                                      filter_currency=cashflows[0].currency,
                                                      prevent_overfill=self._prevent_overfill,
                                                      do_fill=self._do_fill)

        if spots is None:
            spots = self._spot_provider.fx_spots_in_range(start=order_date, end=order_state.final_due_date,
                                                          fx_pair=order_state.fx_pair)
        for order in order_state.orders:
            if order.due_date not in spots:
                raise ValueError("Your cashflow pay date is not a buisness date")

        report = FxConversionReport(orders=order_state.orders, spots=spots, policy_name=self._policy.name,
                                    do_fill=self._do_fill)

        policy = self._policy.copy()
        policy.initialize(date=order_date, order_state=order_state)
        for date in report.dates:
            action = policy.action(date=date, order_state=order_state)
            order_state.finalize_state()
            report.add_action(balance=order_state.fx_position, action=action)

        report.finalize_report(cost=self._cost)
        return report

    def test_stylized_cashflow_for_dates(self,
                                         start_date: Date,
                                         end_date: Date,
                                         amount: float,
                                         currency: Currency,
                                         days_away: int) -> FxConversionReportSeries:
        """
        Runs a "stylized" backtest test of a single cashflow over a range of dates. We keep the time until cashflow
        constant, and test a strategy across multiple dates in a backtest range
        :param start_date: Date, first date for which we run the test
        :param end_date: Date,
        :param amount: float, the amount of foreign currency to convert into domestic
        :param currency: Currency, the foreign currency
        :param days_away: int, number of business/trading days away is this cashflow
        :return: CurrencyHedgeReportSeries, reports for days in the backtest
        """
        fx_pair = FxPair(base=currency, quote=self._domestic)
        spots = self._spot_provider.fx_spots_in_range(start=start_date, end=end_date + days_away, fx_pair=fx_pair)
        trade_dates = spots.index
        reports = FxConversionReportSeries(do_fill=self._do_fill)

        for i in range(len(trade_dates) - days_away + 1):
            date = trade_dates[i]
            pay_date = trade_dates[min(len(trade_dates) - 1, i + days_away - 1)]

            cashflow = CashFlow(amount=amount, currency=currency, pay_date=pay_date)
            spots_range = spots[(date <= spots.index) & (spots.index <= pay_date)]

            report = self.test_cashflows_for_date(order_date=date, cashflows=cashflow, spots=spots_range)
            reports.add_report(report)

        return reports
