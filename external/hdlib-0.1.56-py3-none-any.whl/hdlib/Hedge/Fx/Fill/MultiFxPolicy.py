from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair

from hdlib.Hedge.Fx.Fill.Action import FxHedgeAction
from hdlib.Hedge.Fx.Fill.OneFxPolicy import OneFxPolicy
from hdlib.Hedge.Fx.Fill.MultiFxOrderState import MultiFxOrderFlowState

from abc import ABC, abstractmethod
from typing import Dict
from copy import deepcopy


class MultiFxPolicy(ABC):
    """
    Abstract base class for a multi currency hedging policy. A policy is a mapping from a date and a current
    order state (ie how much of a requested currency order has been filled) into an action, ie how much to buy
    """

    def __init__(self, name: str = 'UnknownPolicy'):
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    @abstractmethod
    def actions(self, date: Date, order_state: MultiFxOrderFlowState) -> Dict[FxPair, FxHedgeAction]:
        """
        Perform a sequence hedging actions (how much to buy/sell) in accordance with the policy,
        given the states on this date. There is one action corresponding to each FxPair
        The action also updates the state
        :param date: Date, the date on which to perform the action (corresponds to "now")
        :param order_state: MultiFxOrderFlowState, the current state of each FxPair,
                tracks how much remains to purchase for each FxPair
        :return:
        """
        raise NotImplementedError

    def initialize(self, date: Date, order_state: MultiFxOrderFlowState):
        """
        Ability to initialize a policy on a start date. For example, a stop loss strategy could initialize itself
        to the spot level on some date
        :param date: Date, the date on which the policy starts
        :param order_state: MultiFxOrderFlowState, the flow states at initialization
        """
        return

    def copy(self) -> 'MultiFxPolicy':
        """
        Create a deep copy of this policy. Allows the policy to maintain state, and/or to be initialized from
        some point in time, dependent on when it is initialized
        """
        return deepcopy(self)


class MultiOneFxPolicy(MultiFxPolicy):
    def __init__(self,
                 policies: Dict[FxPair, OneFxPolicy],
                 name: str = None):
        """
        A multi Fx policy formed from indepdent OneFx policies, each focusing on only one FxPair

        :param policies: Dict[FxPair, OneFxPolicy], one policy per FxPair
        :param name: str, the name of this policy
        """
        super().__init__(name=name if name else f"Multi-Policy")
        self._policies = policies

    def actions(self, date: Date, order_state: MultiFxOrderFlowState) -> Dict[FxPair, FxHedgeAction]:
        actions: Dict[FxPair, FxHedgeAction] = {}
        for fx_pair, state in order_state.fx_states.items():
            actions[fx_pair] = self._policies[fx_pair].action(date=date, order_state=state)

        return actions

    def initialize(self, date: Date, order_state: MultiFxOrderFlowState):
        for fx_pair, state in order_state.fx_states.items():
            self._policies[fx_pair].initialize(date=date, order_state=state)