from hdlib.DateTime.Date import Date
from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD
from hdlib.DataProvider.Fx.FxSpotProvider import FxSpotProvider
from hdlib.Hedge.Fx.Fill.Action import FxHedgeAction
from hdlib.Hedge.Fx.Fill.FxOrder import FxOrder
from hdlib.Hedge.Fx.Fill.FxOrderState import FxOrderFlowState
from hdlib.Hedge.Fx.Fill.OneFxPolicy import OneFxPolicy

import numpy as np
from abc import ABC


# ==============================================================


class FxSpotLevelPolicy(OneFxPolicy, ABC):
    def __init__(self,
                 name: str,
                 spot_provider: FxSpotProvider):
        """
        A simple policy that depends only on the level of spot FX. E.g. trigger-based policies such as StopLoss
        :param name: str, Name of the policy
        :param spot_provider: SpotFxProvider, object which provides spots upon request
        """
        super().__init__(name=name)
        self._spot_provider = spot_provider


class BuySpotLevel(FxSpotLevelPolicy):
    """
    Simple trigger policy to buy a percentage of the remaining order if the spot drops above/below some value
    """

    def __init__(self,
                 buy_if_above: bool,
                 spot_level: float,
                 portion_of_remaining: float,
                 spot_provider: FxSpotProvider):
        """
        :param buy_if_above: bool, if true, buy when the spot is above the given level, else buy when below
        :param spot_level: float, level of spot which triggers buy action
        :param portion_of_remaining: float, the portion of remaining order to buy when triggered, between [0,1]
        :param spot_provider: SpotFxProvider, object which provides spots upon request
        """
        super().__init__(name='Buy Level', spot_provider=spot_provider)
        self._buy_if_above = buy_if_above
        self._spot_level = spot_level
        self._portion_of_remaining = portion_of_remaining

        if portion_of_remaining < 0 or portion_of_remaining > 1.:
            raise ValueError("You can only buy between [0,1] remaining proportion")

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        spot = self._spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)

        if self._is_triggered(spot=spot):
            remaining = order_state.net_remain_to_fill
            if remaining > 0:
                amount = remaining * self._portion_of_remaining
                return FxHedgeAction.buy(date=date, amount=amount, fx_pair=order_state.fx_pair)

        return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)

    def _is_triggered(self, spot: float):
        if self._buy_if_above and spot > self._spot_level:
            return True
        if not self._buy_if_above and spot < self._spot_level:
            return True
        return False


class BuySpotLevelFromRefDate(BuySpotLevel):
    def __init__(self,
                 buy_if_above: bool,
                 spot_multiplier: float,
                 portion_of_remaining: float,
                 spot_provider: FxSpotProvider):
        super().__init__(buy_if_above=buy_if_above, portion_of_remaining=portion_of_remaining,
                         spot_provider=spot_provider, spot_level=np.nan)
        self._spot_multiplier = spot_multiplier

    def initialize(self, date: Date, order_state: FxOrder):
        spot_ref = self._spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)
        self._spot_level = self._spot_multiplier * spot_ref


class DCABuyHighPolicy(FxSpotLevelPolicy):
    """
    A variation on DCA whereby the amount of currency purchased is increased whenever the spot is above
    some level
    """

    def __init__(self,
                 spot_provider: FxSpotProvider,
                 dc: DayCounter = DayCounter_HD(),
                 spot_multiplier=1.0,
                 amount_multiplier=2.):
        self._dc = dc
        super().__init__(name='Buy High DCA', spot_provider=spot_provider)
        self._spot_level = np.nan
        self._spot_multiplier = spot_multiplier
        self._amount_multiplier = amount_multiplier

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        remaining = order_state.net_remain_to_fill
        if remaining <= 0:
            return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)

        days = self._dc.days_between(start=date, end=order_state.final_due_date)
        amount = remaining / days  # uniformly distributes remaining amount across future dates
        if amount < remaining:
            spot = self._spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)
            if spot > self._spot_level:
                amount = min(remaining, amount * self._amount_multiplier)
            else:
                amount /= self._amount_multiplier

        return FxHedgeAction.buy(date=date, amount=amount, fx_pair=order_state.fx_pair)

    def initialize(self, date: Date, order_state: FxOrder):
        spot_ref = self._spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)
        self._spot_level = self._spot_multiplier * spot_ref


class BuyHighSellLowFromRefDate(FxSpotLevelPolicy):
    def __init__(self,
                 spot_provider: FxSpotProvider,
                 buy_portion: float = 0.5,
                 sell_portion: float = 0.5,
                 buy_trigger: float = 1.03,
                 sell_trigger: float = 0.97
                 ):
        super().__init__(spot_provider=spot_provider, name="Buy High Sell Low")
        self._buy_portion = buy_portion
        self._sell_portion = sell_portion

        self._spot_level = np.nan
        self._buy_trigger = buy_trigger
        self._sell_trigger = sell_trigger

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        order_amount = order_state.net_order_amount
        spot = self._spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)

        if self._buy_portion > 0 and spot > self._spot_level * self._buy_trigger:
            return FxHedgeAction.buy(date=date, amount=order_amount * self._buy_portion,
                                     fx_pair=order_state.fx_pair)
        if self._sell_portion > 0 and spot < self._spot_level * self._sell_trigger:
            return FxHedgeAction.sell(date=date, amount=order_amount * self._sell_portion,
                                      fx_pair=order_state.fx_pair)

        return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)

    def initialize(self, date: Date, order_state: FxOrder):
        self._spot_level = self._spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)
