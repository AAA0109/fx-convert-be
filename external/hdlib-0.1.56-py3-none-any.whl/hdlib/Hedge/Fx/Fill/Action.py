from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair


class FxHedgeAction(object):
    def __init__(self, date: Date, amount: float, fx_pair: FxPair):
        """
        A hedging action taken on a particular date, which is simply the amount of currency converted
        :param date: Date, the date on which action is taken
        :param amount: float, the amount purchased (converted into domestic) on this date. Could be 0 (hold),
                      if this number is negative it corresponds to a sell action
        """
        self.date = date
        self.amount = amount
        self.fx_pair = fx_pair

    @classmethod
    def hold(cls, date: Date, fx_pair: FxPair) -> 'FxHedgeAction':
        """ Hold Action. Don't purchase anything """
        return cls(date=date, amount=0., fx_pair=fx_pair)

    @classmethod
    def buy(cls, date: Date, amount: float, fx_pair: FxPair) -> 'FxHedgeAction':
        """ Buy Action. Purchase some amount (ensures positive) """
        if amount <= 0:
            raise ValueError("A buy action must be for a positive amount ")
        return cls(date=date, amount=amount, fx_pair=fx_pair)

    @classmethod
    def sell(cls, date: Date, amount: float, fx_pair: FxPair) -> 'FxHedgeAction':
        """ Sell Action. Sell some amount (ensures negative) """
        if amount <= 0:
            raise ValueError("A sell action must be for a positive amount ")
        return cls(date=date, amount=-amount, fx_pair=fx_pair)

    @classmethod
    def buy_or_sell(cls, date: Date, amount: float, fx_pair: FxPair) -> 'FxHedgeAction':
        """ Buy or Sell Action. The amount is signed. So positive is a buy, negative is sell """
        if amount == 0:
            raise ValueError("A buy or sell action must be for a non zero amount ")
        return cls(date=date, amount=amount, fx_pair=fx_pair)

    @classmethod
    def buy_sell_or_hold(cls, date: Date, amount: float, fx_pair: FxPair) -> 'FxHedgeAction':
        """ Buy, Sell, or Hold Action.The amount is signed. So positive is a buy, negative is sell, 0 is hold """
        return cls(date=date, amount=amount, fx_pair=fx_pair)

    def merge(self, other: 'FxHedgeAction'):
        """ Merge another action on same date into this one """
        if other.date != self.date:
            raise ValueError("You cannot merge two actions on different dates")
        if other.fx_pair != self.fx_pair:
            raise ValueError("You cannot merge two actions on different fx pairs")
        self.amount += other.amount
