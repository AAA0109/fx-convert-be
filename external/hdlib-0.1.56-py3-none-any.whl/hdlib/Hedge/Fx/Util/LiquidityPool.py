from typing import Optional, Dict, Union

import pandas as pd
import numpy as np
from hdlib.Core.AccountInterface import AccountInterface

from hdlib.Core.FxPairInterface import FxPairInterface


class LiquidityPool(object):
    """
    Maintains a pool for each fx pair (in market convention) which is the unhedged exposure for that pair,
    netted over all accounts. This can be used to absorb desired hedges, and prevent unneeded trading with the OMS.
    It also prevents increasing a customers net risk in any case

    # --------------------------------------------------------------------------------------------------------------
    # Example I:  No Risk, No Net Reduction  ... The original "Oh Shit" case
    # --------------------------------------------------------------------------------------------------------------
    # Account 1:   Exposure: +100 GBP, Risk reduction: 10%,  Hedge Position: -10 GBP, Liquidity Pool: +90 GBP
    # Account 2:   Exposure: -100 GBP, Risk reduction: 80%,  Hedge Position: +80 GBP, Liquidity Pool: -20 GBP

    # Net Requested hedge:   +70 GBP     <- Net Requested by the accounts
    # Net Liquidity Pool:     +70 GBP     <- We absorb this liquidity before going to OMS (ie, we use residual risk to absorb opposing risk)
    # Net Submitted Trade:   +0 GBP      <- After netting, and exhausting liquidity pool, how much to we actually submit to IB
    # Net Unhedged Exposure: +0 GBP      <- How much exposure customer has across all accounts, allowing natural netting
    # Net Hedged Exposure:   +0 GBP      <- How much exposure customer has across all accounts, after hedging

    # --------------------------------------------------------------------------------------------------------------
    # Example II:  Has Risk, 100% Net Reduction  (More than requested in either account)
    # --------------------------------------------------------------------------------------------------------------
    # Account 1:   Exposure: +50 GBP,  Risk reduction: 10%,  Hedge Position: -5 GBP,  Liquidity Pool: +45 GBP
    # Account 2:   Exposure: -100 GBP, Risk reduction: 80%,  Hedge Position: +80 GBP, Liquidity Pool: -20 GBP

    # Net Requested hedge:   +75 GBP
    # Net Liquidity Pool:     +25 GBP
    # Net Submitted Trade:   +50 GBP
    # Net Unhedged Exposure: -50 GBP
    # Net Hedged Exposure:   +0 GBP   (100% Net Risk Reduction)

    # --------------------------------------------------------------------------------------------------------------
    # Example III:  Has Risk, 0% Net Reduction  (Less than requested in either account, but individually
    # each account keeps promise)
    # --------------------------------------------------------------------------------------------------------------
    # Account 1:   Exposure: +100 GBP,  Risk reduction: 10%,  Hedge Position: -10 GBP, Liquidity Pool: +90 GBP
    # Account 2:   Exposure: -20 GBP,   Risk reduction: 50%,  Hedge Position: +10 GBP, Liquidity Pool: -10 GBP

    # Net Requested hedge:   +0 GBP
    # Net Liquidty Pool:     +80 GBP
    # Net Submitted Trade:   +0 GBP
    # Net Unhedged Exposure: +80 GBP
    # Net Hedged Exposure:   +80 GBP   (0% Net Risk Reduction)
    # --------------------------------------------------------------------------------------------------------------
    """

    def __init__(self):
        # Net Unhedged Exposure Across All Accounts
        self._net_unhedged_exposure = {}
        # Exposures per FxPair per account.
        self._exposure_per_fx_per_account: Dict[FxPairInterface, Dict[AccountInterface, float]] = {}

    @property
    def account_exposures(self) -> Dict[FxPairInterface, Dict[AccountInterface, float]]:
        return self._exposure_per_fx_per_account

    def add_to_pool(self, full_exposure_mkt: Union[pd.Series, Dict[FxPairInterface, float]], account: Optional[AccountInterface] = None):
        """
        Add exposures to the pool for an account (each account will add its exposures to this pool),
            IN MARKET CONVENTION

        :param full_exposure_mkt: pd.Series, the FX exposure in each pair for that account, across all cashflows,
            in market convention
        :param account: Account, the account whose exposures are being added.
        """
        for fxpair, amount in full_exposure_mkt.items():
            self._net_unhedged_exposure[fxpair] = self._net_unhedged_exposure.get(fxpair, 0.) + amount
            if account is not None:
                self._exposure_per_fx_per_account.setdefault(fxpair, {})[account] = amount

    def get_net_cash_exposures(self, fx_pair: FxPairInterface) -> float:
        """
        Get the net cash exposure for a specific FX pair. NOTE: this should be IN MARKET CONVENTION. We don't do
            any checking if you supplied the wrong convention.
        :param fx_pair: str, the FX pair
        :return: float, the "pool liquidity" ie net unhedged cash exposure for this pair
        """
        return self._net_unhedged_exposure.get(fx_pair, 0.)

    def get_residual_position(self, fx_pair: FxPairInterface, desired_position: float) -> float:
        """
        Get the residual FX position to take, after applying any existing liquidity first to absorb some or all of
        the desired position.

        :param fx_pair: str, the FX pair
        :param desired_position: float, the desired (net) hedge position in this pair, ie netted FX hedge position
            across all accounts for customer
        :return: float, the amount of position to hold, after we absorb whatever we can with liquidity from the pool
            This residual is the position we take, and should submit to broker
        """
        if desired_position == 0.:
            return 0.
        net_unhedged_exposure = self.get_net_cash_exposures(fx_pair=fx_pair)

        if np.sign(net_unhedged_exposure) == np.sign(desired_position):
            return 0.  # In this case, we can absorb the hedge via excess liquidity
        elif np.abs(desired_position) > np.abs(net_unhedged_exposure):
            # In this case, cap the hedge to be no more than the net exposure (in opposite direction)
            # NOTE: consider relaxing this, based on cross-currency hedging
            return -net_unhedged_exposure
        else:
            return desired_position
