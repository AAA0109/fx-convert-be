import inspect
import logging
import sys

_LOG_FORMAT = '%(asctime)s %(levelname)-8s: %(message)s'
_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'


def get_logger(level=logging.DEBUG, log_file=None):
    module_ = inspect.getmodule(inspect.stack()[1][0]).__name__
    logger = logging.getLogger(module_)
    logger.setLevel(level)

    logging.basicConfig(format=_LOG_FORMAT, stream=sys.stdout, level=level, datefmt=_DATE_FORMAT)
    formatter = logging.Formatter(fmt=_LOG_FORMAT, datefmt=_DATE_FORMAT)

    if log_file:   # ensures that logging is sent to screen as well, and not just diverted to file
        file_handler = logging.FileHandler(filename=log_file)
        file_handler.setFormatter(formatter)
        logging.getLogger("").addHandler(file_handler)

    return logger


def get_file_rotating_logger(log_file, level=logging.DEBUG, when='D', interval=1, backupCount=5):
    from logging.handlers import TimedRotatingFileHandler

    logging.basicConfig(format=_LOG_FORMAT, stream=sys.stdout, level=level, datefmt=_DATE_FORMAT)
    formatter = logging.Formatter(fmt=_LOG_FORMAT, datefmt=_DATE_FORMAT)

    file_handler = TimedRotatingFileHandler(filename=log_file, when=when, interval=interval, backupCount=backupCount)
    file_handler.setFormatter(formatter)
    logger = logging.getLogger("")
    logger.addHandler(file_handler)
    logger.setLevel(level)

    return logger

#################################


if __name__ == '__main__':
    logger_ = get_logger(log_file='C:/temp/test_log.log')
    logger_.info('Testing file + screen logger')
