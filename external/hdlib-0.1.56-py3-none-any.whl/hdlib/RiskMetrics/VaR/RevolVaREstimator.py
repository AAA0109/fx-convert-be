from hdlib.RiskMetrics.VaR.VaREstimator import VaREstimator
from hdlib.RiskMetrics.Volatility.VolEstimator import VolEstimator
from hdlib.RiskMetrics.VaR.QuantileEstimator import QuantileEstimator, EmpiricalQuantileEsimator

import numpy as np
from typing import Optional


class RevolVaREstimator(VaREstimator):
    """
    Value-At-Risk (VaR) Estimator which uses a simple devol/revol procedure, based on a supplied volatility estimator,
    to estimate top-day VaR
    """

    def __init__(self,
                 do_revol: bool = True,
                 vol_estimator: Optional[VolEstimator] = None,
                 window: int = 250,
                 quantile_estimator: QuantileEstimator = EmpiricalQuantileEsimator()):
        """
        :param do_revol: bool, if true applies the devol/revol procedure (else its just standard quantile estimate)
        :param vol_estimator: VolEstimator, used to estimate vols to devol/revol
        :param window: int, the window size for rolling estimates
        """
        super().__init__()
        self._do_revol = do_revol
        self._vol_estimator = vol_estimator
        self._window = window
        self._quantile_estimator = quantile_estimator

        if self._do_revol and self._vol_estimator is None:
            raise ValueError("You supplied do_revol=True but no vol_estimator!")

    def estimate(self, returns: np.ndarray, var_level: float = 0.99) -> float:
        """
        Main method, estimate the VaR for this entire times series of PnL/returns data (increasing time)
        :param returns: np.ndarray, returns/PnL data (increasing time)
        :param var_level: float, the VaR level
        :return: float, the VaR estimate
        """
        rets = returns
        return self._quantile_estimator.quantile(rets, 1 - var_level)

    def sliding_estimate(self, returns: np.ndarray, window: int) -> np.ndarray:
        """
        Sliding window estimates of VaR. Can be fed into backtest
        :param returns: np.ndarray, returns/PnL data (increasing time)
        :param window: int, the window size for estimation
        :return: np.ndarray, array of estimates of size len(returns) - window + 1, containing VaR estimates in a
        sliding fashion
        """
        if self._do_revol:
            rets = self._vol_estimator.revol_returns(returns=returns, window=self._window)
        else:
            rets = returns
        estimates = [self.estimate(chunk) for chunk in np.lib.stride_tricks.sliding_window_view(rets, window)]
        return np.asarray(estimates)
