from hdlib.Instrument.Instrument import Instrument

from typing import List, Optional, Sequence


class Position(object):
    def __init__(self, instrument: Instrument, quantity: float):
        self._instrument = instrument
        self._quantity = quantity

    @property
    def instrument(self):
        return self._instrument

    @property
    def quantity(self):
        return self._quantity


class Portfolio(Sequence):
    def __init__(self, positions: Optional[List[Position]] = None):
        self._positions = positions or []

    @property
    def positions(self):
        return self._positions

    @property
    def size(self):
        return self.__len__()

    @property
    def empty(self) -> bool:
        return self.size == 0

    def add_position(self, position: Position):
        self._positions.append(position)

    def get_positions_for_currency(self) -> List[Position]:
        pos = []
        for position in self._positions:
            if position.instrument.currency_long:
                pos.append(position)

        return pos

    def __len__(self):
        return len(self._positions)

    def __iter__(self):
        return iter(self._positions)

    def __getitem__(self, index):
        return self._positions[index]

    def __next__(self):
        return next(self._positions)
