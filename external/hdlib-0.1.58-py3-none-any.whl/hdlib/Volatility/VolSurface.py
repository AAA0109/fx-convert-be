from abc import ABC, abstractmethod
from typing import Union
import numpy as np

from hdlib.DateTime.Date import Date
from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD


class VolSurface(ABC):
    def __init__(self, ref_date: Date, dc: DayCounter = DayCounter_HD()):
        """
        Base class for volatility surfaces
        :param ref_date: Date, the reference/valuation date
        :param dc: DayCounter, how time/days are counted
        """
        self._ref_date = ref_date
        self._dc = dc

    @property
    def ref_date(self) -> Date:
        return self._ref_date

    @abstractmethod
    def vol_KT(self, K: Union[float, np.ndarray], T: float) -> Union[float, np.ndarray]:
        """
        Get volatility at a strike and Time to maturity
        :param K: float or array, strike(s)
        :param T: float, time to maturity of option
        :return: float or array of vol(s) at strike(s)
        """
        raise NotImplementedError

    def vol_KD(self, K: Union[float, np.ndarray], date: Date) -> Union[float, np.ndarray]:
        """
        Get volatility at a strike and Date of option maturity
        :param K: float or array, strike(s)
        :param date: float, maturity date of option
        :return: float or array of vol(s) at strike(s)
        """
        return self.vol_KT(K, T=self._dc.year_fraction(self._ref_date, date))
