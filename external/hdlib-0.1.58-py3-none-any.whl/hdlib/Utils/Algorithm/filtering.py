from typing import Optional, List

import numpy as np

from hdlib.DateTime.Date import Date


def filter_lists(dates: List[Date], data: List[List[float]]):
    """
    Take a collection of lists of data, indexed by a list of dates, and only keep the last entry for each calendar date
    where none of the data is NaN.

    :param dates, Sequence[Date], the index of dates, assumed to be unique and sorted in ascending order.
    :param data, List[List[float]], a list of all the data lists. The data should all be floats, and each list of
        floats should have the same size.
    """
    if len(data) == 0:
        return dates, []

    l = len(data[0])
    for lst in data:
        if len(lst) != l:
            raise ValueError(f"all lists in the input must be the same size")
    if l != len(dates):
        raise ValueError(f"the length of the dates and data must be the same")

    dates_out = []
    data_out = [[] for _ in data]

    date_for_day: Optional[Date] = None
    data_for_day: Optional[List[float]] = None
    for i in range(l):
        date = dates[i]

        # If this is valid data (no nans), set it as the data for the day, since this comes (temporally after)
        # any other data in the day.
        data_slice = [d[i] for d in data]
        if not np.any(np.isnan(data_slice)):
            date_for_day = date
            data_for_day = data_slice

        # If the next date is in a new day, or the list ends, add the last point from the last day (if there is one)
        # and reset the structures.
        if i + 1 == l or (date_for_day is not None and dates[i + 1].date() != date_for_day.date()):
            # Only add data if there was any.
            if data_for_day is not None:
                dates_out.append(date_for_day)
                for j in range(len(data)):
                    data_out[j].append(data_for_day[j])

            date_for_day = date
            data_for_day = None

    return dates_out, data_out