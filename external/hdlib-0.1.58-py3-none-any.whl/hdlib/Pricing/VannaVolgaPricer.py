from typing import Optional


class VannaVolgaSmilePricer:
    def __init__(self,
                 T: float,

                 K_atm: float, vol_atm: float,
                 K_25p: float, vol_25p: float,
                 K_25c: float, vol_25c: float,
                 rr_cost: Optional[float] = None,
                 bf_cost: Optional[float] = None):
        """ """
        self._T = T
        self._K_atm = K_atm
        self._vol_atm = vol_atm
        self._K_25p = K_25p
        self._vol_25p = vol_25p
        self._K_25c = K_25c
        self._vol_25c = vol_25c

    def price(self):
        rr_cost = 0
        bf_cost = 0
