import numpy as np


def vix_vol(strikes: np.ndarray, prices: np.ndarray, T: float, F: float, disc: float) -> float:
    """
    Calculate VIX volatility from a set of OTM quotes
    :param strikes: np.ndarray, strikes, increasing order
    :param prices: np.ndarray, prices per strike
    :param T: float, time to expiry
    :param F: float, foward at T
    :param disc: float, discount at T
    :return: float, the vix computation of expected future realized volatitity over [0, T]
    """
    # TODO: handle a strike == F
    i = np.argmax(strikes >= F) - 1
    K0 = strikes[i]

    dk = (strikes[2:] - strikes[:-2]) / 2
    kvec = dk / np.power(strikes[1:-1], 2)

    # Interior strikes
    tv = np.dot(prices[1:-1], kvec)

    # Boundary strikes
    tv += prices[0] * dk[0] / np.power(strikes[0], 2) + prices[-1] * dk[-1] / np.power(strikes[-1], 2)

    tv *= 2. / disc
    tv -= np.power(F / K0 - 1, 2)
    return np.sqrt(tv / T)


def vix_vol_interpolation(vix_1: float, T_1: float,
                          vix_2: float, T_2: float,
                          T: float):
    tv1 = vix_1 ** 2 * T_1
    tv2 = vix_2 ** 2 * T_2

    tv = tv1 + (T - T_1) / (T_2 - T_1) * (tv2 - tv1)
    return np.sqrt(tv / T)
