from typing import Union, Optional, Tuple
import numpy as np

from hdlib.TermStructures.DiscountCurve import DiscountCurve, EmptyDiscountCurve
from hdlib.TermStructures.ForwardCurve import ForwardCurve
from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair


class FxForwardCurve(ForwardCurve):
    def __init__(self,
                 pair: FxPair,
                 F0: float,
                 foreign_discount: DiscountCurve,
                 domestic_discount: DiscountCurve,
                 adjustment_discount: Optional[DiscountCurve] = None):
        """
        FX forward curve: spot driven, deterministic forward. This is a convenience class. In many cases, we will
        have FX term structure directly, which can be interpolated. This class also supports this case, which is the
        purpose of the adjustment curve, which is used to match the differnce between observed forwards and the
        theoretical FX curve that is the ratio of foreign to domestic discount curves
        :param F0: float, spot FX at reference time
        :param pair: FxPair, the FX pair (foreign->Domestic)
        :param foreign_discount: DiscountCurve, for foreign currency (first in pair)
        :param domestic_discount: DiscountCurve, for domestic currency (second in pair)
        :param adjustment_discount: DiscountCurve, used to ensure that this FxForwardCurve exactly reproduces a
            set of FX forward rates provided by market (e.g. its an interpolated curve)
        """
        super(FxForwardCurve, self).__init__(ref_date=foreign_discount.ref_date, dc=foreign_discount.day_counter)
        self._pair = pair
        self._F0 = F0
        self._foreign_discount = foreign_discount
        self._domestic_discount = domestic_discount
        self._adjustment_discount = adjustment_discount \
                                    or EmptyDiscountCurve(ref_date=self.ref_date, dc=self.day_counter)

    def get_pair(self) -> FxPair:
        """ Get the FXPair object for this curve """
        return self._pair

    def spot(self) -> float:
        """ Get the spot FX rate """
        return self._F0

    def at_T(self, T: Union[float, np.ndarray]) -> Union[float, np.ndarray]:
        return self._F0 * self._foreign_discount.at_T(T) \
               / self._domestic_discount.at_T(T) * self._adjustment_discount.at_T(T)
