from abc import abstractmethod
from typing import Optional, List

from hdlib.Core.Currency import Currency
from hdlib.DateTime.Calendar.Calendar import Calendar, RollConvention, NullCalendar
from hdlib.DateTime.Date import Date
from hdlib.DateTime.DateGenerator import DateGeneratorRRule
from hdlib.DateTime.DayCounter import DayCounter_HD
from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Instrument.CashFlowGenerator import CashFlowGenerator


class RecurringCashFlow(CashFlowGenerator):
    """

    """

    def __init__(self,
                 currency: Currency,
                 amount: float,
                 periodicity: str,
                 start_date: Date,
                 end_date: Optional[Date] = None,
                 name: Optional[str] = None):
        super().__init__(currency=currency)
        self._amount = amount
        self._periodicity = periodicity
        self._start_date = start_date
        self._end_date = end_date
        self._name = name
        self._generator = DateGeneratorRRule(periodicity=periodicity, start_date=start_date, end_date=end_date)

    @property
    def start_date(self):
        return self._start_date

    @property
    def end_date(self):
        return self._end_date

    @property
    def amount(self):
        return self._amount

    @property
    def periodicity(self):
        return self._periodicity

    def generate_cashflows(self, date: Date, max_days: Optional[int] = None) -> List[CashFlow]:
        cashflows = []
        while not self._generator.is_ended():
            pay_date = self._generator.generate()
            if pay_date < date:
                continue
            cashflows.append(CashFlow(amount=self._amount, currency=self.currency, pay_date=pay_date, name=self._name))
        return cashflows

    @property
    def currency(self):
        return self._currency
