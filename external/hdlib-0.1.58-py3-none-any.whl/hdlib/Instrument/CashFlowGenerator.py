from abc import ABC, abstractmethod
from typing import Optional, List, Union

import numpy as np

from hdlib.Core.Currency import Currency
from hdlib.DateTime.Date import Date
from hdlib.Instrument.CashFlow import CashFlow


class CashFlowGenerator(ABC):
    """
    Base class for objects that create sequences of cash flows.
    """

    def __init__(self, currency: Currency):
        self._currency = currency

    @abstractmethod
    def generate_cashflows(self, date: Date, max_days: Optional[int] = None) -> List[CashFlow]:
        raise NotImplementedError

    @property
    def currency(self):
        return self._currency


class CyclicCashFlow(CashFlowGenerator):
    """
    A periodic cashflow generator, represents a sequence of cashflows repeating cyclically.
    """

    def __init__(self,
                 currency: Currency,
                 amounts: List[float],
                 per_days: int,
                 start_days: Optional[int] = None,
                 end_days: Optional[int] = None,
                 repeat: Optional[int] = None):
        super().__init__(currency=currency)

        if per_days <= 0:
            raise Exception("days spacing (\"per_days\") must be > 0")
        if end_days is not None and repeat is not None:
            raise Exception("only one of the options \"end_days\" and \"repeat\" can not be None")

        self._amounts = amounts
        self._per_days = per_days
        self._start_days = start_days
        self._end_days = end_days
        self._repeat = repeat

    def generate_cashflows(self, date: Date, max_days: Optional[int] = None) -> List[CashFlow]:
        if max_days is None and self._end_days is None and self._repeat is None:
            raise Exception("either max_days or self._end_days or self._repeat must not be None")

        end = None
        if self._repeat is not None:
            end = self._start_days if self._repeat == 0 else self._start_days + (self._repeat - 1) * self._per_days
        elif self._end_days is not None:
            end = self._end_days

        end = min(max_days, end) if max_days is not None and end is not None \
            else (max_days if max_days is not None else end)

        output = []
        days = self._per_days if self._start_days is None else self._start_days

        i = 0
        while days <= end:
            if 0 <= days:
                output.append(CashFlow(amount=self._amounts[i], currency=self._currency, pay_date=date + days))
            days += self._per_days
            i += 1
            i = np.mod(i, len(self._amounts))

        return output


class SingleCashFlow(CyclicCashFlow):
    """
    Represents a single cashflow.
    """

    def __init__(self, currency: Currency, amount: float, days: int):
        super().__init__(currency=currency, amounts=[amount], per_days=0, start_days=days, repeat=1)


class PeriodicCashFlow(CyclicCashFlow):
    """
    A periodic cashflow generator, represents the same (amount) cashflow occurring at fixed intervals.
    """

    def __init__(self,
                 currency: Currency,
                 amount: float,
                 per_days: int,
                 start_days: Optional[int] = None,
                 end_days: Optional[int] = None,
                 repeat: Optional[int] = None):
        super().__init__(currency=currency,
                         amounts=[amount],
                         per_days=per_days,
                         start_days=start_days,
                         end_days=end_days,
                         repeat=repeat)


class SpecifiedCashFlow(CashFlowGenerator):
    """
    Several specified cashflows on specified days in the future.
    """

    def __init__(self, currency: Currency, amount: Union[float, int, List[float]], days: List[int]):
        super().__init__(currency=currency)

        if isinstance(amount, List):
            if len(amount) != len(days):
                raise Exception("numbers of amounts and days must match in SpecifiedCashFlow")
            self._amounts = amount
        else:
            self._amounts = [amount for _ in days]
        self._days = days

    def generate_cashflows(self, date: Date, max_days: Optional[int] = None) -> List[CashFlow]:
        output = []
        for amount, days in zip(self._amounts, self._days):
            output.append(CashFlow(amount=amount, currency=self._currency, pay_date=date + days))
        return output
