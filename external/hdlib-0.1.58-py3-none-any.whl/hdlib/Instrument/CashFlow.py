from hdlib.Instrument.Instrument import Instrument
from hdlib.Core.Currency import Currency
from hdlib.DateTime.Date import Date

from typing import List, Sequence, Iterator, Optional


class CashFlow(Instrument):
    def __init__(self,
                 amount: float,
                 currency: Currency,
                 pay_date: Date,
                 name: Optional[str] = None):
        """
        Basic (deterministic) cash flow class. A known positive cashflow, at a fixed date, in a single currency
        :param amount: float, amount of cashflow denominated in the currency
        :param currency: Currency, the currency of the cashflow
        :param pay_date: Date, the payment date, when cash is actually recieved/paid
        :param name: str, name of this cashflow (if any)
        """
        super().__init__(expiry=pay_date, currency_long=currency)
        self._amount = amount
        self._name = name

    @property
    def amount(self) -> float:
        return self._amount

    @property
    def pay_date(self) -> Date:
        return self._expiry

    @property
    def currency(self) -> Currency:
        return self._currency

    @property
    def name(self) -> Optional[str]:
        return self._name

    @pay_date.setter
    def pay_date(self, new_date: Date):
        self._expiry = new_date

    # Methods to allow sorting based on Pay Date

    def __eq__(self, other: 'CashFlow'):
        return self.pay_date == other.pay_date

    def __lt__(self, other: 'CashFlow'):
        return self.pay_date < other.pay_date

    def __gt__(self, other: 'CashFlow'):
        return self.pay_date > other.pay_date

    def __ne__(self, other: 'CashFlow'):
        return self.pay_date != other.pay_date


class CashFlows(Sequence):
    """
    An iterable container of cashflows, with convenience methods.
    """
    def __init__(self, cashflows: List[CashFlow] = None, sort: bool = True, is_sorted: bool = False):
        self._cashflows = cashflows or []
        if self._cashflows:
            if sort and not is_sorted:
                self._cashflows = sorted(self._cashflows)

        self._sorted = sort or is_sorted

    @property
    def sorted(self) -> bool:
        return self._sorted

    @property
    def size(self) -> int:
        return self.__len__()

    @property
    def empty(self) -> bool:
        return self.size == 0

    def sort_and_filter(self, ref_date: Date) -> 'CashFlows':
        if self.size == 0:
            return CashFlows()

        cashflows = self._cashflows if self._sorted else sorted(self._cashflows)

        # Use the fact that it's sorted to filter efficiently
        if cashflows[0].pay_date >= ref_date:
            return CashFlows(cashflows, sort=False, is_sorted=True)

        cashflows = [cf for cf in cashflows if cf.pay_date >= ref_date]
        return CashFlows(cashflows, sort=False, is_sorted=True)

    def __next__(self):
        return next(self._cashflows)

    def __iter__(self) -> Iterator[CashFlow]:
        return iter(self._cashflows)

    def __len__(self):
        return len(self._cashflows)

    def __getitem__(self, index) -> CashFlow:
        return self._cashflows[index]


if __name__ == '__main__':
    from hdlib.Core.Currency import USDCurrency
    cfs = CashFlows([CashFlow(10, USDCurrency(), Date.today()),
                     CashFlow(50, USDCurrency(), Date.today())])

    for cf_ in cfs:
        print(cf_.pay_date)

    print(cfs[1].amount)
    print(len(cfs))
