from typing import Optional, List

from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Core.AccountInterface import AccountInterface
from hdlib.Core.FxPairInterface import FxPairInterface
from hdlib.DateTime import Date


class FxForwardInstrument:
    """
    The minimal interface for defining an Fx forward instrument.
    """

    def get_fxpair(self) -> FxPairInterface:
        raise NotImplementedError

    def get_amount(self) -> float:
        raise NotImplementedError

    # The forward price of the position (expressed as a unit price, not price of the total position).
    def get_forward_price(self) -> float:
        raise NotImplementedError

    def get_account(self) -> AccountInterface:
        raise NotImplementedError

    def get_delivery_time(self) -> Date:
        raise NotImplementedError

    def get_enter_time(self) -> Date:
        raise NotImplementedError

    def to_cashflows(self) -> List[CashFlow]:
        """
        Convert a forward into its component cashflows.
        """
        # Amount is the amount in Base, amount of quote is -forward_price * amount.
        base_amount = self.get_amount()
        quote_amount = -base_amount * self.get_forward_price()
        return [
            CashFlow(amount=base_amount, currency=self.get_fxpair().base, pay_date=self.get_delivery_time()),
            CashFlow(amount=quote_amount, currency=self.get_fxpair().quote, pay_date=self.get_delivery_time()),
        ]


class BasicFxForward(FxForwardInstrument):
    """
    A basic implementation of an FxForwardInstrument that stores all the fields.
    """

    def __init__(self,
                 fxpair: FxPairInterface,
                 amount: float,
                 forward_price: float,
                 delivery_time: Date,
                 enter_time: Date,
                 account: Optional[AccountInterface] = None):
        self.fxpair = fxpair
        self.amount = amount
        self.forward_price = forward_price
        self.delivery_time = delivery_time
        self.enter_time = enter_time
        self.account = account

    def get_fxpair(self) -> FxPairInterface:
        return self.fxpair

    def get_amount(self) -> float:
        return self.amount

    def get_forward_price(self) -> float:
        return self.forward_price

    def get_account(self) -> AccountInterface:
        return self.account

    def get_delivery_time(self) -> Date:
        return self.delivery_time

    def get_enter_time(self) -> Date:
        return self.enter_time
