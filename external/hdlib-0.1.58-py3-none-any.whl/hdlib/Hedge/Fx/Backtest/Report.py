from typing import Optional, List
import pandas as pd
import numpy as np

from hdlib.DateTime.Date import Date
from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccount

from hdlib.Hedge.Fx.HedgeAccount import (
    HedgeAccountSettings
)

import logging

logger = logging.getLogger(__name__)


class BTReport_SingleRefDate(object):
    def __init__(self,
                 start_date: Date,
                 end_date: Date,
                 num_dates: int,
                 fx_names: List[str],
                 settings: HedgeAccountSettings,
                 cash_pnl: CashPnLAccount,
                 initial_cash_fx: float,
                 num_cashflows: int):
        """ """
        self._ref_date = start_date
        self._end_date = end_date
        self._num_dates = num_dates
        self._fx_names = fx_names
        self._settings = settings
        self._cash_pnl = cash_pnl
        self._initial_cash_fx = initial_cash_fx
        self._num_cashflows = num_cashflows

    @staticmethod
    def row_header() -> List[str]:
        return ['Account', 'Domestic',
                'StartDate', 'EndDate',
                'NumDates', 'NumCurrencies', 'NumCashflows',
                'InitialCashValue', 'UnhedgedValue',
                'HedgedValue',
                'HedgePnL', 'TradeCost', 'RollCost',
                'Hedged_v_NoHedge', 'Gain_v_NoHedge',
                'Hedged_v_Initial', 'Gain_v_Initial',
                'Unhedged_v_Initial']

    def summary_row(self) -> List:
        if self._cash_pnl.hedge_position_value != 0:
            logger.warning("Summarizing date, but you didnt unwind your positions")

        final_balance = self._cash_pnl.aggregate_cash_and_future_npv
        unhedged = self._cash_pnl.future_cashflow_npv + self._cash_pnl.cashflows_received  # simply recieve the cashflows

        v_nohedge = final_balance - unhedged
        gain_v_nohedge = v_nohedge / unhedged

        v_initial = final_balance - self._initial_cash_fx
        gain_v_initial = v_initial / self._initial_cash_fx

        unhedged_v_initial = unhedged - self._initial_cash_fx
        return [self._settings.account_name, self._settings.domestic.get_mnemonic(),
                self._ref_date, self._end_date,
                self._num_dates, len(self._fx_names), self._num_cashflows,
                self._initial_cash_fx, unhedged,
                final_balance,
                self._cash_pnl.hedge_pnl, self._cash_pnl.trade_costs, self._cash_pnl.roll_costs,
                v_nohedge, gain_v_nohedge,
                v_initial, gain_v_initial,
                unhedged_v_initial]


class BTReport(object):
    """ Stylized Report, multiple ref dates """

    def __init__(self):
        self._reports: List[List] = []
        self._df: Optional[pd.DataFrame] = None

    def add_report(self, report: BTReport_SingleRefDate):
        self._reports.append(report.summary_row())

    def to_df(self) -> pd.DataFrame:
        self._df = pd.DataFrame(data=self._reports, columns=BTReport_SingleRefDate.row_header())
        return self._df

    def summary_metrics(self) -> pd.Series:
        if self._df is None:
            self.to_df()

        index = ['NumBacktestDates', 'NumDatesInHedge',
                 'UnhedgedValue-Mean',  'HedgedValue-Mean',
                 'Unhedged_v_Initial',
                 'Hedged_v_Initial',
                 'Unhedged-Vol', 'Hedged-Vol', 'Reduction-Vol',
                 'Unhedged-95th', 'Hedged-95th', 'Reduction-95th',
                 'Unhedged-Worst', 'Hedged-Worst', 'Reduction-Worst'
                 ]

        unhedged_vol = self._df['Unhedged_v_Initial'].std(axis=0)
        hedged_vol = self._df['Hedged_v_Initial'].std(axis=0)
        vol_reduction = 1 - hedged_vol / unhedged_vol

        unhedged_VaR = np.quantile(self._df['Unhedged_v_Initial'].values, 0.05)
        hedged_VaR = np.quantile(self._df['Hedged_v_Initial'].values, 0.05)
        VaR_reduction = 1 - hedged_VaR / unhedged_VaR

        unhedged_worst = np.min(self._df['Unhedged_v_Initial'].values)
        hedged_worst = np.min(self._df['Hedged_v_Initial'].values)
        worst_reduction = 1 - hedged_worst / unhedged_worst

        data = [len(self._df),
                self._df['NumDates'].mean(),
                self._df['UnhedgedValue'].mean(),
                self._df['HedgedValue'].mean(),
                self._df['Unhedged_v_Initial'].mean(),
                self._df['Hedged_v_Initial'].mean(),
                unhedged_vol, hedged_vol, vol_reduction,
                unhedged_VaR, hedged_VaR, VaR_reduction,
                unhedged_worst, hedged_worst, worst_reduction
                ]
        return pd.Series(index=index, data=data)
