from typing import List, Tuple, Optional

from hdlib.DateTime.Date import Date


class SingleScenario:
    """
    Record how the account values of a hedged account and a non-hedged account vary over a single scenario.
    """
    def __init__(self):
        self._days: List[int] = []
        self._unhedged_value_time_series = []
        self._hedged_value_time_series = []

    def add_values(self, days: int, unhedged_value: float, hedged_value: float):
        self._days.append(days)
        self._unhedged_value_time_series.append(unhedged_value)
        self._hedged_value_time_series.append(hedged_value)

    @property
    def size(self):
        return len(self._days)

    @property
    def max_days(self) -> Optional[int]:
        if len(self._days) == 0:
            return None
        return self._days[-1]

    @property
    def days(self) -> List[int]:
        return self._days

    @property
    def unhedged_ts(self) -> List[float]:
        return self._unhedged_value_time_series

    @property
    def hedged_ts(self) -> List[float]:
        return self._hedged_value_time_series


class ComparativeHistory:
    """
    Object that keeps track of the time series of the total value of hedged and unhedged accounts throughout time.
    """
    def __init__(self, ref_date: Date):
        self._ref_date = ref_date
        self._scenarios = []

    def push_new_scenario(self):
        self._scenarios.append(SingleScenario())

    def add_values_to_current_scenario(self, days: int, unhedged_value: float, hedged_value: float):
        self._scenarios[-1].add_values(days=days, unhedged_value=unhedged_value, hedged_value=hedged_value)

    def get_min_ts_length(self) -> Optional[int]:
        if len(self._scenarios) == 0:
            return None
        min_size = self._scenarios[0].size
        for scenario in self._scenarios:
            min_size = min(min_size, scenario.size)
        return min_size

    def get_min_max_days(self) -> Optional[int]:
        if len(self._scenarios) == 0:
            return None
        min_days = self._scenarios[0].max_days
        for scenario in self._scenarios:
            min_days = min(min_days, scenario.max_days)
        return min_days

    @property
    def size(self):
        return len(self._scenarios)

    def get_days_ts(self, index: int, max_days: Optional[int] = None):
        size = self._index_for_day(self._scenarios[index].days, max_days)
        return self._scenarios[index].days[:size]

    def get_hedged_ts(self, index: int, max_days: Optional[int] = None):
        size = self._index_for_day(self._scenarios[index].days, max_days)
        return self._scenarios[index].hedged_ts[:size]

    def get_unhedged_ts(self, index: int, max_days: Optional[int] = None):
        size = self._index_for_day(self._scenarios[index].days, max_days)
        return self._scenarios[index].unhedged_ts[:size]

    def get_percentile(self, percentile: float,
                       max_days: Optional[int] = None) -> Tuple[List[int], List[float], List[float]]:
        hedged_values, unhedged_values = {}, {}

        for scenario in self._scenarios:
            days = scenario.days
            hedged = scenario.hedged_ts
            unhedged = scenario.unhedged_ts

            for day, hv, uv in zip(days, hedged, unhedged):
                if max_days is None or day <= max_days:
                    if day not in hedged_values:
                        hedged_values[day], unhedged_values[day] = [], []
                    hedged_values[day].append(hv)
                    unhedged_values[day].append(uv)
        # Sort values
        days, hedged, unhedged = [], [], []
        for day, values in hedged_values.items():
            perc = int(len(values) * percentile)
            values = list(sorted(values))
            days.append(day)
            hedged.append(values[perc])
        for day, values in unhedged_values.items():
            perc = int(len(values) * percentile)
            values = list(sorted(values))
            unhedged.append(values[perc])

        days, hedged, unhedged = list(zip(*list(sorted(zip(days, hedged, unhedged)))))
        return days, hedged, unhedged

    def get_average_hedged(self,
                           max_days: Optional[int] = None) -> Tuple[List[int], List[float], List[float]]:
        """
        Returns the time series of the average of hedged scenarios on each day.
        """
        count, hvalue, uvalue = {}, {}, {}

        for scenario in self._scenarios:
            days = scenario.days
            hedged = scenario.hedged_ts
            unhedged = scenario.unhedged_ts

            for day, hv, uv in zip(days, hedged, unhedged):
                if max_days is None or day <= max_days:
                    if day not in hvalue:
                        count[day], hvalue[day], uvalue[day] = 0, 0, 0
                    count[day] += 1
                    uvalue[day] += uv
                    hvalue[day] += hv

        ave_days, ave_hedged, ave_unhedged = [], [], []
        for day, hv in hvalue.items():
            c = count[day]
            ave_days.append(day)
            ave_hedged.append(hv / c)
            ave_unhedged.append(uvalue[day] / c)

        ave_days, ave_hedged, ave_unhedged = list(zip(*list(sorted(zip(ave_days, ave_hedged, ave_unhedged)))))

        return ave_days, ave_hedged, ave_unhedged

    @staticmethod
    def _index_for_day(days: List[int], max_days: Optional[int] = None):
        if max_days is None:
            return len(days)
        index = 0
        for day in days:
            index += 1
            if max_days < day:
                return index
        return len(days) + 1
