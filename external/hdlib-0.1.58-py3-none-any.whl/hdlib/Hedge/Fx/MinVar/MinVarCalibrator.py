from typing import List, Tuple, Optional

from hdlib.Hedge.Fx.MinVar.CalibratablePositions import CalibratablePositions
from hdlib.Hedge.Fx.MinVar.Objectives import (
    MinVarianceObjective, RollCostPenalty, TradingCostPenalty, ValueAtRiskTarget, ValueAtRiskBound
)
from hdlib.Hedge.Fx.MinVar.PnLRiskCalculator import PnLRiskCalculator
from hdlib.Fit.Calibrator import Calibrator
from hdlib.Fit.Loss import SumLoss
from hdlib.Fit.Minimizer import ScipyMinimizer, OptResult
from scipy.optimize import LinearConstraint

import numpy as np


class VarReductionSummary(object):
    def __init__(self,
                 unhedged_variance: float,
                 hedged_variance: float,
                 target_reduction: float,
                 unhedged_VaR_95: float,
                 hedged_VaR_95: float):
        self.unhedged_variance = unhedged_variance
        self.hedged_variance = hedged_variance
        self.target_reduction = target_reduction

        self.unhedged_VaR_95 = unhedged_VaR_95
        self.hedged_VaR_95 = hedged_VaR_95

    @property
    def variance_reduction(self) -> float:
        return 1.0 - self.hedged_variance / self.unhedged_variance

    @property
    def unhedged_vol(self) -> float:
        return np.sqrt(self.unhedged_variance)

    @property
    def hedged_vol(self) -> float:
        return np.sqrt(self.hedged_variance)

    @property
    def volatility_reduction(self) -> float:
        return 1.0 - np.sqrt(self.hedged_variance / self.unhedged_variance)

    def __str__(self) -> str:
        return f"\nUnhedged Vol: {self.unhedged_vol:.4f}" \
               f"\nHedged Vol: {self.hedged_vol:.4f}" \
               f"\nVol Reduction Achieved: {100 * self.volatility_reduction:.3f}%" \
               f"\nVol Reduction Target: {100 * self.target_reduction:.3f}%" \
               f"\nUnhedged VaR(.95): {self.unhedged_VaR_95:.3f}" \
               f"\nHedged VaR(.95): {self.hedged_VaR_95:.3f}"


class MinVarCalibrator(object):
    def __init__(self,
                 last_positions: np.ndarray,
                 net_future_cashflows: np.ndarray,
                 forwards: np.ndarray,
                 vols: np.ndarray,
                 correlations: np.ndarray,
                 position_bounds: List[Tuple[float, float]] = None,
                 target_reduction: float = 1.0,
                 min_var_penalty_strength: float = 10):
        """
        Minimum variance calibrator to determine fx positions to minimize the variance of future realized cashflows,
        subject to constraints and cost criteria

        :param last_positions: np.ndarray, last/current set of positions in each fx pair
        :param net_future_cashflows: np.ndarray, net future cashflows corresponding to each fx pair
        :param forwards: np.ndarray, forwards at a 1-day time horizon
        :param vols: np.ndarray, annualized vols per fx pair
        :param correlations: np.ndarray, matrix of correlations between fx pairs
        :param position_bounds: List[tuple], list of position bounds (lower/upper) per fx pair
        :param target_reduction: float, the targeted risk reduction (measured by volatility/std dev), in [0, 1.]
        :param min_var_penalty_strength: float, the strength of min variance penalty
        """
        self._alpha_last = last_positions
        self._zetas = net_future_cashflows

        self._pnl_risk = PnLRiskCalculator(forwards=forwards,
                                           vols=vols,
                                           correlations=correlations,
                                           dt=1. / 252, spots=None)

        self._target_reduction = target_reduction
        self._gamma = min_var_penalty_strength

        if not position_bounds:
            position_bounds = []
            eps = 1e-03
            for zeta in net_future_cashflows:
                magnitude = 1.1 * (abs(zeta) + eps)  # Allow up to 110% of the exposure
                position_bounds.append((-magnitude, magnitude))

        self._positions = CalibratablePositions(net_cash_exposures=net_future_cashflows,
                                                alpha_bounds=position_bounds,
                                                target_reduction=target_reduction)
        self._init_calibrator()

        # The result of the latest optimization.
        self._result: Optional[OptResult] = None

    @property
    def pnl_risk_calculator(self) -> PnLRiskCalculator:
        """ Access the pnl risk calculator"""
        return self._pnl_risk

    def add_margin_budget(self,
                          margin_long: np.ndarray,
                          margin_short: np.ndarray,
                          budget: float):
        """
        Add the margin budget, with the margin cost per fx pair
        :param margin_long: np.ndarray, the long margin rates per fx pair
        :param margin_short: np.ndarray, the short margin rates per fx pair
        :param budget: float, the budget (in domestic currency) for the total margin across all
            spot fx positions in hedge
        """
        if np.any(margin_long) != 0 or np.any(margin_short) != 0:
            margins = CalibratablePositions.concat_long_short(longs=margin_long, shorts=margin_short)
            self._calibrator.add_constraint('Margin',
                                            constraint=LinearConstraint(margins, ub=budget, lb=-np.inf))

    def add_roll_costs(self,
                       costs_long: np.ndarray,
                       costs_short: np.ndarray):
        if np.any(costs_long) != 0 or np.any(costs_short) != 0:
            roll_cost_objective = RollCostPenalty(positions=self._positions,
                                                  costs_long=costs_long, costs_short=costs_short,
                                                  strength=1)
            self._calibrator.add_objective(name='RollCost', objective=roll_cost_objective)

    def add_trading_costs(self, costs: np.ndarray):
        if np.any(costs) != 0:
            trade_cost_objective = TradingCostPenalty(positions=self._positions,
                                                      alphas_last=self._alpha_last, trans_costs=costs,
                                                      strength=1)
            self._calibrator.add_objective(name='TradingCost', objective=trade_cost_objective)

    def add_value_at_risk_bound(self,
                                target_VaR: float,
                                strength_mult: float = 10,
                                q: float = 0.95,
                                override_target: bool = False,
                                days_scale: float = 1.0):
        """
        :param strength_mult: float, strength of the variance objective, in units of the variance objectives
            strength. Hence, a strength of 5 means 5 times the strength of variance objective
        """
        # TODO: rethink this "override_target" approach... all of this should be encapuslated in the calibrator,
        # not left up to the policy to enforce it
        if target_VaR > 0:
            return
        obj = ValueAtRiskBound(positions=self._positions,
                               pnl_risk=self._pnl_risk,
                               strength=self._gamma * strength_mult,
                               target_VaR=target_VaR,
                               q=q,
                               days_scale=days_scale)
        name = 'Target' if override_target else f'VaRBound({q})'
        self._calibrator.add_objective(name=name, objective=obj)

    def optimize_positions(self, include_summary: bool = False
                           ) -> Tuple[np.ndarray, Optional[VarReductionSummary], OptResult]:
        # Optimize
        self._result = self._calibrator.calibrate()

        # Return the weights (of dimension number of fx pairs)
        optimal = self._positions.get_alphas()

        if not include_summary:
            return optimal, None, self._result

        return optimal, self.summary(), self._result

    @property
    def latest_opt_result(self) -> Optional[OptResult]:
        """ Get the optimization result of last optimzation (None if never optimized before) """
        return self._result

    def summary(self) -> VarReductionSummary:
        """ Summarize the variance reduction provided by the hedge """
        return VarReductionSummary(
            unhedged_variance=self._pnl_risk.variance(weights=self._positions.net_cash_exposures),
            hedged_variance=self._pnl_risk.variance(weights=self._positions.weights),
            target_reduction=self._target_reduction,
            unhedged_VaR_95=self._pnl_risk.value_at_risk(weights=self._positions.net_cash_exposures),
            hedged_VaR_95=self._pnl_risk.value_at_risk(weights=self._positions.weights))

    # ==================
    # Private
    # ==================

    def _init_calibrator(self):
        # options = {'xtol': 1e-5, 'gtol': 1e-12, 'barrier_tol': 1e-08, 'maxiter': 300, 'verbose': 2}
        # minimizer = ScipyMinimizer(method='trust-constr', options=options)

        options = {'ftol': 1e-06, 'maxiter': 50}
        minimizer = ScipyMinimizer(method='SLSQP', options=options)
        loss = SumLoss()

        self._calibrator = Calibrator(model=self._positions, minimizer=minimizer, loss=loss)

        # Add Variance Objective
        obj = MinVarianceObjective(positions=self._positions, pnl_risk=self._pnl_risk,
                                   strength=self._gamma, target_reduction=self._target_reduction)
        self._calibrator.add_objective(name='Target', objective=obj)
