from typing import List, Tuple, Optional
from scipy.stats import norm
import numpy as np


class PnLRiskCalculator(object):
    """
    Calculates risk measures (such as Variance, Value-At-Risk) for PnL based on a correlated lognormal assumption
    of the fx pairs
    """

    def __init__(self,
                 forwards: np.ndarray,
                 vols: np.ndarray,
                 correlations: np.ndarray,
                 dt: float = 1. / 252,
                 spots: np.ndarray = None
                 ):
        self._forwards = forwards
        self._vols = vols  # NOTE: these are annualized vols, ie daily_vol / sqrt(dt)
        self._correlations = correlations
        self._dt = dt  # Risk Horizon

        self._C = self._cov()
        self._fwd_points = forwards - spots if spots is not None else None

    def variance(self, weights: np.ndarray) -> float:
        if len(weights) != self._C.shape[0]:
            raise ValueError("weights must be same dimensionality as covariance matrix")
        return float(np.dot(weights.T, np.dot(self._C, weights)))

    def std_dev(self, weights: np.ndarray) -> float:
        return np.sqrt(self.variance(weights))

    def expected_value(self, weights: np.ndarray) -> float:
        if self._fwd_points is not None:
            return float(np.dot(self._fwd_points, weights))
        return 0.

    def value_at_risk(self, weights: np.ndarray, q: float = 0.95) -> float:
        """
        Compute VaR (using a normal approximation of the PnL), which matches first two moments
        :param weights: np.ndarray, position weights in each Fx Pair
        :param q: float, confidence level (e.g. 0.95 = 95% confidence)
        :return: float, the VaR of PnL over the time horizon
        """
        variance = self.variance(weights)
        if abs(variance) < 1e-14:
            return 0
        # TODO: make optimized version where you pass in the precalculated quantile, then just shift and
        # scale it (for use by optimizer)
        return norm.ppf(1 - q,
                        loc=self.expected_value(weights),
                        scale=np.sqrt(variance))

    def expected_shortfall(self, weights: np.ndarray, q: float = 0.95) -> float:
        std_dev = self.std_dev(weights)
        mean = self.expected_value(weights)
        return mean + std_dev * norm.pdf(norm.ppf(q)) / 1 - q

    # =================
    # Private
    # =================

    def _cov(self) -> np.ndarray:
        N = len(self._vols)
        dt = self._dt
        M = np.ndarray(shape=(N, N))
        for i in range(N):
            Fi = self._forwards[i]
            vi = self._vols[i]
            for j in range(N):
                Fj = self._forwards[j]
                vj = self._vols[j]
                M[i, j] = Fi * Fj * np.expm1(self._correlations[i, j] * vi * vj * dt)
                # M[i, j] = Fi * Fj * (np.exp(self._correlations[i, j] * vi * vj * dt) - 1.)

        return M
