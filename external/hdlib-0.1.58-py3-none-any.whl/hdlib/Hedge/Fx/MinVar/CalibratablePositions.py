from typing import List, Tuple, Optional
import numpy as np

from hdlib.Fit.Calibratable import Calibratable


class CalibratablePositions(Calibratable):
    def __init__(self, net_cash_exposures: np.ndarray, alpha_bounds: List[Tuple], target_reduction: float = 1.0):
        """
        Calibratable positions - serves as the control variables / parameters to be optimized over
        during the constrained min variance calibration
        :param net_cash_exposures: np.ndarray, the net cash exposures in each currency
        :param alpha_bounds: List[Tuple], each tuple corresponds to one Fx_pair, the (upper, lower) bound
            for alpha
        """
        # In space of alphas, ie the actual positions, one per fx
        self._net_cash_exposures = net_cash_exposures
        self._alphas = np.zeros_like(net_cash_exposures)
        self._weights = np.zeros_like(net_cash_exposures)

        # In space of alpha_+, alpha-, the optimization parameters
        self._guess = np.zeros(2 * len(alpha_bounds))
        self._params = np.zeros_like(self._guess)
        self._param_bounds = []

        # each alpha maps to alpha_+, alpha_-
        for i in range(len(alpha_bounds)):
            min_, max_ = alpha_bounds[i]
            if min_ >= 0 or max_ <= 0:
                raise ValueError("Your param bounds must cover a range around 0")
            self._param_bounds.append((0, max_))  # alpha_+
            self._param_bounds.append((0, -min_))  # alpha_-

            if net_cash_exposures[i] < 0:
                # Go long for negative cashflows
                self._guess[2 * i] = min(target_reduction * abs(net_cash_exposures[i]), 0.98 * max_)
            else:
                # Go short for positive cashflow
                self._guess[2 * i + 1] = max(target_reduction * abs(net_cash_exposures[i]), 0.98 * min_)

    @property
    def size(self) -> int:
        return len(self._net_cash_exposures)

    @property
    def net_cash_exposures(self) -> np.ndarray:
        return self._net_cash_exposures

    @property
    def weights(self) -> np.ndarray:
        """ Returns the combined weights, w_j, includes alpha hedge plus cashflows """
        return self._weights

    def calc_coverage(self, trivial_thresh: float = 0.01) -> np.ndarray:
        return np.where(np.abs(self._net_cash_exposures) > trivial_thresh, -self._alphas / self.net_cash_exposures, 1)

    def get_alphas(self) -> np.ndarray:
        """ Returns the actual hedge positions, alpha = alpha(+) - alpha(-)"""
        return self._alphas

    @staticmethod
    def concat_long_short(longs: np.ndarray, shorts: np.ndarray) -> np.ndarray:
        """
        Convenience method to concatenate long/short arrays into an array of twice this size,
        which alternates between long and short for each fx_pair
        """
        if len(longs) != len(shorts):
            raise ValueError("Long/short inputs of different size")

        out = np.zeros(2 * len(longs))
        for i in range(len(longs)):
            out[2 * i] = longs[i]
            out[2 * i + 1] = shorts[i]

        return out

    # ==============================
    # Calibratable Interface
    # ==============================

    def num_params(self) -> int:
        return len(self._param_bounds)

    def set_params(self, params: np.ndarray):
        """
        Sets the parameters in calibratable
        :param params: np.array, the new parameters
        :return: self
        """
        self._params = params
        self._alphas = self._params[:-1:2] - self._params[1::2]
        self._weights = self._alphas + self._net_cash_exposures
        return self

    def get_params(self) -> np.ndarray:
        """
        Get the current set of params.
        Note: set params
        :return: np.array, current parameters
        """
        return self._params

    def default_params(self) -> Optional[np.ndarray]:
        return self._guess

    def param_bounds(self) -> Optional[List[Tuple]]:
        """
        Theoretical parameter bounds. These dont have to be what you used during optimization, but providing reasonable
        bounds here allows a model to be fit out-of-the-box
        :return: list of tuples, upper and lower bounds on each parameter.
        """
        return self._param_bounds
