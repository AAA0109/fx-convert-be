from abc import ABC, abstractmethod
from typing import Sequence, Dict, Optional, List, Iterable, Tuple
import numpy as np
import pandas as pd
from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.DateTime.Date import Date


class HedgeCostProvider(ABC):
    """
    Provides hedge costs for a fixed set of fx_pairs
    All methods return data with the same index order as the supplied fx_names
    """
    @abstractmethod
    def get_spot_fx_transaction_costs(self,
                                      date: Date,
                                      fx_pairs: Optional[Sequence[FxPairInterface]] = None) -> pd.Series:
        """
        Get spot fx transaction costs for spot trades on the supplied date. This can include bid/ask spreads as well
        as broker commisions. E.g., Forex.com hides commissions in bid/ask spreads, while IB instead charges commision.
        In general we can assume some combination of the two
        :param date: Date, the datetime on which to get the costs
        :return: pd.Series, the costs ordered by the fx_names order of this object
        """
        # TODO: we are double counting the spreads and commisions when assessing hedge costs, we need to
        # split these out, since trading pnl already accounts for spreads
        raise NotImplementedError

    @abstractmethod
    def get_spot_fx_margin_rates(self,
                                 date: Date,
                                 fx_pairs: Optional[Sequence[FxPairInterface]] = None) -> pd.Series:
        """
        Get spot fx margin rates (assumed same rates apply to long/short). These rates are in [0,1]
        :param date: Date, the datetime on which to get the costs
        :return: pd.Series, the rates ordered by the fx_names order of this object
        """
        raise NotImplementedError

    @abstractmethod
    def get_spot_fx_roll_rates(self,
                               date: Date,
                               fx_pairs: Optional[Sequence[FxPairInterface]] = None) -> Tuple[pd.Series, pd.Series]:
        """
        Get Long / short Position Roll Rates.
        Note that a positive long roll rate is a gain to the long position.
        Note that a positive short roll rate is a gain to the short position.
        """
        raise NotImplementedError


class HedgeCostProvider_Const(HedgeCostProvider):
    """
    Hedge cost provider with constant costs over time, useful for testing.
    """
    def __init__(self,
                 fx_pairs: List[FxPairInterface],
                 margin_rates: Optional[Sequence[float]] = None,
                 roll_rates_long: Optional[Sequence[float]] = None,
                 roll_rates_short: Optional[Sequence[float]] = None,
                 transaction_costs: Optional[Sequence[float]] = None):

        self._margin_rates = self._make_series(index=fx_pairs, data=margin_rates)
        self._roll_rates_long = self._make_series(index=fx_pairs, data=roll_rates_long)
        self._roll_rates_short = self._make_series(index=fx_pairs, data=roll_rates_short)
        self._transaction_costs = self._make_series(index=fx_pairs, data=transaction_costs)

    def get_spot_fx_transaction_costs(self,
                                      date: Date,
                                      fx_pairs: Optional[Sequence[FxPairInterface]] = None) -> pd.Series:
        if fx_pairs is None:
            return self._transaction_costs
        return self._transaction_costs[fx_pairs]

    def get_spot_fx_margin_rates(self,
                                 date: Date,
                                 fx_pairs: Optional[Sequence[FxPairInterface]] = None) -> pd.Series:
        if fx_pairs is None:
            return self._margin_rates
        return self._margin_rates[fx_pairs]

    def get_spot_fx_roll_rates(self,
                               date: Date,
                               fx_pairs: Optional[Sequence[FxPairInterface]] = None) -> Tuple[pd.Series, pd.Series]:
        if fx_pairs is None:
            return self._roll_rates_long, self._roll_rates_short
        return self._roll_rates_long[fx_pairs], self._roll_rates_short[fx_pairs]

    @staticmethod
    def _make_series(index: List[FxPairInterface], data: Optional[np.ndarray]) -> pd.Series:
        return pd.Series(index=index,
                         data=data if data is not None else np.zeros(len(index)))
