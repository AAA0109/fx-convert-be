from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD
from hdlib.Core.FxPair import FxPair
from hdlib.DateTime.Date import Date

from typing import Dict
import pandas as pd

from abc import ABC, abstractmethod


class CostOfFxHedge(ABC):
    """
    Calculator for the cost of the hedging strategy based on actions taken... e.g. we are charged 1% per date
    for currency held
    """

    def __init__(self, dc: DayCounter = DayCounter_HD()):
        self._dc = dc

    def __call__(self, fx_positions: pd.Series) -> float:
        """
        Calculate the full cost of a time series of fx balances
        :param fx_positions: pd.Series, a series with date index, and values equal to the fx balance held at end of
                           each date (how much is rolled over to the next date)
        :return: float, the aggregate cost over time for carrying this fx_balance
        """
        cost = 0

        for i in range(len(fx_positions) - 1):
            cost += self.roll_cost(amount=fx_positions.values[i],
                                   start=fx_positions.index[i], end=fx_positions.index[i + 1])

        # NOTE: assumes only one day of roll at the end
        cost += self.roll_cost(amount=fx_positions.values[-1],
                               start=fx_positions.index[-1],
                               end=Date.from_datetime_date(fx_positions.index[-1]) + 1)
        return cost

    @abstractmethod
    def roll_cost(self, amount: float, start: Date, end: Date) -> float:
        """
        Calculates the cost to roll an Fx balance forward between two dates (inclusive)
        :param amount: float, the amount of fx balance to roll forward
        :param start: Date, the starting date
        :param end: Date, the ending date
        :return: float, the roll cost of carrying the fx between start and end date
        """
        raise NotImplementedError


class NoCostOfFxHedge(CostOfFxHedge):
    """
    A zero cost of currency hedge. This cost will always return zero, regardless of the action sequence.
    Useful for testing, but not realistic
    """

    def __call__(self,
                 fx_positions: pd.Series) -> float:
        return 0.

    def roll_cost(self, amount: float, start: Date, end: Date) -> float:
        return 0


class FixedDailyRateCostOfFxHedge(CostOfFxHedge):
    """
     A daily compounding Fixed rate cost of hedge. B/c we are short the foreign currency,
     the cost is assessed on the foreign amount, ie how much foreign are we converting into domestic
     """

    def __init__(self,
                 long_rate: float,
                 short_rate: float,
                 dc: DayCounter = DayCounter_HD()):
        super().__init__(dc=dc)

        yf = self._dc.year_fraction_from_days(1)
        self._daily_long_rate = long_rate * yf
        self._daily_short_rate = short_rate * yf

    def roll_cost(self, amount: float, start: Date, end: Date) -> float:
        n_days = self._dc.days_between(start=start, end=end)
        rate = self._daily_long_rate if amount > 0 else self._daily_short_rate
        return abs(amount) * ((1 + rate) ** n_days - 1)


class CostOfMultiFxHedge(ABC):

    @abstractmethod
    def roll_cost(self, amount: float, fx_pair: FxPair, start: Date, end: Date) -> float:
        raise NotImplementedError

    @abstractmethod
    def cost_for_fx_pair(self, fx_pair: FxPair, position: pd.Series) -> float:
        raise NotImplementedError

    def __call__(self,
                 balances: Dict[FxPair, pd.Series]) -> float:
        cost = 0
        for pair, balance in balances.items():
            cost += self.cost_for_fx_pair(fx_pair=pair, position=balance)

        return cost


class NoCostOfMultiFxHedge(CostOfMultiFxHedge):

    def roll_cost(self, amount: float, fx_pair: FxPair, start: Date, end: Date) -> float:
        return 0.

    def cost_for_fx_pair(self, fx_pair: FxPair, position: pd.Series) -> float:
        return 0.

    def __call__(self,
                 balances: Dict[FxPair, pd.Series]) -> float:
        return 0.


class CostOfMultiOneFxHedge(CostOfMultiFxHedge):
    def __init__(self, costs: Dict[FxPair, CostOfFxHedge]):
        self._costs = costs

    def roll_cost(self, amount: float, fx_pair: FxPair, start: Date, end: Date) -> float:
        return self._costs[fx_pair].roll_cost(amount=amount, start=start, end=end)

    def cost_for_fx_pair(self, fx_pair: FxPair, position: pd.Series) -> float:
        return self._costs[fx_pair](position)

