from abc import ABC, abstractmethod
import numpy as np

from hdlib.Hedge.Fx.Fill.FxOrderState import FxOrderFlowState
from hdlib.DateTime.DayCounter import DayCounter, Date
from hdlib.DataProvider.Fx.FxSpotProvider import FxSpotProvider
from hdlib.DataProvider.Fx.FxVolProvider import FxVolProvider


class OneFxRiskBudget(ABC):
    """
    Base class for a "Risk Budget". This class is able to inspect an order state, and determine if the current level
    of risk exposure exceeds some budget. It is able to check date by date, to re-assess the situation, and provide
    the amount of action to take to bring the risk level back to an acceptable tolerance
    """

    @abstractmethod
    def budget_excess(self, date: Date, order_state: FxOrderFlowState) -> float:
        """
        Compute the "excess" amount of risk over the prescribed budget. The excess is expressed in units of foreign
        currency (consistent with the order state). This correpsonds to a conversion order that should be placed to
        eliminate the excess risk.
        :param date: Date, the current date on which to assess if the budget is exceeded
        :param order_state: CurrencyOrderState, the current state of a currency order, as of the latest update
        :return: float, the budget excess in units of foreign currency. By converting this amount of currency,
        you will meet the acceptable risk threshold
        """
        raise NotImplementedError

    def is_over_budget(self, date: Date, order_state: FxOrderFlowState) -> bool:
        """ Check if the existing order state exceeds the risk budget """
        return self.budget_excess(date=date, order_state=order_state) > 0


class NoRiskBudget(OneFxRiskBudget):
    """
    A dummy RiskBudget. Whenever asked if we have excess risk, it will say no
    """

    def budget_excess(self, date: Date, order_state: FxOrderFlowState) -> float:
        return 0.


class OneFxRelativeRiskBudget(OneFxRiskBudget):
    def __init__(self,
                 portion_at_risk: float):
        """ Portion of the original order """
        self._portion_at_risk = portion_at_risk

    def budget_excess(self, date: Date, order_state: FxOrderFlowState) -> float:
        remains = order_state.net_remain_to_fill
        if remains <= 0:
            return 0

        initial_order = order_state.net_order_amount
        allowed_risk = initial_order * self._portion_at_risk
        return max(0., remains - allowed_risk)


class OneFxVolatilityRiskBudget(OneFxRiskBudget):
    def __init__(self,
                 portion_at_risk: float,
                 dc: DayCounter,
                 fx_spot_provider: FxSpotProvider,
                 fx_vol_provider: FxVolProvider,
                 vol_mult: float = 1):
        """ Portion of the original order """
        self._portion_at_risk = portion_at_risk
        self._dc = dc
        self._fx_spot_provider = fx_spot_provider
        self._fx_vol_provider = fx_vol_provider
        self._vol_mult = vol_mult

    def budget_excess(self, date: Date, order_state: FxOrderFlowState) -> float:
        remains = order_state.net_remain_to_fill
        if remains <= 0:
            return 0

        daily_vol = self._fx_vol_provider.fx_spot_vol(date=date, fx_pair=order_state.fx_pair)
        daily_vol = daily_vol / np.sqrt(self._dc.year_fraction_from_days(1))

        vol_fx = daily_vol * np.sqrt(self._dc.year_fraction(start=date, end=order_state.final_due_date))

        # Compute FX amount based on original order size
        spot = self._fx_spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)
        fx_amount = order_state.net_order_amount * spot

        allowed_risk = fx_amount * self._portion_at_risk
        # remains_risk = remains * vol_fx * self._vol_mult
        excess = remains - allowed_risk / (vol_fx * self._vol_mult)
        return max(0., excess)


