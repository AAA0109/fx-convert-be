import numpy as np
from typing import Dict

from hdlib.Hedge.Fx.Fill.OneFxPolicy import OneFxPolicy
from hdlib.Hedge.Fx.Fill.MultiFxPolicy import MultiFxPolicy, MultiFxOrderFlowState
from hdlib.DateTime.Date import Date
from hdlib.DateTime.DayCounter import DayCounter
from hdlib.Core.FxPair import FxPair

from hdlib.Hedge.Fx.Fill.Action import FxHedgeAction
from hdlib.Hedge.Fx.Fill.FxOrderState import FxOrderFlowState
from hdlib.Hedge.Fx.Fill.Cost import CostOfFxHedge

from hdlib.DataProvider.Fx.FxSpotProvider import FxSpotProvider
from hdlib.DataProvider.Fx.FxVolProvider import FxVolProvider
from hdlib.Universe.Historical.HistUniverseProvider import HistUniverseProvider


class MinVarFxPolicy(MultiFxPolicy):
    def __init__(self,
                 cost: CostOfFxHedge,
                 dc: DayCounter,
                 u_provider: HistUniverseProvider,
                 max_daily_roll_cost: float,
                 gamma: float
                 ):
        super().__init__(name="MinVarOneFxPolicy")
        self._cost = cost
        self._max_cost = max_daily_roll_cost

        self._dc = dc
        self._u_provider = u_provider
        self._gamma = gamma

    def actions(self, date: Date, order_state: MultiFxOrderFlowState) -> Dict[FxPair, FxHedgeAction]:
        """
        Perform a sequence hedging actions (how much to buy/sell) in accordance with the policy,
        given the states on this date. There is one action corresponding to each FxPair
        The action also updates the state
        :param date: Date, the date on which to perform the action (corresponds to "now")
        :param order_state: MultiFxOrderFlowState, the current state of each FxPair,
                tracks how much remains to purchase for each FxPair
        :return:
        """
        raise NotImplementedError


class MinVarOneFxPolicy(OneFxPolicy):
    def __init__(self,
                 cost: CostOfFxHedge,
                 dc: DayCounter,
                 fx_spot_provider: FxSpotProvider,
                 fx_vol_provider: FxVolProvider,
                 max_daily_roll_cost: float,
                 gamma: float):
        """
        Policy .....

        :param cost: CostOfFxHedge, used to assess roll cost of current fx_balance
        :param max_daily_roll_cost: float, the maximum allowed daily roll cost
        """
        super().__init__(name="MinVarOneFxPolicy")
        self._cost = cost
        self._max_cost = max_daily_roll_cost

        self._dc = dc
        self._fx_spot_provider = fx_spot_provider
        self._fx_vol_provider = fx_vol_provider
        # self._discount = discount

        self._gamma = gamma

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        """"""
        date = Date.from_datetime_date(date=date)
        order_state.date = date

        vol = self._fx_vol_provider.fx_spot_vol(date=date, fx_pair=order_state.fx_pair)
        # DO: need to hook up a fx_forward_provider
        fwd = self._fx_spot_provider.fx_spot(date=date, fx_pair=order_state.fx_pair)

        # DO: need to discount the cashflows, for now just summing them
        # NOTE: we arent hedging anything that is due today
        net_fx = np.sum([order.amount for order in order_state.orders if order.due_date > date])

        dx = self._dc.year_fraction(date, date + 1)
        lam_var = fwd ** 2 * (np.exp(vol ** 2 * dx) - 1)

        cost_per_unit = self._cost.roll_cost(amount=np.sign(net_fx), start=date, end=Date.from_datetime_date(date) + 1)
        if net_fx > 0:
            alpha_minus = -cost_per_unit / (2 * self._gamma * lam_var) + net_fx
            desired_position = min(-alpha_minus, 0)
        else:
            alpha_plus = - cost_per_unit / (2 * self._gamma * lam_var) - net_fx
            desired_position = max(alpha_plus, 0)

        # DO: come up with unified formula (one liner) using sign(), update doc, make it a theorem

        # DO: incorporate the Max cost

        # Compare current (net) hedge to where we should be, adjust as needed
        current_position = order_state.fx_position

        adjustment = desired_position - current_position
        return FxHedgeAction.buy_sell_or_hold(date=date, amount=adjustment, fx_pair=order_state.fx_pair)
