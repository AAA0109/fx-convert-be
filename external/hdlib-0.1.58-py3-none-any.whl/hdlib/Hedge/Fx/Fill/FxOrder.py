from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair
from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Core.Currency import Currency


class FxOrder(object):
    def __init__(self,
                 order_date: Date,
                 due_date: Date,
                 amount: float,
                 domestic_currency: Currency,
                 foreign_currency: Currency):
        """
        An order to purchase a given amount of a domestic currency, by selling a foreign currency (ie,
        an order to "gradually" purchase the foreign/domestic pair.
        Ie, this is an order to convert some amount of:
            foreign -> domestic,
        :param order_date: Date, the date on which the order is placed
        :param due_date: Date, the last date on which a trade can be made
        :param amount: float, the amount of domestic currency to purchase by selling foreign currency
        :param domestic_currency: Currency, the domestic currency (that we want to buy)
        :param foreign_currency: Currency, the foreign currency (that we want to sell)
        """
        self.order_date = order_date
        self.due_date = due_date
        self.amount = amount
        self.domestic_currency = domestic_currency
        self.foreign_currency = foreign_currency

        # The long Fx Exposure
        self.fx_pair = FxPair(base=foreign_currency, quote=domestic_currency)

    @classmethod
    def from_cashflow(cls,
                      order_date: Date,
                      domestic_currency: Currency,
                      cashflow: CashFlow) -> 'FxOrder':
        return cls(order_date=order_date,
                   domestic_currency=domestic_currency,
                   foreign_currency=cashflow.currency,
                   amount=cashflow.amount,
                   due_date=cashflow.pay_date)
