from hdlib.Core.Currency import Currency
from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair
from hdlib.Hedge.Fx.Fill.FxOrderState import FxOrderFlowState
from hdlib.Instrument.CashFlow import CashFlow

import pandas as pd
from typing import Sequence, Optional, Dict, Iterable


class MultiFxOrderFlowState(object):
    def __init__(self, fx_states: Dict[FxPair, FxOrderFlowState]):
        self._fx_states = fx_states

    @property
    def fx_pairs(self) -> Iterable[FxPair]:
        return self._fx_states.keys()

    @property
    def fx_states(self) -> Dict[FxPair, FxOrderFlowState]:
        return self._fx_states

    def get_state(self, fx_pair: FxPair) -> Optional[FxOrderFlowState]:
        return self._fx_states.get(fx_pair, None)

    def finalize_states(self):
        for _, state in self._fx_states.items():
            state.finalize_state()

    def fx_positions(self) -> pd.Series:
        return pd.Series(index=[pair.name for pair in self.fx_pairs],
                         data=[state.fx_position for pair, state in self._fx_states.items()])

    @classmethod
    def from_cashflows_by_currency(cls,
                                   order_date: Date,
                                   domestic: Currency,
                                   cashflows: Dict[Currency, Sequence[CashFlow]],
                                   prevent_overfill: bool = True
                                   ) -> 'MultiFxOrderFlowState':

        fx_states: Dict[FxPair, FxOrderFlowState] = {}
        for currency, flows in cashflows.items():
            fx_pair = FxPair(currency, domestic)
            fx_states[fx_pair] = FxOrderFlowState.from_cashflows(order_date=order_date,
                                                                 domestic=domestic, cashflows=flows,
                                                                 prevent_overfill=prevent_overfill)
        return MultiFxOrderFlowState(fx_states=fx_states)

    # @classmethod
    # def from_cashflows(cls, cashflows: Sequence[CashFlow]) -> 'MultiFxOrderFlowState':
    #     # Determine unique currencies
    #     currencies = set()
    #     for cashflow in cashflows:
    #         currencies.add(cashflow.currency)
    #
    #     for currency in currencies:


