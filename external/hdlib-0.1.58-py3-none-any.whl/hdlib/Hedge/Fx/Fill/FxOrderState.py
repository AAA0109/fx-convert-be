from hdlib.Core.Currency import Currency
from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair
from hdlib.Hedge.Fx.Fill.FxOrder import FxOrder
from hdlib.Hedge.Fx.Fill.Action import FxHedgeAction

from typing import Sequence, Optional, List

from hdlib.Instrument.CashFlow import CashFlow


class FxOrderState(object):
    def __init__(self,
                 order: FxOrder,
                 prevent_overfill: bool = True,
                 hard_fail: bool = False):
        """
        Tracks the current state of a currency hedge/conversion request
        :param order: CurrencyOrder, an order to convert some foreign currency into domestic
        :param prevent_overfill: bool, if true, an exception is raised if you fill more than needed
        """
        self.order = order
        self.date = order.order_date  # Maintains the date associated with the lastest currency order state
        self.remain_to_fill = order.amount

        self._hard_fail = hard_fail
        self._prevent_overfill = prevent_overfill

    @property
    def fx_pair(self) -> FxPair:
        return self.order.fx_pair

    @property
    def due_date(self) -> Date:
        return self.order.due_date

    @property
    def is_filled(self) -> bool:
        """ Has the order already been filled """
        return abs(self.remain_to_fill) <= 1e-08

    @property
    def is_overfilled(self) -> bool:
        """ Check if you bought too much currency """
        return self.remain_to_fill < 0

    def update_state(self, action: FxHedgeAction) -> bool:
        """
        Update the order state given the latest action
        :param action: CurrencyHedgeAction, an action which alters the current order state
        :return: bool, indicator of whether or not the order is completely filled following this update
        """
        if action.date < self.date:
            raise ValueError("Your hedge action must be at a date on or after the latest state update date")

        if action.date > self.due_date:
            raise ValueError("You cannot act after the due date")

        if action.amount > self.remain_to_fill and self._prevent_overfill:
            if self._hard_fail:
                raise ValueError("You have acted too much!")
            else:
                action.amount = self.remain_to_fill

        self.date = action.date
        self.remain_to_fill -= action.amount
        return self.is_filled

    def fill_remaining(self, date: Date) -> float:
        """
        Fill whatever remains unfilled from the order. Returns the fill amount. This can be negative, if you
        overfilled
        """
        remaining = self.remain_to_fill
        if not self.is_filled:
            self.update_state(action=FxHedgeAction.buy_or_sell(date=date, amount=remaining, fx_pair=self.fx_pair))
        else:
            self.update_state(action=FxHedgeAction.hold(date=date, fx_pair=self.fx_pair))
        return remaining


class FxOrderFlowState(object):
    """ Manages multiple orders of a single currency"""

    def __init__(self,
                 fx_pair: FxPair,
                 orders: Sequence[FxOrder],
                 prevent_overfill: bool = True,
                 do_fill: bool = True,
                 fx_position: float = 0.):
        """"""
        # Assumption: orders are sorted,
        self._orders = orders
        self._fx_pair = fx_pair
        self._date = orders[0].order_date  # Maintains the date associated with the lastest currency order state
        self._final_order_due = orders[-1].due_date

        self._order_states: List[FxOrderState] = []

        self._fx_position: float = fx_position  # Balance of fx purchases that have not yet been assigned to an order
        self._net_remain_to_fill: float = 0.

        self._prevent_overfill = prevent_overfill
        self._do_fill = do_fill

        # Keep track of the next order that needs to be filled, and if you fill it increment
        self._next_order_to_fill_index = 0

        self._net_order_amount: float = 0.

        # Initialize the state
        self._initialize(fx_pair=fx_pair, orders=orders)

    def _initialize(self, fx_pair: FxPair, orders: Sequence[FxOrder]):

        for order in orders:
            if order.fx_pair != fx_pair:
                raise ValueError("Wrong Fx Pair")

            self._order_states.append(FxOrderState(order=order, prevent_overfill=self._prevent_overfill))
            if self._do_fill:
                self._net_remain_to_fill += order.amount

        self._net_order_amount = self._net_remain_to_fill

    @property
    def fx_pair(self) -> FxPair:
        return self._fx_pair

    @property
    def final_due_date(self) -> Date:
        return self._final_order_due

    @property
    def num_cashflows(self) -> int:
        return len(self._order_states)

    @property
    def orders(self) -> Sequence[FxOrder]:
        return self._orders

    @property
    def prevent_overfill(self) -> bool:
        return self._prevent_overfill

    @property
    def next_order_to_fill(self) -> FxOrder:
        return self._order_states[self._next_order_to_fill_index].order

    def get_unfilled_orders(self) -> Sequence[FxOrderState]:
        return self._order_states[self._next_order_to_fill_index:]

    @property
    def fx_position(self) -> float:
        """ Tracks the current FX position """
        return self._fx_position

    @property
    def net_order_amount(self) -> float:
        return self._net_order_amount

    @property
    def net_remain_to_fill(self) -> float:
        return self._net_remain_to_fill

    @property
    def is_net_filled(self) -> bool:
        """ Has the order already been filled """
        return abs(self._net_remain_to_fill) <= 1e-08

    def update_state(self, action: FxHedgeAction):
        """
        Update the order state given the latest action
        :param action: CurrencyHedgeAction, an action which alters the current order state
        :return: bool, indicator of whether or not the order is completely filled following this update
        """
        if action.date < self._date:
            raise ValueError("Your hedge action must be at a date on or after the latest state update date")

        if action.date > self._final_order_due:
            raise ValueError(
                "You cannot act after the final order due date")

        if self._do_fill:  # In case of filling (rather than hedging)
            if self._prevent_overfill:
                if (self._net_remain_to_fill > 0 and (action.amount > self._net_remain_to_fill)) or \
                        (self._net_remain_to_fill < 0 and (action.amount < self._net_remain_to_fill)):
                    action.amount = self._net_remain_to_fill

            self._net_remain_to_fill -= action.amount

        self._fx_position += action.amount
        self._date = action.date

    def finalize_state(self):
        """
        Call this method at the end of a date when the objective is to fill orders.
        Ensures that everything is tidied up at end of date, adjust action as needed
        """

        next_order = self._order_states[self._next_order_to_fill_index]
        if self._date >= next_order.due_date:
            if self._do_fill:
                # In the case our objective is to fill order
                remaining = next_order.fill_remaining(date=self._date)

                # Consume the balance to fill this order
                self._fx_position -= remaining

            if self._next_order_to_fill_index < self.num_cashflows - 1:
                self._next_order_to_fill_index += 1

        return

    @classmethod
    def from_cashflows(cls,
                       order_date: Date,
                       domestic: Currency,
                       cashflows: Sequence[CashFlow],
                       filter_currency: Optional[Currency] = None,
                       prevent_overfill: bool = True,
                       do_fill: bool = True) -> 'FxOrderFlowState':
        """"""
        if isinstance(cashflows, CashFlow):
            cashflows = [cashflows]

        foreign_currency = filter_currency or cashflows[0].currency
        fx_pair = FxPair(foreign_currency, domestic)
        orders = []
        for cashflow in cashflows:
            if cashflow.currency != fx_pair.base:
                if filter_currency:
                    continue
                raise ValueError("No filter currency supplied and the orders have different currencies!")
            orders.append(
                FxOrder.from_cashflow(order_date=order_date, domestic_currency=domestic, cashflow=cashflow))

        order_state = FxOrderFlowState(fx_pair=fx_pair, orders=orders,
                                       prevent_overfill=prevent_overfill, do_fill=do_fill)
        return order_state
