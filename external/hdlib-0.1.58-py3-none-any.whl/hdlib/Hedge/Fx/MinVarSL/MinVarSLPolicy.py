import pandas as pd
import numpy as np

from hdlib.Hedge.Fx.MinVar.MinVarCalibrator import MinVarCalibrator
from hdlib.Hedge.Fx.HedgeAccount import HedgeAccountSettings
from hdlib.Hedge.Fx.HedgeCostProvider import HedgeCostProvider
from hdlib.Hedge.Fx.Policy import Policy, CashExposures, Universe, PolicySummary
from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccountHistoryProvider, CashPnLAccount
from hdlib.DateTime.Date import Date

from hdlib.MLTools.Features import Features


class FeatureProvider(object):
    def __init__(self):
        pass

    def get_features_for_date(self,
                              positions: pd.Series,
                              cash_exposures: CashExposures,
                              universe: Universe) -> np.ndarray:
        # TODO: something better

        names = cash_exposures.fx_names
        spots = universe.fx_universe.fx_assets.get_fx_spots(names=names)
        vols = universe.fx_universe.fx_vols.vols_spots(names=names)
        corrs = universe.fx_universe.fx_corrs.instant_fx_spot_corr_matrix(pairs=names)

        exposures = cash_exposures.net_exposures()
        zetas = exposures.values

        X = np.hstack((zetas, spots.values, vols.values, corrs.values))
        return X


class MinVarSLPolicy(Policy):
    """
    Constrained minimum variance policy, which optimizes between objective to reduce variance and balance costs
    of fx positions and trade costs, with margin constraints, etc.
    """

    def __init__(self,
                 settings: HedgeAccountSettings,
                 name: str = 'MinVarSL'):
        super().__init__(name=name, settings=settings)

        self._vol_reduction_target = self._settings.custom_settings.get('VolTargetReduction', 1.0)

        self._max_VaR95_exposure_percent = self._settings.custom_settings.get('VaR95ExposureRatio', 1.0)
        self._max_VaR95_exposure_days = self._settings.custom_settings.get('VaR95ExposureWindow', None)

        self._feature_provider = FeatureProvider()  # TODO: pull from db or something
        self._is_trained = False

    def new_positions(self,
                      positions: pd.Series,
                      cash_exposures: CashExposures,
                      universe: Universe,
                      account_history_provider: CashPnLAccountHistoryProvider,
                      cost_provider: HedgeCostProvider) -> PolicySummary:
        if not self._is_trained:
            raise RuntimeError("The policy has not been trained!")

        date = universe.ref_date
        exposures = cash_exposures.net_exposures()
        zetas = exposures.values

        # In case where we no longer have any real exposure
        if np.sum(np.abs(zetas)) < 1e-05:
            return PolicySummary(pd.Series(data=np.zeros_like(zetas), index=exposures.index))

        raise NotImplementedError

    def fit(self, X: np.ndarray, y: np.ndarray) -> 'MinVarSLPolicy':
        # TODO:
        pass
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        raise NotImplementedError
