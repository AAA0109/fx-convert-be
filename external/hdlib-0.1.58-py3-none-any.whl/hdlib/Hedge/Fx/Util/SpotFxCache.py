from abc import abstractmethod

from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair
from hdlib.DateTime.Date import Date
from hdlib.Hedge.Cash.CashPositions import VirtualFxPosition
from hdlib.Instrument.CashFlow import CashFlow

import numpy as np

from typing import Dict, Union, Optional, Any, Iterable, Tuple

Duck = Any
FxPairName = str


# TODO: add unit tests

class SpotFxCache:
    def __init__(self, ref_date: Date):
        """ Create a SpotFxCache, setting the reference date. """
        self._ref_date = ref_date

    @property
    def time(self) -> Date:
        return self._ref_date

    @property
    def date(self) -> Date:
        """ NOTE: Use time() instead. It is a full time, not just a date. """
        return self.time

    @abstractmethod
    def get_fx(self, fx_pair: Union[FxPairInterface, FxPairName], value_if_missing: float = None) -> Optional[float]:
        """ Get the Fx spot rate conversion rate. """
        raise NotImplementedError

    @abstractmethod
    def has_fx(self, fx_pair: Union[FxPairInterface, FxPairName]):
        """ Check if the spot map has a non-None entry for this spot. """
        raise NotImplementedError

    def convert_value(self, value: float, from_currency: Currency, to_currency: Currency) -> float:
        """ Convert a value in a base currency into its value in a quote currency """
        if from_currency == to_currency:
            return value
        fx_pair = FxPair(base=from_currency, quote=to_currency)
        fx_spot = self.get_fx(fx_pair=fx_pair)
        if fx_spot is None:
            return np.nan
        return value * fx_spot

    def position_value(self,
                       fx_position: Union[VirtualFxPosition, Duck],
                       currency: Optional[Currency] = None) -> Optional[float]:
        """
        Returns, if possible, the value of an FxPosition in either the specified currency, or the quote currency.
        :param currency: Currency, convert all values to the currency, if supplied
        :param fx_position: FxPosition (hd dashboard), the Fx position.
        """
        fxpair = fx_position.fxpair
        value = self.get_fx(fxpair.name, None)
        if value:
            quote_value = fx_position.amount * value
            if currency:
                return self.convert_value(value=quote_value,
                                          from_currency=fxpair.quote,
                                          to_currency=currency)
            return quote_value
        return None

    def sum_cashflow_spot_values(self, cashflows: Iterable['CashFlow'], currency: Currency) -> Tuple[float, float]:
        """
        Compute sum of spot cash values and absolute values of spots for a container/iterable of cashflows,
        all converted into a common currency (with no discounting)
        :param cashflows: Iterable, a container (e.g. list or array) of cashflows
        :param currency: Currency, currency to convert cashflow into
        :return: (float, float) = (value, abs(value)), converted cashflow in the value_currency (un-discounted)
        """
        value, abs_value = 0, 0
        for cashflow in cashflows:
            px = self.convert_value(value=cashflow.amount, from_currency=cashflow.currency, to_currency=currency)
            value += px
            abs_value += np.abs(px)
        return value, abs_value


class DictSpotFxCache(SpotFxCache):
    def __init__(self,
                 date: Date,
                 spots: Dict[Union[FxPairName, FxPairInterface], float],
                 info: Optional[Dict[FxPairName, Any]] = None):
        super().__init__(ref_date=date)
        self._spots = {str(pair): value for pair, value in spots.items()}  # Make sure they are really strings.
        # Information about the fx spot, e.g. what time the spot came from, what data cut it came from, etc.
        self._info = info

    def get_fx(self, fx_pair: Union[FxPairInterface, FxPairName], value_if_missing: float = None) -> Optional[float]:
        # TODO: in future, allow triangulation to get the rate
        fx_name = str(fx_pair)
        spot = self._spots.get(fx_name, None)
        if spot:
            return spot
        spot = self._spots.get(FxPair.invert_str(fx_name), None)
        if spot is None:
            return value_if_missing

        return 1.0 / spot

    def has_fx(self, fx_pair: Union[FxPairInterface, FxPairName]):
        """ Check if the spot map has a non-None entry for this spot. """
        fx_name = str(fx_pair)
        return fx_name in self._spots and self._spots[fx_name] is not None


class DictSpotFxCacheWithSingleTriangle(DictSpotFxCache):
    def __init__(self,
                 date: Date,
                 spots: Dict[Union[FxPairName, FxPairInterface], float],
                 info: Optional[Dict[FxPairName, Any]] = None,
                 triang_currency_mnemonic: str = 'USD'):
        super().__init__(date=date, spots=spots, info=info)
        self._triang = triang_currency_mnemonic

    def get_fx(self, fx_pair: Union[FxPairInterface, FxPairName], value_if_missing: float = None) -> Optional[float]:
        # TODO: add lru cache decorator, use methodtools
        fx = super().get_fx(fx_pair=fx_pair, value_if_missing=value_if_missing)
        if fx != value_if_missing:
            return fx

        # Triangulation:   XXX/YYY = XXX/USD * USD/YYY
        first_pair, second_pair = self._get_triangulation_pairs(fx_pair)

        # First: XXX/USD
        first_fx = super().get_fx(first_pair, value_if_missing=None)

        if not first_fx:
            return value_if_missing

        # Second: USD/YYY
        second_fx = super().get_fx(second_pair, value_if_missing=None)
        if not second_fx:
            return value_if_missing

        return first_fx * second_fx

    def has_fx(self, fx_pair: Union[FxPairInterface, FxPairName]):
        """ Check if the spot map has a non-None entry for this spot. """
        if super().has_fx(fx_pair):
            return True

        first_pair, second_pair = self._get_triangulation_pairs(fx_pair)
        if super().has_fx(first_pair) and super().has_fx(second_pair):
            return True

        return False

    def _get_triangulation_pairs(self, fx_pair: Union[FxPairInterface, FxPairName]) -> Tuple[FxPair, FxPair]:
        first = FxPair.from_currency_strs(fx_pair.base.get_mnemonic(), self._triang)
        second = FxPair.from_currency_strs(self._triang, fx_pair.quote.get_mnemonic())
        return first, second
