import numpy as np
from typing import Dict, Iterable, Any, Union

from hdlib.Instrument.FxForward import FxForwardInstrument
from hdlib.DateTime.Date import Date
from hdlib.Universe import Universe
from hdlib.Hedge.Cash.CashPositions import VirtualFxPosition
from hdlib.Utils.PnLCalculator import PnLCalculator
from hdlib.Hedge.Fx.Util.SpotFxCache import SpotFxCache, FxPairName, FxPair
from hdlib.Core.Currency import Currency
from hdlib.AppUtils.log_util import get_logger, logging

logger = get_logger(level=logging.INFO)

Duck = Any


class FxPnLCalculator(PnLCalculator):
    # =================================
    # PnL Methods
    # =================================

    def calc_unrealized_pnl_of_positions(self,
                                         spot_fx_cache: SpotFxCache,
                                         positions: Iterable[Union[VirtualFxPosition, Duck]],
                                         currency: Currency) -> float:
        pnl = 0.0
        for fx_position in positions:
            if fx_position.is_empty:
                continue
            current_rate = spot_fx_cache.get_fx(fx_pair=fx_position.fxpair)
            if current_rate is None:
                return np.nan
            if np.isnan(fx_position.total_price):
                logger.warning(f"Total price of fx position id = {fx_position.id} is NaN. Unrealized PnL will be NaN.")
            val, position_currency = fx_position.unrealized_pnl(current_rate=current_rate)
            pnl += spot_fx_cache.convert_value(value=val, from_currency=position_currency,
                                               to_currency=currency)

        return pnl

    def calc_unrealized_pnl_of_fxforwards(self,
                                          fx_forwards: Iterable[FxForwardInstrument],
                                          universe: Universe,
                                          currency: Currency) -> float:
        pnl = 0.0
        for forward in fx_forwards:
            asset = universe.get_fx_asset(pair=forward.get_fxpair())
            if not asset:
                logger.warning(f"Cannot find asset for {forward.get_fxpair()}, assuming flat forward.")
                fwd_value = universe.get_fx(forward.get_fxpair())
            else:
                fwd_value = asset.fwd_curve.at_D(date=Date.from_datetime(forward.get_delivery_time()))
            val = (fwd_value - forward.get_forward_price()) * forward.get_amount()
            pnl += universe.convert_value(value=val, from_currency=forward.get_fxpair().get_quote_currency(),
                                          to_currency=currency)

        return pnl

    def calc_approximate_theta_of_fxforwards(self,
                                             fx_forwards: Iterable[FxForwardInstrument],
                                             universe: Universe,
                                             currency: Currency) -> float:
        theta = 0.0
        for forward in fx_forwards:
            asset = universe.get_fx_asset(pair=forward.get_fxpair())
            if not asset:
                logger.warning(
                    f"Cannot find asset for {forward.get_fxpair()}, assuming flat forward, therefore, no theta")
            else:
                fwd_value = asset.fwd_curve.at_D(date=Date.from_datetime(forward.get_delivery_time()))
                fwd_value_plus_one = asset.fwd_curve.at_D(date=Date.from_datetime(forward.get_delivery_time()) + 1)
                dfwd = (fwd_value_plus_one - fwd_value) * forward.get_amount()
                theta += universe.convert_value(value=dfwd, from_currency=forward.get_fxpair().get_quote_currency(),
                                                to_currency=currency)
        return theta

    def calc_realized_pnl_of_position_change(
            self,
            spot_fx_cache: SpotFxCache,
            old_positions: Dict[FxPair, Union[VirtualFxPosition, Duck]],
            new_positions: Dict[FxPair, float],
            currency: Currency) -> float:
        """
        Compute the realized PnL that would result from a change in positions
        :param spot_fx_cache: SpotFxCache, contains current spot Fx rates
        :param old_positions: dict of old VirtualFxPosition objects, which contains the average price to put
         on the old  position
        :param new_positions: dict of the new positions
        :param currency: Currency, the currency in which PnL is expressed
        :return: float, pnl
        """
        all_pairs = set(old_positions.keys())
        all_pairs.update(new_positions.keys())

        pnl = 0

        for fx_pair in all_pairs:
            old_position = old_positions.get(fx_pair, None)
            if not old_position or old_position.amount == 0:
                continue  # There is no realized PnL from new positions

            new_position_val = new_positions.get(fx_pair, 0.)

            pnl_raw = self.calc_realized_pnl(old_amount=old_position.amount,
                                             old_price_avg=old_position.average_price,
                                             new_amount=new_position_val,
                                             new_price_avg=spot_fx_cache.get_fx(fx_pair=fx_pair))
            pnl += spot_fx_cache.convert_value(value=pnl_raw, from_currency=fx_pair.quote, to_currency=currency)

        return pnl

    # =================================
    # Position Value Methods
    # =================================

    def get_position_value(self,
                           fx_cache: SpotFxCache,
                           positions: Iterable[Union[VirtualFxPosition, Duck]],
                           currency: Currency) -> float:
        """
        Get value of positions in domestic currency.
        """
        value = 0

        for position in positions:
            if abs(position.amount) < 1e-08:
                continue

            # Spot in market currency
            spot = fx_cache.get_fx(fx_pair=position.fxpair.name)

            if position.fxpair.quote == currency:
                value += position.amount * spot
            elif position.fxpair.base == currency:
                value += position.amount  # quantity is already in units of domestic currency
            else:
                raise NotImplementedError("Need to implement triangulation")

        return value

    def get_position_value_by_holding(self,
                                      fx_cache: SpotFxCache,
                                      positions: Iterable[Union[VirtualFxPosition, Duck]],
                                      currency: Currency
                                      ) -> Dict[FxPairName, float]:
        position_values = {}
        for position in positions:
            if abs(position.amount) < 1e-08:
                continue
            fxpair = position.fxpair

            # Spot in market currency
            spot = fx_cache.get_fx(fx_pair=position.fxpair.name)

            if fxpair not in position_values:
                position_values[fxpair.name] = 0.

            if fxpair.quote == currency:
                position_values[fxpair.name] += position.amount * spot
            elif fxpair.base == currency:
                # Quantity is already in units of domestic currency
                position_values[fxpair.name] += position.amount
            else:
                raise NotImplementedError("Need to implement triangulation")

        return position_values
