from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair as FxPairHDL
from hdlib.Hedge.Fx.Util.SpotFxCache import SpotFxCache

import pandas as pd
import numpy as np

from typing import Sequence, Dict, List, Tuple, Set


class FxMarketConverter:
    """
    Class that can do market convention conversions, like check whether FX pairs are traded, or how to synthesize an
    FX pair from market trade pair.
    """

    def __init__(self, traded_pairs: Dict[FxPairInterface, float]):
        # Map from a traded FX pair to the min lot size for that pair.
        self._traded_pairs = traded_pairs

    def get_market_pairs_for_fx_pair(self, fx_pair: FxPairInterface) -> List[Tuple[FxPairInterface, bool]]:
        """
        Get the market tradable pairs that correspond to the given FX pair. For the case of triangulation, there may
        be multiple pairs, otherwise, there will be a single pair in the list.

        :returns: List of traded currency pairs needed to get the input fx pair, along with a bool that is true
            if you need to go long the inverse of the pair.
        """

        # If this pair is traded, we can just return it.
        if self.is_market_traded_pair(fx_pair=fx_pair):
            return [(fx_pair, False)]

        inverse = fx_pair.make_inverse()
        if self.is_market_traded_pair(fx_pair=inverse):
            return [(inverse, True)]

        # TODO: Else, do triangulation.
        raise Exception("triangulation logic not yet implemented")

    def get_traded_currencies(self) -> Set[Currency]:
        currencies = set({})
        for pair in self._traded_pairs:
            currencies.add(pair.base)
            currencies.add(pair.quote)

        return currencies

    def is_market_traded_pair(self, fx_pair: FxPairInterface) -> bool:
        return fx_pair in self._traded_pairs

    def get_lot_size(self, fx_pair: FxPairInterface) -> float:
        """
        Get the lot size for an fx pair. This is assumed to always be an FX pair that actually trades.
        """
        if fx_pair not in self._traded_pairs:
            raise ValueError(f"fx pair {fx_pair} not a market traded pair")
        return self._traded_pairs[fx_pair]

    def round_to_lot(self, fx_pair: FxPairInterface, amount: float) -> float:
        """
        Round an order amount to a round lot size for an fx pair. This is assumed to always be an FX pair
        that actually trades.
        """
        lot_size = self.get_lot_size(fx_pair=fx_pair)
        amount = np.fix(amount / lot_size) * lot_size
        return amount

    def convert_rates_to_market_array(self,
                                      fx_pairs: Sequence[FxPairInterface],
                                      fx_rates: np.ndarray) -> pd.Series:
        """
        Convert a set of fx_pairs, with rates in that convention, into a set of market pairs, with appropriately
        converted rates (if a pair is already market convention, there is no change)
        :param fx_pairs:
        :param fx_rates:
        :return:
        """
        # TODO: update later for triangulation (output could be of a different size)
        fx_pairs_mkt = []
        fx_rates_mkt = fx_rates.copy()
        for i in range(len(fx_pairs)):
            fx_pair: FxPairInterface = fx_pairs[i]
            if fx_pair in self._traded_pairs:
                fx_pairs_mkt.append(fx_pair)
            else:
                fx_pairs_mkt.append(fx_pair.make_inverse())
                fx_rates_mkt[i] = 1. / fx_rates[i]

        return pd.Series(index=fx_pairs_mkt, data=fx_rates_mkt, dtype=float)

    def convert_positions_to_market_array(self,
                                          fx_positions_cntr: pd.Series,
                                          fx_rates_cntr: np.ndarray) -> pd.Series:
        # TODO: deprecate?

        if len(fx_positions_cntr) != len(fx_rates_cntr):
            raise ValueError("Positions and rates must be of the same length")

        fx_pairs_mkt = []
        fx_positions_mkt = fx_positions_cntr.values.copy()

        for i in range(len(fx_positions_cntr)):
            fx_pair: FxPairInterface = fx_positions_cntr.index[i]
            if fx_pair in self._traded_pairs:
                fx_pairs_mkt.append(fx_pair)
            else:
                fx_pairs_mkt.append(fx_pair.make_inverse())
                fx_positions_mkt[i] = -fx_rates_cntr[i] * fx_positions_cntr.iloc[i]

        return pd.Series(index=fx_pairs_mkt, data=fx_positions_mkt, dtype=float)

    def convert_positions_to_market(self,
                                    fx_positions: pd.Series,
                                    fx_cache: SpotFxCache) -> pd.Series:
        # TODO: update later for triangulation (output could be of a different size)

        fx_pairs_mkt = []
        fx_positions_mkt = []

        # traded = list(self._traded_pairs.keys())

        for fx_pair, position in fx_positions.items():
            fx_pair: FxPairInterface = fx_pair
            spot_cntr = fx_cache.get_fx(fx_pair=fx_pair)

            if fx_pair in self._traded_pairs:
                fx_pairs_mkt.append(fx_pair)
                fx_positions_mkt.append(position)
            else:
                fx_pairs_mkt.append(fx_pair.make_inverse())
                # Note: when switching convention, switch the direction (from long to short, and conversely)
                fx_positions_mkt.append(-spot_cntr * position)

        return pd.Series(index=fx_pairs_mkt, data=fx_positions_mkt, dtype=float)

    def convert_positions_to_cntr_currency(self,
                                           fx_positions_mkt: Dict[FxPairInterface, float],
                                           fx_cache: SpotFxCache,
                                           domestic: Currency
                                           ) -> pd.Series:
        # TODO: update later for triangulation (output could be of a different size)

        # TODO: Return a dictionary - enough with these pandas series. We use this as a dictionary, and its more
        #  difficult to express type info with a series.

        fx_pairs_cntr = []
        fx_positions_cntr = []

        for fx_pair, position in fx_positions_mkt.items():
            fx_pair: FxPairInterface = fx_pair
            if fx_pair.quote.get_mnemonic() == domestic.get_mnemonic():
                fx_pairs_cntr.append(fx_pair)
                fx_positions_cntr.append(position)
            elif fx_pair.base.get_mnemonic() == domestic.get_mnemonic():

                # Get spot either directly, or via its inverse.
                spot_mkt = fx_cache.get_fx(fx_pair=fx_pair)
                inverse_pair = FxPairHDL(base=fx_pair.quote, quote=fx_pair.base)
                spot_mkt = 1.0 / fx_cache.get_fx(inverse_pair) if spot_mkt is None else spot_mkt
                fx_pairs_cntr.append(inverse_pair)
                # Note: when switching convention, switch the direction (from long to short, and conversely)
                fx_positions_cntr.append(-spot_mkt * position)
            else:
                raise NotImplementedError("Requires triangulation")

        return pd.Series(index=fx_pairs_cntr, data=fx_positions_cntr, dtype=float)
