from abc import abstractmethod

from hdlib.Core.Currency import Currency


class FxPairInterface(object):
    """
    Defines the minimal interface for an FxPair.
    """

    @abstractmethod
    def get_base_currency(self) -> Currency:
        """ Get the base currency of this FxPair. """
        raise NotImplementedError

    @abstractmethod
    def get_quote_currency(self) -> Currency:
        """ Get the quote currency of this FxPair. """
        raise NotImplementedError

    @abstractmethod
    def make_inverse(self) -> 'FxPairInterface':
        """ Create the inverse pair of this pair. """
        raise NotImplementedError

    @property
    def name(self) -> str:
        """ Get the name of the FxPair. """
        return f"{self.base.get_mnemonic()}/{self.quote.get_mnemonic()}"

    @property
    def inverse_name(self) -> str:
        """ Get the name of inverse Fx Pair """
        return f"{self.quote.get_mnemonic()}/{self.base.get_mnemonic()}"

    @property
    def base(self) -> Currency:
        """ Property alias for get_base_currency(). """
        return self.get_base_currency()

    @property
    def quote(self) -> Currency:
        """ Property alias for get_quote_currency(). """
        return self.get_quote_currency()

    def __hash__(self):
        return hash(self.name)

    def __repr__(self) -> str:
        return self.name

    def __str__(self) -> str:
        return self.name

    def __eq__(self, other: 'FxPairInterface'):
        return self.name == other.name if other else False

    def __lt__(self, other: 'FxPairInterface'):
        return self.name < other.name

    def __gt__(self, other: 'FxPairInterface'):
        return self.name > other.name

    def __ne__(self, other: 'FxPairInterface'):
        return self.name != other.name if other else True
