from hdlib.Core.Currency import Currency, make_currency
from hdlib.Core.FxPairInterface import FxPairInterface


class FxPair(FxPairInterface):
    """
    A concrete implementation of the FxPairInterface. This is the HDL representation of an FX pair.
    """

    def __init__(self, base: Currency, quote: Currency):
        """
        FX Pair object, e.g. USD -> CHF
        :param base: Currency, the base ("foreign") currency
        :param quote: Currency, the quote/term ("domestic") currency
        """
        self._base = base
        self._quote = quote

    # =============================================================
    #  FxPairInterface methods.
    # =============================================================

    def get_base_currency(self) -> Currency:
        """ Get the base currency of this FxPair. """
        return self._base

    def get_quote_currency(self) -> Currency:
        """ Get the quote currency of this FxPair. """
        return self._quote

    def make_inverse(self) -> 'FxPair':
        """ Create the inverse pair of this pair. """
        return FxPair(self._quote, self._base)

    # =============================================================
    #  Other methods.
    # =============================================================

    @staticmethod
    def invert_str(fx_pair: str) -> str:
        """
        Given a string representation of an FxPair, return an inverted string representation
        :param fx_pair: str, e.g. "USD/GBP"
        :return: str, the inverted pair, e.g. "GBP/USD"
        """
        if len(fx_pair) == 7:
            return f"{fx_pair[4:]}/{fx_pair[:3]}"
        elif len(fx_pair) == 6:
            return f"{fx_pair[3:]}/{fx_pair[:3]}"
        raise ValueError("Pair is not formatted as XXX/YYY or XXXYYY")

    @staticmethod
    def from_currency_strs(base: str, quote: str) -> 'FxPair':
        """
        Construct a currency pair object from str representation of each currency
        :param base: str, the base currency mnemonic, e.g. "EUR"
        :param quote: str, the quote currency mnemonic, e.g. "USD"
        :return: FxPair
        """
        return FxPair(make_currency(base), make_currency(quote))

    @staticmethod
    def from_str(pair: str) -> 'FxPair':
        """
        Construct a currency pair object from str representations:
        :param pair: str, of the form "EUR/USD" or "EURUSD"
        :return: FxPair
        """
        if len(pair) == 7 and pair[3] == '/':
            return FxPair.from_currency_strs(pair[:3], pair[4:])
        elif len(pair) == 6:
            return FxPair.from_currency_strs(pair[:3], pair[3:])
        raise ValueError("Pair is not formatted as USD/EUR or USDEUR")


