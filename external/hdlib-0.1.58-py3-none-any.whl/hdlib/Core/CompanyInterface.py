from abc import abstractmethod

from hdlib.Core.Currency import Currency


class CompanyInterface(object):
    """ Class that provides the most basic interface of what information is needed from a company. """

    @abstractmethod
    def get_name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def get_company_currency(self) -> Currency:
        raise NotImplementedError

    def __hash__(self):
        return hash(self.get_name())

    def __str__(self) -> str:
        return self.get_name()


class BasicCompany(CompanyInterface):
    """ A basic implementation of a Company. """

    def __init__(self, name: str, domestic: Currency):
        self._name = name
        self._domestic = domestic

    def get_name(self) -> str:
        return self._name

    def get_company_currency(self) -> Currency:
        return self._domestic
