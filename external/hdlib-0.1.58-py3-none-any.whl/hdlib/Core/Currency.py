from abc import ABC, ABCMeta, abstractmethod
from typing import Optional


class Currency(object):
    """
    Interface for a currency.
    """

    @abstractmethod
    def get_name(self) -> str:
        """ The name of currency (e.g. US Dollars) """
        raise NotImplementedError

    @abstractmethod
    def get_mnemonic(self) -> str:
        """ The 3 character mnemonic (e.g. USD) """
        raise NotImplementedError

    def __repr__(self) -> str:
        return self.get_mnemonic()

    def __str__(self) -> str:
        return self.get_mnemonic()

    def __eq__(self, other: 'Currency'):
        return self.get_mnemonic() == other.get_mnemonic()

    def __lt__(self, other: 'Currency'):
        return self.get_mnemonic() < other.get_mnemonic()

    def __gt__(self, other: 'Currency'):
        return self.get_mnemonic() > other.get_mnemonic()

    def __ne__(self, other: 'Currency'):
        return self.get_mnemonic() != other.get_mnemonic()

    def __hash__(self):
        return hash(self.get_mnemonic())


class CustomCurrency(Currency):
    def __init__(self, mnemonic: str, name: str = None):
        self._mnemonic = mnemonic
        self._name = name or mnemonic

    def get_name(self) -> str:
        return self._name

    def get_mnemonic(self) -> str:
        return self._mnemonic


class USDCurrency(Currency):

    def get_name(self) -> str:
        return "US dollars"

    def get_mnemonic(self) -> str:
        return "USD"


class EURCurrency(Currency):

    def get_name(self) -> str:
        return "Euros"

    def get_mnemonic(self) -> str:
        return "EUR"


class GBPCurrency(Currency):

    def get_name(self) -> str:
        return "British pound"

    def get_mnemonic(self) -> str:
        return "GBP"


class CHFCurrency(Currency):

    def get_name(self) -> str:
        return "Swiss Franc"

    def get_mnemonic(self) -> str:
        return "CHF"


class AUDCurrency(Currency):

    def get_name(self) -> str:
        return "Australian Dollar"

    def get_mnemonic(self) -> str:
        return "AUD"


class CADCurrency(Currency):

    def get_name(self) -> str:
        return "Canadian Dollar"

    def get_mnemonic(self) -> str:
        return "CAD"


class JPYCurrency(Currency):

    def get_name(self) -> str:
        return "Japanese Yen"

    def get_mnemonic(self) -> str:
        return "JPY"


class MXNCurrency(Currency):

    def get_name(self) -> str:
        return "Mexican Peso"

    def get_mnemonic(self) -> str:
        return "MXN"


class CNYCurrency(Currency):

    def get_name(self) -> str:
        return "Chinese Yuan"

    def get_mnemonic(self) -> str:
        return "CNY"


class TRYCurrency(Currency):

    def get_name(self) -> str:
        return "Turkish Lira"

    def get_mnemonic(self) -> str:
        return "TRY"


class KRWCurrency(Currency):

    def get_name(self) -> str:
        return "South Korean won"

    def get_mnemonic(self) -> str:
        return "KRW"


class SGDCurrency(Currency):

    def get_name(self) -> str:
        return "Singapore dollar"

    def get_mnemonic(self) -> str:
        return "SGD"


class ZARCurrency(Currency):

    def get_name(self) -> str:
        return "South African Rand"

    def get_mnemonic(self) -> str:
        return "ZAR"


class IDRCurrency(Currency):

    def get_name(self) -> str:
        return "Indonesian rupiah"

    def get_mnemonic(self) -> str:
        return "IDR"


class BRLCurrency(Currency):

    def get_name(self) -> str:
        return "Brazilian real"

    def get_mnemonic(self) -> str:
        return "BRL"


class INRCurrency(Currency):

    def get_name(self) -> str:
        return "Indian rupee"

    def get_mnemonic(self) -> str:
        return "INR"


class RUBCurrency(Currency):

    def get_name(self) -> str:
        return "Russian ruble"

    def get_mnemonic(self) -> str:
        return "RUB"


class ANGCurrency(Currency):

    def get_name(self) -> str:
        return "Netherlands Antillean guilder"

    def get_mnemonic(self) -> str:
        return "ANG"


class SARCurrency(Currency):

    def get_name(self) -> str:
        return "Saudi riyal"

    def get_mnemonic(self) -> str:
        return "SAR"


class ARSCurrency(Currency):

    def get_name(self) -> str:
        return "Argentine peso"

    def get_mnemonic(self) -> str:
        return "ARS"


class AEDCurrency(Currency):

    def get_name(self) -> str:
        return "UAE Dirham"

    def get_mnemonic(self) -> str:
        return "AED"


class CZKCurrency(Currency):

    def get_name(self) -> str:
        return "Czech Koruna"

    def get_mnemonic(self) -> str:
        return "CZK"


class DKKCurrency(Currency):

    def get_name(self) -> str:
        return "Danish Krone"

    def get_mnemonic(self) -> str:
        return "DKK"


class HUFCurrency(Currency):

    def get_name(self) -> str:
        return "Hungarian Forint"

    def get_mnemonic(self) -> str:
        return "HUF"


class NOKCurrency(Currency):

    def get_name(self) -> str:
        return "Norwegian Krone"

    def get_mnemonic(self) -> str:
        return "NOK"


class NZDCurrency(Currency):

    def get_name(self) -> str:
        return "New Zealand Dollar"

    def get_mnemonic(self) -> str:
        return "NZD"


class PLNCurrency(Currency):

    def get_name(self) -> str:
        return "Poland Zloty"

    def get_mnemonic(self) -> str:
        return "PLN"


class SEKCurrency(Currency):

    def get_name(self) -> str:
        return "Swedish Krona"

    def get_mnemonic(self) -> str:
        return "SEK"


class THBCurrency(Currency):

    def get_name(self) -> str:
        return "Thai Baht"

    def get_mnemonic(self) -> str:
        return "THB"


class ILSCurrency(Currency):
    def get_name(self) -> str:
        return "Israeli New Shekel"

    def get_mnemonic(self) -> str:
        return "ILS"


# ========================
# Importable Currency objects, treat like singletons
# ========================


USD = USDCurrency()
GBP = GBPCurrency()
CHF = CHFCurrency()
EUR = EURCurrency()
AUD = AUDCurrency()
CAD = CADCurrency()
JPY = JPYCurrency()
MXN = MXNCurrency()
CNY = CNYCurrency()
TRY = TRYCurrency()
KRW = KRWCurrency()
SGD = SGDCurrency()
ZAR = ZARCurrency()
IDR = IDRCurrency()
BRL = BRLCurrency()
INR = INRCurrency()
RUB = RUBCurrency()
ANG = ANGCurrency()
SAR = SARCurrency()
ARS = ARSCurrency()

AED = AEDCurrency()
CZK = CZKCurrency()
DKK = DKKCurrency()
HUF = HUFCurrency()
NOK = NOKCurrency()
NZD = NZDCurrency()
PLN = PLNCurrency()
SEK = SEKCurrency()

THB = THBCurrency()

ILS = ILSCurrency()

# ========================

_currency_map = {"USD": USD, "GBP": GBP, "CHF": CHF, "EUR": EUR, "AUD": AUD,
                 "CAD": CAD, "JPY": JPY, "MXN": MXN, "CNY": CNY, "KRW": KRW,
                 "SGD": SGD, "ZAR": ZAR, "IDR": IDR, "BRL": BRL, "INR": INR,
                 "RUB": RUB, "SAR": SAR, "ARS": ARS, "TRY": TRY, "ANG": ANG,
                 "AED": AED, "CZK": CZK, "DKK": DKK, "HUF": HUF, "NOK": NOK,
                 "NZD": NZD, "PLN": PLN, "SEK": SEK, "THB": THB, "ILS": ILS}

# Export a list of all available major currencies. For now, just exporting the _currency_map.
all_major_currency = _currency_map


def make_currency(currency: str) -> Optional[Currency]:
    """ Make a currency object from a currency string. If unable to convert, returns Custom Currency obj """
    return _currency_map.get(currency, CustomCurrency(mnemonic=currency, name=currency))
