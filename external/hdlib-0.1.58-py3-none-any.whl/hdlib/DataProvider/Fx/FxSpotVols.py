from typing import Tuple, Union, Dict, List, Iterable, Optional
import numpy as np
import pandas as pd
from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.DateTime.Date import Date
from hdlib.Core.Currency import Currency
from abc import ABC, abstractmethod


class FxSpotVols(object):
    def __init__(self,
                 ref_date: Date,
                 vols: Union[pd.DataFrame, pd.Series, Dict[str, float]] = pd.DataFrame()):
        """
        Provides FX spot / forward volatilities, as of a given reference date, for all known FX pairs
        If vols is a DataFrame, rows and columns are Currency objects
        If vols is a Series, the index should be FxPair objects
        :param ref_date: Date, the valuation/reference date
        """
        self._ref_date = ref_date

        if isinstance(vols, pd.Series):
            self._impl = _SeriesImpl(vols)
        elif isinstance(vols, dict):
            self._impl = _DictImpl(vols)
        elif isinstance(vols, pd.DataFrame):
            self._impl = _FrameImpl(vols)
        else:
            raise ValueError("vols is not of a usable types")

        # TODO: this may become abstract interface, but for now we need the plumbing

    @property
    def ref_date(self) -> Date:
        return self._ref_date

    def vol_spot(self, name: str = None, pair: FxPairInterface = None) -> float:
        """
        Instantaneous vol estimate for spot currency pair, between the spot "inovoations".
        Note: this is the ANNUALIZED volatility, not the daily volatility
        :param name: str, name of pair, format "USD/GBP"
        :param pair: FxPair, the currency pair object
        :return: float, spot FX volatility
        """
        return self._impl.vol_spot(pair=pair, name=name)

    def vols_spots(self,
                   names: Optional[Iterable[str]] = None,
                   pairs: Optional[Iterable[FxPairInterface]] = None) -> pd.Series:
        """
        Instantaneous vol estimate for spot currency pair, between the spot "innovation".
        Note: this is the ANNUALIZED volatility, not the daily volatility
        :param names: iterable of pair names
        :param pairs: iterable of Fx pairs
        :return: pd.Series, the annualized spot vol per pair
        """
        return self._impl.vols_spots(names=names, pairs=pairs)


# ===============
# Private Implementations
# ===============


class _Impl(ABC):
    """ Specific implementation of the FxVol Provider (PIMPL pattern) """

    @abstractmethod
    def vol_spot(self, name: str = None, pair: FxPairInterface = None) -> float:
        raise NotImplementedError

    def vols_spots(self, names: Optional[Iterable[str]] = None,
                   pairs: Optional[Iterable[FxPairInterface]] = None) -> pd.Series:
        if names is None and pairs is None:
            raise ValueError("names and pairs cannot both be None")
        if pairs is not None:
            return pd.Series(index=pairs, data=[self.vol_spot(pair=pair) for pair in pairs])
        return pd.Series(index=names, data=[self.vol_spot(name=name) for name in names])


class _FrameImpl(_Impl):
    """ Implementation in case of a DataFrame, where columns and rows are currencies """

    def __init__(self, vols: pd.DataFrame):
        self._vols = vols

    def vol_spot(self, name: str = None, pair: FxPairInterface = None) -> float:
        return self._vols.loc[pair.base.get_mnemonic(), pair.quote.get_mnemonic()] if pair \
            else self._vols.loc[name[:3], name[4:]]


class _SeriesImpl(_Impl):
    """ Implementation in case of a Series, where index is a pair name """

    def __init__(self, vols: pd.Series):
        self._vols = vols

    def vol_spot(self, name: str = None, pair: FxPairInterface = None) -> float:
        return self._vols.loc[pair.name] if pair else self._vols.loc[name]


class _DictImpl(_Impl):
    """ Implementation in case of a Dictionary, where key is a pair name """

    def __init__(self, vols: Dict[str, float]):
        self._vols = vols

    def vol_spot(self, name: str = None, pair: FxPairInterface = None) -> float:
        return self._vols.get(pair.name, np.nan) if pair else self._vols.get(name, np.nan)
