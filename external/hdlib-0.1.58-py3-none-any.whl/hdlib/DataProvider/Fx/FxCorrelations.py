import numpy as np
import pandas as pd
from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.DateTime.Date import Date

from typing import Union, Set, List, Tuple, Iterable


# TODO(Nate): We need to stop having such concrete base classes. It is not reasonable to make anyone who wants to
#   implement an FxCorrelations service to provide correlations as a dataframe, and no other way. We need purely
#   abstract interfaces.
class FxCorrelations(object):
    def __init__(self,
                 ref_date: Date,
                 instant_corr: pd.DataFrame = pd.DataFrame()):
        """
        Provides FX spot / forward correlations, as of a given reference date, for all known FX pairs
        :param ref_date: Date, the valuation/reference date
        :param instant_corr: pd.DataFrame, instant correlation matrix. The column names and index are
            FX pairs.
        """
        self._ref_date = ref_date
        self._instant_corr = instant_corr

    @property
    def ref_date(self) -> Date:
        return self._ref_date

    def instant_fx_spot_corr(self,
                             pairs: Tuple[FxPairInterface, FxPairInterface] = None,
                             names: Tuple[str, str] = None) -> float:
        """
        Instantaneous Correlation estimate for spot currency pairs, between the spot "inovoations".
        Typically this is estimated by correlating log returns of the FX pair
        :return: float, estimate of correlation
        """
        try:
            if pairs:
                return self._instant_corr.loc[pairs[0].name, pairs[1].name]
            return self._instant_corr.loc[names[0], names[1]]
        except Exception:
            return np.nan

    def instant_fx_spot_corr_matrix(self,
                                    pairs: Union[Iterable[str], Iterable[FxPairInterface]] = None) -> pd.DataFrame:
        """
        Instantaneous Correlation estimate for spot currency pairs, between the spot "inovoations".
        Typically, this is estimated by correlating log returns of the FX pair
        :param pairs: List, Set or Tuple of fx pair names
        :return: matrix, correlations for this subset of fx pairs
        """
        if pairs is None:
            return self._instant_corr
        names = []
        for p in pairs:
            if isinstance(p, str):
                names.append(p)
            elif isinstance(p, FxPairInterface):
                names.append(p.name)
            else:
                raise ValueError(f"unrecognized type for pair {p}")

        return self._instant_corr.loc[names, names]
