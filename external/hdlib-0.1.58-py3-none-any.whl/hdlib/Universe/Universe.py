from typing import Optional, Tuple, Dict, Union, Iterable, Set

import pandas as pd

from hdlib.Instrument.CashFlow import CashFlow

from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.Core.FxPair import FxPair
from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD
from hdlib.Hedge.Fx.Util.SpotFxCache import SpotFxCache, FxPairName
from hdlib.Instrument.FxForward import FxForwardInstrument
from hdlib.Universe.Asset.FxAsset import FxAsset
from hdlib.Universe.Asset.IrAsset import IrAsset
from hdlib.Universe.FX.FxUniverse import FxAssets, FxUniverse
from hdlib.Core.Currency import Currency
from hdlib.TermStructures.DiscountCurve import DiscountCurve
from hdlib.DateTime.Date import Date


class Universe(SpotFxCache):
    """
    A financial pricing universe, which contains all pricing related information as of a particular time.

    Since the Universe should also have spot assets, it functions as a SpotFxCache.
    """

    def __init__(self,
                 ref_date: Date,
                 dc: DayCounter = DayCounter_HD(),
                 fx_universe: Optional[FxUniverse] = None,
                 counter_currency: Optional[Currency] = None):
        """
        Financial Pricing Universe, as of a given reference date
        :param ref_date: Date, the valuation/reference date
        :param dc: DayCounter,
        :param fx_universe: FxUniverse, provides FX rates on this date (optional, one is initialized if not supplied),
            as well as correlations, volatilities.
        """
        super().__init__(ref_date=ref_date)
        self._dc = dc
        self._fx_universe = fx_universe or FxUniverse(ref_date)

        # If this universe is a counter-currency universe (all the Fx assets share a common quote currency),
        # this field indicates what currency that is. Otherwise, this is None.
        self.cntr_currency = counter_currency

        if ref_date != self._fx_universe.ref_date:
            raise ValueError("Your reference date must match that of the fx_provider")

        self._ir_assets: Dict[str, IrAsset] = {}

    # ============================
    # Member Data
    # ============================

    @property
    def ref_date(self) -> Date:
        return self._ref_date

    @property
    def day_counter(self) -> DayCounter:
        return self._dc

    @property
    def fx_universe(self) -> FxUniverse:
        return self._fx_universe

    @property
    def fx_assets(self) -> FxAssets:
        return self._fx_universe.fx_assets

    @property
    def ir_assets(self) -> Dict[str, IrAsset]:
        return self._ir_assets

    @property
    def currencies(self) -> Set[Currency]:
        """
        Get the set of all currencies that are either the quote or base for any currency pair in the
        universe's FxAssets.
        """
        return self.fx_assets.currencies

    # ============================
    # Adder Methods to add new assets to the universe
    # ============================

    def add_fx_asset(self, fx_asset: FxAsset):
        self.fx_assets.add_asset(asset=fx_asset)

    def add_ir_asset(self, ir_asset: IrAsset):
        self._ir_assets[ir_asset.name] = ir_asset

    # ============================
    # Getter Methods for Assets
    # ============================

    def get_fx_asset(self,
                     name: str = None,
                     pair: Union[FxPairInterface, Tuple[Currency, Currency]] = None) -> Optional[FxAsset]:
        """
        Get an FX asset by name (or currency pair)
        :param pair: currency pair (tuple[base,quote]) or FxPairInterface type, must supply this or the name
        :param name: str, name of FX pair, of the form "USD/EUR"
        :return: FxAsset if found, else None
        """
        return self.fx_assets.get_asset(name=name, pair=pair)

    def get_ir_asset(self, name: str = None, currency: Currency = None) -> Optional[IrAsset]:
        """
        Get IR asset by name (or currency)
        :param name: str, name of asset (mnemonic of currency, e.g. USD)
        :param currency: Currency, the currency of IR asset (e.g. USDCurrency)
        :return: IRAsset if found, else None
        """
        return self._ir_assets.get(name, None) if name else self._ir_assets.get(currency.get_mnemonic(), None)

    def get_discount_curve(self, name: str = None, currency: Currency = None) -> Optional[DiscountCurve]:
        ir_asset = self.get_ir_asset(name=name, currency=currency)
        return ir_asset.discount_curve if ir_asset else None

    # ============================
    # Other Finance
    # ============================

    def get_forward(self, fx_pair: FxPairInterface, date: Date) -> Optional[float]:
        """ Get an Fx forward. """
        asset = self.get_fx_asset(pair=fx_pair)
        if asset:
            return asset.fwd_curve.at_D(date)
        return None

    def get_spot(self, fx_pair: FxPairInterface) -> Optional[float]:
        """ Get the current Fx spot. """
        return self.get_forward(fx_pair=fx_pair, date=self.ref_date)

    def get_spot_volatility(self,
                            spot_positions: Union[pd.Series, Dict[FxPair, float]],
                            currency: Currency) -> float:
        return self.fx_universe.get_spot_volatility(spot_positions, currency=currency)

    def price_spot_positions(self,
                             spot_positions: Union[pd.Series, Dict[FxPair, float]],
                             base_currency: Currency) -> Optional[float]:
        total_value = 0.
        for fxpair, amount in spot_positions.items():
            value = self.get_spot(fxpair)
            if value is None:
                return None
            converted_value = self.convert_value(value=value,
                                                 from_currency=fxpair.get_quote_currency(),
                                                 to_currency=base_currency)
            total_value += converted_value * amount
        return total_value

    def price_forward_positions(self, forwards: Iterable[FxForwardInstrument], currency: Currency):
        """ Price a collection of forward positions. """
        value = 0.
        for forward in forwards:
            value += self.price_forward(forward, currency)
        return value

    def price_forward(self, forward: FxForwardInstrument, currency: Currency):
        """ Price a single forward contract. """
        current_fwd_rate = self.get_forward(forward.get_fxpair(), date=forward.get_delivery_time())
        forward_price = forward.get_forward_price()
        Z = self.get_discount(asset=forward.get_fxpair(),
                              date=forward.get_delivery_time())
        value_in_quote = Z * (current_fwd_rate - forward_price) * forward.get_amount()
        return self.convert_value(value=value_in_quote, from_currency=forward.get_fxpair().quote, to_currency=currency)

    def value_cashflow(self, cashflow: CashFlow, quote_currency: Currency):
        """
        Value of a future cashflow in any currency, valued in a particular quote currency.

                        FORWARD                     ZCB
        Pay date (PD)   1 (B) ---> <--- FWD (Q)     <--- FWD (Q)
        ...
        Present (t = 0)                             ---> Z(PD) * FWD  (buy ZCB)

        If at the present, I am paid Z(PD) * FWD, then I can buy Z * FWD ZCBs and enter into a FWD at the pay date (PD).
        At the pay date, I receive FWD in domestic, and use that to buy one unit of the foreign currency via the
        Fx forward.
        Therefore, the NPV of receiving one unit of B at time PD is Z(PD) * FWD.

        Note that since FWD(ttm) = FWD(0) * exp[(rd - rf - r_xccy) ttm],
            V = Z(ttm) * FWD(ttm) = exp(-rd * ttm) * FWD(ttm) = FWD(0) * exp[-(rf + r_xccy) * ttm]
        """
        if cashflow.pay_date < self.ref_date:
            return 0.

        if cashflow.currency == quote_currency:
            fwd = 1.0
        else:
            fwd = self.get_forward(fx_pair=FxPair(cashflow.currency, quote_currency), date=cashflow.pay_date)
        if not fwd:
            raise RuntimeError(f"could not find fwd for {(cashflow.currency, quote_currency)}")

        unit_value = fwd * self.get_discount(asset=quote_currency, date=cashflow.pay_date)
        return cashflow.amount * unit_value

    def get_discount(self, asset: Union[FxPairInterface, Currency], date: Date):
        """ Get the discount curve for an asset. """
        if isinstance(asset, FxPairInterface):
            asset = asset.get_quote_currency()
        return self.get_ir_asset(currency=asset).discount_curve.at_D(date)

    # ============================
    # SpotFxCache Methods
    # ============================

    def get_fx(self, fx_pair: Union[FxPairInterface, FxPairName], value_if_missing: float = None) -> Optional[float]:
        return self._fx_universe.get_fx(fx_pair=fx_pair, value_if_missing=value_if_missing)

    def has_fx(self, fx_pair: Union[FxPairInterface, FxPairName]):
        """ Check if the spot map has a non-None entry for this spot. """
        return self._fx_universe.has_fx(fx_pair=fx_pair)
