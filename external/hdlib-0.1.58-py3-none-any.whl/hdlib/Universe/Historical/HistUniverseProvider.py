from abc import ABC, abstractmethod

from hdlib.Universe.Universe import Universe, Date, DayCounter

from typing import List, Iterable


class HistUniverseProvider(ABC):
    """
    Historical Universe Provider. Base class for a provider which can construct historical universes on
    command for a supplied valuation date
    """

    @abstractmethod
    def make_universe(self, date: Date) -> Universe:
        """ Main Method to construct the Universe on a given date """
        raise NotImplementedError

    @abstractmethod
    def get_dates(self, start: Date, end: Date) -> Iterable[Date]:
        """
        Get the dates of available universes, between start and end (inclusive)
        These are in ascending order
        :param start: Date, the first date (wont return any dates before this)
        :param end: Date, the end date (wont return and dates after this)
        :return: Iterable[Date], all available dates between start and end (inclusive)
        """
        raise NotImplementedError

    @abstractmethod
    def get_n_dates(self, start: Date, num_dates: int) -> Iterable[Date]:
        """
        Get the first N dates including and following the start date that are available universes. If there are fewer
        than N available dates on or after the start date, the the maximum possible number of dates will be returned.

        :param start: Date, the first date
        :param num_dates: int, the number of dates to return.
        :returns: Iterable[Date], the first N (or fewer if necessary) available dates, starting with the start date
        """
        raise NotImplementedError

    @abstractmethod
    def get_n_uniform_dates(self, start: Date, num_dates: int) -> Iterable[Date]:
        """
        Get N dates including the start date that are as uniformly space out as possible from the dates available to the
        universe. If there are fewer than N available dates on or after the start date, the the maximum possible number
        of dates will be returned.

        :param start: Date, the first date
        :param num_dates: int, the number of dates to return.
        :returns: Iterable[Date], the first N (or fewer if necessary) available dates, starting with the start date
        """
        raise NotImplementedError

    @abstractmethod
    def get_all_dates(self) -> Iterable[Date]:
        """
        Get all the available dates for which universes can be created.
        """
        raise NotImplementedError

    @abstractmethod
    def get_next_date(self, date: Date) -> Date:
        raise NotImplementedError

    @abstractmethod
    def get_top_date(self) -> Date:
        raise NotImplementedError

    @property
    @abstractmethod
    def day_counter(self) -> DayCounter:
        """ Get the day counter, used for all day counting internally """
        raise NotImplementedError
