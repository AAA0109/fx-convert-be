from hdlib.Universe.Asset.Asset import Asset

from hdlib.Core.Currency import Currency
from hdlib.TermStructures.DiscountCurve import DiscountCurve


class IrAsset(Asset):
    def __init__(self,
                 currency: Currency,
                 discount: DiscountCurve):
        """
        IR (interest rate) asset representing a single currency
        :param currency: Currency, base asset currency
        :param discount: DiscountCurve, primary/default discount curve for discounting cashflows
        """
        super(IrAsset, self).__init__(ref_date=discount.ref_date,
                                      name=currency.get_mnemonic(),
                                      currency=currency)
        self._discount_curve = discount

    @property
    def discount_curve(self) -> DiscountCurve:
        return self._discount_curve
