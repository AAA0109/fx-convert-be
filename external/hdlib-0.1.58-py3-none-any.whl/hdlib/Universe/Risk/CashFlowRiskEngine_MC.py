from hdlib.Universe.Pricing.CashFlowPricer import CashFlowPricer
from hdlib.Instrument.CashFlow import CashFlows, Currency, Date
from hdlib.Universe.Universe import Universe, FxAssets, FxAsset
from hdlib.Universe.Risk.CashFlowRiskMetrics import CashFlowRiskMetrics
from hdlib.Core.FxPair import FxPair
from hdlib.Universe.Risk.CashFlowRiskEngine import CashFlowRiskEngine, CashFlowRiskEngineFactory

from typing import List, Set

import numpy as np


class CashFlowRiskEngine_MC(CashFlowRiskEngine, CashFlowRiskEngineFactory):
    def __init__(self,
                 universe: Universe,
                 n_trials: int = 10000):
        self._universe = universe
        self._ref_date: Date = universe.ref_date
        self._fx_assets: FxAssets = universe.fx_assets
        self._dc = universe.day_counter
        self._cf_pricer: CashFlowPricer = CashFlowPricer(universe)

        self._n_trials = n_trials

    def make_engine(self, universe: Universe) -> 'CashFlowRiskEngine_MC':
        """ Factory method to construct a new engine (ie a copy), to implement the factory interface """
        return CashFlowRiskEngine_MC(universe=universe, n_trials=self._n_trials)

    def calc_risk_metrics(self,
                          cashflows: CashFlows,
                          domestic_currency: Currency) -> [CashFlowRiskMetrics, np.ndarray]:
        disc = self._universe.get_discount_curve(currency=domestic_currency)

        unique_pairs = set()  # names of FX pairs, e.g. "USD/CHF"
        deterministic = 0

        if not cashflows.sorted:
            cashflows = cashflows.sort_and_filter(ref_date=self._ref_date)

        cf_times, cf_amounts, cfs = [], [], []

        for cf in cashflows:
            if cf.pay_date < self._ref_date:
                continue  # Cash flow already occured

            if cf.currency == domestic_currency:
                deterministic += cf.amount * disc.at_D(cf.pay_date)
                continue

            if cf.pay_date == self._ref_date:
                deterministic += cf.amount * self._fx_assets.get_fx_spot(pair=FxPair(cf.currency, domestic_currency))
                continue

            unique_pairs.add(FxPair(cf.currency, domestic_currency).name)

            cf_times.append(self._dc.year_fraction(self._ref_date, cf.pay_date))
            cf_amounts.append(cf.amount)
            cfs.append(cf)

        n_states = len(unique_pairs)
        if n_states == 0:
            return CashFlowRiskMetrics.from_deterministic(npv=deterministic), np.asarray([])

        state_map = {fx: i for fx, i in zip(unique_pairs, range(n_states))}
        cf_states = [state_map[FxPair(cf.currency, domestic_currency).name] for cf in cfs]

        values = self._sim_values(cf_times=cf_times, cf_amounts=cf_amounts,
                                  cf_states=cf_states, pairs=unique_pairs)

        npv, abs_npv = self._cf_pricer.price_cashflows(cashflows, value_currency=domestic_currency)
        values = values - (npv - deterministic)  # This is the VaR from Expected Cashflow
        pnl_std_dev = np.std(values)
        pnl_mean = np.mean(values)

        var_90, var_95, var_99 = np.quantile(values, (0.1, 0.05, 0.01))

        return CashFlowRiskMetrics(npv=npv,
                                   var_90=var_90,
                                   var_95=var_95,
                                   var_99=var_99,
                                   mean=float(pnl_mean),
                                   std_dev=float(pnl_std_dev)), values

    def _sim_values(self,
                    cf_times: List[float],
                    cf_amounts: List[float],
                    cf_states: List[int],
                    pairs: Set[str]) -> np.ndarray:

        n_state = len(pairs)
        fx_0 = np.zeros(n_state)
        vols = np.zeros(n_state)

        fx_universe = self._universe.fx_universe

        for pair, i in zip(pairs, range(n_state)):
            fx_0[i] = self._fx_assets.get_fx_spot(name=pair)
            # Get the annualized vol
            vols[i] = fx_universe.fx_vols.vol_spot(name=pair)

        fx_assets = {pair: fx_universe.fx_assets.get_asset(name=pair) for pair in pairs}

        num_flows = len(cf_times)

        values = np.zeros(self._n_trials)
        L = self._get_covar_matrix_chol(pairs=pairs, vols=vols)
        vols2 = 0.5 * vols * vols

        for n in range(self._n_trials):
            states = fx_0.copy()
            next_cf_index = 0
            t = 0

            while next_cf_index < num_flows:
                next_cf_time = cf_times[next_cf_index]
                dt = next_cf_time - t

                # Drift depends on the time, consistent with fwd curve
                drifts = np.zeros(n_state)
                for pair, i in zip(pairs, range(n_state)):
                    fx_asset: FxAsset = fx_assets[pair]
                    drifts[i] = fx_asset.fwd_curve.drift(t, next_cf_time)

                z = np.random.randn(n_state)
                states = states * np.exp((drifts - vols2) * dt + np.sqrt(dt) * np.dot(L, z))
                t += dt
                while abs(cf_times[next_cf_index] - t) < 1e-06:  # we've encountered the cashflow
                    values[n] += cf_amounts[next_cf_index] * states[cf_states[next_cf_index]]
                    next_cf_index += 1
                    if next_cf_index == num_flows:
                        break

        return values

    def _get_covar_matrix_chol(self,
                               pairs: Set[str],
                               vols: np.ndarray) -> np.ndarray:
        if len(pairs) != len(vols):
            raise ValueError("The supplied FX pairs are of different length than the vols")

        # Get the correlations for this subset of pairs
        try:
            corr = self._universe.fx_universe.fx_corrs.instant_fx_spot_corr_matrix(pairs).values
        except Exception as e:
            raise RuntimeError(f"Couldnt find the correlation pairs from FxCorrProvider: {e}")

        # Convert to covariance matrix
        covar = np.dot(np.diag(vols), np.dot(corr, np.diag(vols)))

        # Perform cholesky decomposition to get L
        return np.linalg.cholesky(covar)
