import numpy as np
from typing import Tuple, List


class CashFlowRiskMetrics(object):
    def __init__(self,
                 var_90: float = np.nan,
                 var_95: float = np.nan,
                 var_99: float = np.nan,
                 npv: float = np.nan,
                 std_dev: float = np.nan,
                 mean: float = np.nan):
        """"""
        self.var_90 = var_90
        self.var_95 = var_95
        self.var_99 = var_99
        self.npv = npv
        self.std_dev = std_dev
        self.mean = mean

    @staticmethod
    def header() -> List[str]:
        return ['Var90', 'Var95', 'Var99', 'NPV', 'StdDev', 'Mean']

    def to_row(self) -> List:
        return [self.var_90, self.var_95, self.var_99, self.npv, self.std_dev, self.mean]

    def to_dict(self, pnl: List[float] = None) -> dict:
        """ Convenience method to convert to object to a dictionary """
        return {"pnl": pnl if pnl else [],
                "var_90": self.var_90,
                "var_95": self.var_95,
                "var_99": self.var_99,
                "npv": self.npv,
                "std_dev": self.std_dev
                }

    @property
    def value_conf_interval_95(self) -> Tuple[float, float]:
        return (self.npv - 2 * self.std_dev,
                self.npv + 2 * self.std_dev)

    @staticmethod
    def from_deterministic(npv: float) -> 'CashFlowRiskMetrics':
        return CashFlowRiskMetrics(var_90=0., var_95=0., var_99=0., npv=npv, std_dev=0., mean=0.)

    def __repr__(self):
        ci = self.value_conf_interval_95
        return f'VaR (90)    : {self.var_90}\n' \
               f'VaR (95)    : {self.var_95}\n' \
               f'VaR (99)    : {self.var_99}\n' \
               f'Mean(PnL)   : {self.mean}\n' \
               f'StdDev(PnL) : {self.std_dev}\n' \
               f'NPV         : {self.npv}\n' \
               f'NPV 95% C.I.: {ci[0], ci[1]}'
