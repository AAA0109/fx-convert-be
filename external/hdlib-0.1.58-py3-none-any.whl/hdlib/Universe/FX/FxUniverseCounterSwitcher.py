from typing import Dict

from hdlib.Core.Currency import Currency
from hdlib.Core.FxPairInterface import FxPairInterface
from hdlib.DataProvider.Fx.FxCorrelations import FxCorrelations
from hdlib.DataProvider.Fx.FxSpotVols import FxSpotVols
from hdlib.TermStructures.ForwardCurve import RatioForwardCurve, InverseForwardCurve
from hdlib.Universe.Asset.FxAsset import FxAsset
from hdlib.Universe.FX.FxAssets import FxAssets
from hdlib.Universe.FX.FxUniverse import FxUniverse
from hdlib.Universe.Universe import Universe

import pandas as pd
import numpy as np


def vol_XY(vol_XU: float, vol_YU: float, rho_XU__YU: float) -> float:
    """
    Compute the volatility of XXX/YYY
    :param vol_XU: float, vol of XXX/USD
    :param vol_YU: float, vol of YYY/USD
    :param rho_XU__YU: float,  corr(XXX/USD, YYY/USD)
    :return: float, vol of XXX/YYY
    """
    var = vol_YU ** 2 + vol_XU ** 2 - 2 * rho_XU__YU * vol_YU * vol_XU
    return np.sqrt(var)


def corr_XY_UY(vol_XU: float, vol_YU: float, rho_XU__YU: float):
    """
    Compute the corr(XXX/YYY, USD/YYY)
    :param vol_XU: float, vol of XXX/USD
    :param vol_YU:  float, vol of YYY/USD
    :param rho_XU__YU: float,  corr(XXX/USD, YYY/USD)
    :return: float, corr(XXX/YYY, USD/YYY)
    """
    rho = -rho_XU__YU
    v_XY = vol_XY(vol_YU=vol_YU, vol_XU=vol_XU, rho_XU__YU=rho_XU__YU)
    c = (vol_YU + rho * vol_XU) / v_XY
    return c


def corr_XY_ZY(vol_XU: float, vol_YU: float, vol_ZU: float,
               rho_XU__YU: float, rho_ZU__YU: float, rho_XU__ZU: float):
    """
    Compute corr(XXX/YYY, ZZZ/YYY)
    :param vol_XU: float, vol of XXX/USD
    :param vol_YU: float, vol of YYY/USD
    :param vol_ZU: float, vol of ZZZ/USD
    :param rho_XU__YU:  float,  corr(XXX/USD, YYY/USD)
    :param rho_ZU__YU:  float,  corr(ZZZ/USD, YYY/USD)
    :param rho_XU__ZU: float,  corr(XXX/USD, ZZZ/USD)
    :return: float, corr(XXX/YYY, ZZZ/YYY)
    """
    v_XY = vol_XY(vol_XU=vol_XU, vol_YU=vol_YU, rho_XU__YU=rho_XU__YU)
    v_ZY = vol_XY(vol_XU=vol_ZU, vol_YU=vol_YU, rho_XU__YU=rho_ZU__YU)
    v_XZ = vol_XY(vol_XU=vol_XU, vol_YU=vol_ZU, rho_XU__YU=rho_XU__ZU)

    v_ZX = v_XZ

    numer = v_XY ** 2 + v_ZY ** 2 - v_ZX ** 2
    demon = 2 * v_XY * v_ZY
    return numer / demon


class FxUniverseCounterSwitcher:

    def switch_counter(self,
                       universe: Universe,
                       new_domestic: Currency,
                       new_pairs: Dict[str, FxPairInterface]) -> Universe:
        """
        Create a new counter currency universe, starting from a XXX/USD universe, and switching to a XXX/YYY universe
        :param universe: Universe, and existing XXX/USD universe
        :param new_domestic: Currency, the new domestic (counter) currency, new universe will have this counter cncy
        :param new_pairs: Dict[str, FxPairInterface], map from currency names to the new FX pairs in the the
            counter currency universe
        :return: Universe, new universe with new_domestic as the counter currency
        """
        if not universe.cntr_currency or universe.cntr_currency.get_mnemonic() != 'USD':
            raise ValueError("You can only switch from a USD counter currency universe")

        if new_domestic.get_mnemonic() == 'USD':
            return universe

        ref_date = universe.ref_date
        old_fx_u = universe.fx_universe
        old_fx_assets = old_fx_u.fx_assets
        old_fx_vols = old_fx_u.fx_vols
        old_fx_corrs = old_fx_u.fx_corrs

        # TODO: ensure that the necessary discount curve for new domestic is in the new counter universe, we may
        # have to imply it from USD and the FX forward curve

        fx_assets = FxAssets(ref_date=ref_date)
        curr_to_old_pairs = universe.fx_universe.fx_assets.get_pairs_map_for_counter_currency(
            counter='USD')

        # vols = {EurUsd.name: 0.071, GbpUsd.name: 0.0632, CadUsd.name: 0.05}
        vols: Dict[str, float] = {}

        quote_to_usd_asset = old_fx_assets.get_asset(pair=curr_to_old_pairs[new_domestic.get_mnemonic()])
        new_dom_usd_name = quote_to_usd_asset.name
        vol_YU = old_fx_vols.vol_spot(pair=quote_to_usd_asset.fx_pair)

        for currency in universe.currencies:
            new_pair = new_pairs.get(currency.get_mnemonic(), None)
            # if currency != new_domestic:
            if new_pair:
                if currency.get_mnemonic() == 'USD':
                    # 1) Forward Curve
                    new_fwd_curve = InverseForwardCurve(curve=quote_to_usd_asset.fwd_curve)

                    # 2) Vol
                    vols[new_pair.name] = vol_YU

                else:
                    # 1) Forward Curve
                    base_to_usd_asset = old_fx_assets.get_asset(pair=curr_to_old_pairs[currency.get_mnemonic()])
                    new_fwd_curve = RatioForwardCurve(curve_numerator=base_to_usd_asset.fwd_curve,
                                                      curve_denom=quote_to_usd_asset.fwd_curve)

                    # 2) Vol
                    vol_XU = old_fx_vols.vol_spot(pair=base_to_usd_asset.fx_pair)
                    rho_XU__DU = old_fx_corrs.instant_fx_spot_corr(pairs=(base_to_usd_asset.fx_pair,
                                                                          quote_to_usd_asset.fx_pair))
                    vols[new_pair.name] = vol_XY(vol_XU=vol_XU, vol_YU=vol_YU, rho_XU__YU=rho_XU__DU)

                fx_assets.add_asset(asset=FxAsset(fx_pair=new_pair, fwd_curve=new_fwd_curve, vol_surface=None))

        # =============================
        # Correlations
        # =============================
        pair_names = [pair.name for pair in new_pairs.values()]  # get names of pairs to put into matrix
        index = {i: pair for i, pair in enumerate(pair_names)}

        num_pairs = len(pair_names)
        corrs = pd.DataFrame(index=pair_names, columns=pair_names, dtype=float)
        for i in range(num_pairs):
            pair_XY = pair_names[i]
            curr_X = pair_XY[:3]
            XU_name = f"{curr_X}/USD"

            vol_XU = old_fx_vols.vol_spot(name=XU_name)
            rho_XU__YU = old_fx_corrs.instant_fx_spot_corr(names=(XU_name, new_dom_usd_name))

            for j in range(0, i + 1):
                if i == j:
                    corrs.loc[index[i], index[j]] = 1.
                else:
                    pair_ZY = pair_names[j]
                    curr_Z = pair_ZY[:3]
                    ZU_name = f"{curr_Z}/USD"

                    vol_ZU = old_fx_vols.vol_spot(name=ZU_name)
                    rho_ZU__YU = old_fx_corrs.instant_fx_spot_corr(names=(ZU_name, new_dom_usd_name))

                    if curr_X == 'USD':
                        c_XY_ZY = corr_XY_UY(vol_XU=vol_ZU, vol_YU=vol_YU, rho_XU__YU=rho_ZU__YU)
                    elif curr_Z == 'USD':
                        c_XY_ZY = corr_XY_UY(vol_XU=vol_XU, vol_YU=vol_YU, rho_XU__YU=rho_XU__YU)
                    else:
                        rho_XU__ZU = old_fx_corrs.instant_fx_spot_corr(names=(XU_name, ZU_name))
                        c_XY_ZY = corr_XY_ZY(vol_XU=vol_XU,
                                             vol_YU=vol_YU,
                                             vol_ZU=vol_ZU,
                                             rho_XU__YU=rho_XU__YU, rho_ZU__YU=rho_ZU__YU, rho_XU__ZU=rho_XU__ZU)

                    corrs.loc[index[i], index[j]] = c_XY_ZY
                    corrs.loc[index[j], index[i]] = c_XY_ZY

        # =============================

        new_fx_universe = FxUniverse(ref_date=ref_date,
                                     fx_assets=fx_assets,
                                     fx_vols=FxSpotVols(ref_date=ref_date, vols=vols),
                                     fx_corrs=FxCorrelations(ref_date=ref_date, instant_corr=corrs))
        new_u = Universe(ref_date=ref_date,
                         dc=universe.day_counter,
                         counter_currency=new_domestic,
                         fx_universe=new_fx_universe)
        return new_u
