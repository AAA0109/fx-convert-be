from abc import ABC, abstractmethod
from enum import Enum
from typing import Set, Optional
import numpy as np

from hdlib.DateTime.Date import Date


class RollConvention(Enum):
    """
    Rolling convention Enum. Represents the conventions used to roll dates into proper business dates.
    """
    UNADJUSTED = 'UNADJUSTED'  # Don't roll the date

    FOLLOWING = 'FOLLOWING'  # The following business date
    MODIFIED_FOLLOWING = 'MODIFIED_FOLLOWING'
    HALF_MONTH_MODIFIED_FOLLOWING = 'HALF_MONTH_MODIFIED_FOLLOWING'

    PRECEDING = 'PRECEDING'  # The previous business date
    MODIFIED_PRECEDING = 'MODIFIED_PRECEDING'

    NEAREST = 'NEAREST'  # The nearest business date (either up or down)


class Calendar(ABC):
    """
    Base class for business day calendars.
    """

    @abstractmethod
    def name(self) -> str:
        """ Name of the calendar """
        raise NotImplementedError

    @abstractmethod
    def is_business_day(self, date: Date) -> bool:
        """
        Check if a date is a business date in this calendar
        :param date: Date, the date to check
        :return: bool, True if the date is a business date, else False
        """
        raise NotImplementedError

    @abstractmethod
    def is_weekend(self, weekday: int) -> bool:
        """
        Check if a day of the week is considered a weekend. E.g. 6,7 are weekend days in Western calendars
        :param weekday: int, 1,...,7.  1=Monday, ..., 7=Sunday
        :return: bool, True if the day of week is a weekend
        """
        raise NotImplementedError

    def is_holiday(self, date: Date) -> bool:
        """
        Check if a date is a holiday of this calendar
        :param date: Date, the date
        :return: bool, true if the date is a holiday
        """
        return not self.is_business_day(date=date)

    def adjust(self, date: Date, roll_convention: RollConvention = RollConvention.FOLLOWING) -> Date:
        """
        Adjust a date to the nearest business date. This is done on a copy of the date
        :param date: Date, the date to adjust
        :param roll_convention: RollConvention, the convention for rolling a date to the nearest business date
        :return: Date, adjusted to nearest business date according to rolling convention (from copy of original)
        """
        d1 = date.copy()
        c = roll_convention

        if c == RollConvention.UNADJUSTED or c is None:
            return d1

        if c == RollConvention.FOLLOWING or c == RollConvention.MODIFIED_FOLLOWING \
                or c == RollConvention.HALF_MONTH_MODIFIED_FOLLOWING:
            while self.is_holiday(d1):
                d1 += 1
            if c == RollConvention.MODIFIED_FOLLOWING or c == RollConvention.HALF_MONTH_MODIFIED_FOLLOWING:
                if d1.month != date.month:
                    return self.adjust(date, RollConvention.PRECEDING)
                if c == RollConvention.HALF_MONTH_MODIFIED_FOLLOWING:
                    if date.day <= 15 and d1.day > 15:
                        return self.adjust(date, RollConvention.PRECEDING)
        elif c == RollConvention.PRECEDING or c == RollConvention.MODIFIED_PRECEDING:
            while self.is_holiday(d1):
                d1 -= 1
            if c == RollConvention.MODIFIED_PRECEDING and d1.month != date.month:
                return self.adjust(date, RollConvention.FOLLOWING)
        elif c == RollConvention.NEAREST:
            d2 = date.copy()
            while self.is_holiday(d1) and self.is_holiday(d2):
                d1 += 1
                d2 -= 1
            if self.is_holiday(d1):
                return d2
            return d1
        else:
            raise ValueError("Unknown rolling convention")

        return d1

    def days_between(self,
                     start: Date,
                     end: Date,
                     include_start: bool = True,
                     include_end: bool = False) -> int:
        """
        Count Number of dates between two dates (always includes start date).
        :param start: Date, the starting date
        :param end: Date, the ending date
        :param include_start: bool, if ture include the starting date in count
        :param include_end: bool, if true include the endpoint in count
        :return: Number of dates between two dates
        """
        if start == end:
            return 1 if include_start or include_end and self.is_business_day(start) else 0

        d = Date.from_datetime(date=start)
        num_days = 1 if include_start and self.is_business_day(d) else 0
        d += 1
        while d < end:
            if self.is_business_day(d):
                num_days += 1
            d += 1

        if include_end and self.is_business_day(d):
            num_days += 1

        return num_days


class NullCalendar(Calendar):
    """
    Null calendar. Every day is a business day
    """

    def name(self) -> str:
        return "NULL"

    def is_business_day(self, date: Date) -> bool:
        return True

    def is_weekend(self, weekday: int):
        return False

    def days_between(self,
                     start: Date,
                     end: Date,
                     include_start: bool = True,
                     include_end: bool = False) -> int:
        if start == end:
            return 1 if include_start or include_end else 0

        days = Date.days_between(start=start, end=end)
        return days + (include_start + include_end - 1)


class CustomCalendar(Calendar):
    def __init__(self,
                 weekend_days: Set[int],
                 holidays: Optional[Set[Date]] = None,
                 name: str = "Custom"):
        self._name = name
        self._weekend_days = weekend_days
        self._holidays = holidays or set()

    def name(self) -> str:
        return self._name

    def is_weekend(self, weekday: int):
        return weekday in self._weekend_days

    def is_business_day(self, date: Date) -> bool:
        if self.is_weekend(date.day_of_week()):
            return False
        if date in self._holidays:
            return False
        return True

    @classmethod
    def new_western_no_holidays(cls) -> 'CustomCalendar':
        """ Create a Western-style calendar with no holidays """
        return cls(name="WESTERN", weekend_days={6, 7})


# =======================
# Pointer to Implemenation Approach
# =======================


class CalendarImpl(ABC):

    def is_business_day(self, date: Date) -> bool:
        if self.is_weekend(date.day_of_week()):
            return False
        return self._is_business_day(date)

    @abstractmethod
    def name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def is_weekend(self, weekday: int):
        raise NotImplementedError

    @abstractmethod
    def _is_business_day(self, date: Date) -> bool:
        raise NotImplementedError


class WesternCalendarImpl(CalendarImpl, ABC):
    def is_weekend(self, weekday: int):
        return weekday == 6 or weekday == 7

    @staticmethod
    def easter_monday(year: int):
        return _west_easter_mondays[year - 1901]


class OrthodoxCalendarImpl(CalendarImpl, ABC):
    def is_weekend(self, weekday: int):
        return weekday == 6 or weekday == 7

    @staticmethod
    def easter_monday(year: int):
        return _orthodox_easter_mondays[year - 1901]


_west_easter_mondays = [
    98, 90, 103, 95, 114, 106, 91, 111, 102,  # // 1901 - 1909
    87, 107, 99, 83, 103, 95, 115, 99, 91, 111,  # // 1910 - 1919
    96, 87, 107, 92, 112, 103, 95, 108, 100, 91,  # // 1920 - 1929
    111, 96, 88, 107, 92, 112, 104, 88, 108, 100,  # // 1930 - 1939
    85, 104, 96, 116, 101, 92, 112, 97, 89, 108,  # // 1940 - 1949
    100, 85, 105, 96, 109, 101, 93, 112, 97, 89,  # // 1950 - 1959
    109, 93, 113, 105, 90, 109, 101, 86, 106, 97,  # // 1960 - 1969
    89, 102, 94, 113, 105, 90, 110, 101, 86, 106,  # // 1970 - 1979
    98, 110, 102, 94, 114, 98, 90, 110, 95, 86,  # // 1980 - 1989
    106, 91, 111, 102, 94, 107, 99, 90, 103, 95,  # // 1990 - 1999
    115, 106, 91, 111, 103, 87, 107, 99, 84, 103,  # // 2000 - 2009
    95, 115, 100, 91, 111, 96, 88, 107, 92, 112,  # // 2010 - 2019
    104, 95, 108, 100, 92, 111, 96, 88, 108, 92,  # // 2020 - 2029
    112, 104, 89, 108, 100, 85, 105, 96, 116, 101,  # // 2030 - 2039
    93, 112, 97, 89, 109, 100, 85, 105, 97, 109,  # // 2040 - 2049
    101, 93, 113, 97, 89, 109, 94, 113, 105, 90,  # // 2050 - 2059
    110, 101, 86, 106, 98, 89, 102, 94, 114, 105,  # // 2060 - 2069
    90, 110, 102, 86, 106, 98, 111, 102, 94, 114,  # // 2070 - 2079
    99, 90, 110, 95, 87, 106, 91, 111, 103, 94,  # // 2080 - 2089
    107, 99, 91, 103, 95, 115, 107, 91, 111, 103,  # // 2090 - 2099
    88, 108, 100, 85, 105, 96, 109, 101, 93, 112,  # // 2100 - 2109
    97, 89, 109, 93, 113, 105, 90, 109, 101, 86,  # // 2110 - 2119
    106, 97, 89, 102, 94, 113, 105, 90, 110, 101,  # // 2120 - 2129
    86, 106, 98, 110, 102, 94, 114, 98, 90, 110,  # // 2130 - 2139
    95, 86, 106, 91, 111, 102, 94, 107, 99, 90,  # // 2140 - 2149
    103, 95, 115, 106, 91, 111, 103, 87, 107, 99,  # // 2150 - 2159
    84, 103, 95, 115, 100, 91, 111, 96, 88, 107,  # // 2160 - 2169
    92, 112, 104, 95, 108, 100, 92, 111, 96, 88,  # // 2170 - 2179
    108, 92, 112, 104, 89, 108, 100, 85, 105, 96,  # // 2180 - 2189
    116, 101, 93, 112, 97, 89, 109, 100, 85, 105  # // 2190 - 2199
]

_orthodox_easter_mondays = [
    105, 118, 110, 102, 121, 106, 126, 118, 102,  # // 1901 - 1909
    122, 114, 99, 118, 110, 95, 115, 106, 126, 111,  # // 1910 - 1919
    103, 122, 107, 99, 119, 110, 123, 115, 107, 126,  # // 1920 - 1929
    111, 103, 123, 107, 99, 119, 104, 123, 115, 100,  # // 1930 - 1939
    120, 111, 96, 116, 108, 127, 112, 104, 124, 115,  # // 1940 - 1949
    100, 120, 112, 96, 116, 108, 128, 112, 104, 124,  # // 1950 - 1959
    109, 100, 120, 105, 125, 116, 101, 121, 113, 104,  # // 1960 - 1969
    117, 109, 101, 120, 105, 125, 117, 101, 121, 113,  # // 1970 - 1979
    98, 117, 109, 129, 114, 105, 125, 110, 102, 121,  # // 1980 - 1989
    106, 98, 118, 109, 122, 114, 106, 118, 110, 102,  # // 1990 - 1999
    122, 106, 126, 118, 103, 122, 114, 99, 119, 110,  # // 2000 - 2009
    95, 115, 107, 126, 111, 103, 123, 107, 99, 119,  # // 2010 - 2019
    111, 123, 115, 107, 127, 111, 103, 123, 108, 99,  # // 2020 - 2029
    119, 104, 124, 115, 100, 120, 112, 96, 116, 108,  # // 2030 - 2039
    128, 112, 104, 124, 116, 100, 120, 112, 97, 116,  # // 2040 - 2049
    108, 128, 113, 104, 124, 109, 101, 120, 105, 125,  # // 2050 - 2059
    117, 101, 121, 113, 105, 117, 109, 101, 121, 105,  # // 2060 - 2069
    125, 110, 102, 121, 113, 98, 118, 109, 129, 114,  # // 2070 - 2079
    106, 125, 110, 102, 122, 106, 98, 118, 110, 122,  # // 2080 - 2089
    114, 99, 119, 110, 102, 115, 107, 126, 118, 103,  # // 2090 - 2099
    123, 115, 100, 120, 112, 96, 116, 108, 128, 112,  # // 2100 - 2109
    104, 124, 109, 100, 120, 105, 125, 116, 108, 121,  # // 2110 - 2119
    113, 104, 124, 109, 101, 120, 105, 125, 117, 101,  # // 2120 - 2129
    121, 113, 98, 117, 109, 129, 114, 105, 125, 110,  # // 2130 - 2139
    102, 121, 113, 98, 118, 109, 129, 114, 106, 125,  # // 2140 - 2149
    110, 102, 122, 106, 126, 118, 103, 122, 114, 99,  # // 2150 - 2159
    119, 110, 102, 115, 107, 126, 111, 103, 123, 114,  # // 2160 - 2169
    99, 119, 111, 130, 115, 107, 127, 111, 103, 123,  # // 2170 - 2179
    108, 99, 119, 104, 124, 115, 100, 120, 112, 103,  # // 2180 - 2189
    116, 108, 128, 119, 104, 124, 116, 100, 120, 112  # // 2190 - 2199
]
