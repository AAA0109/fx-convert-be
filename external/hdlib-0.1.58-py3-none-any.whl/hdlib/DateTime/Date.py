import calendar
import datetime as dt
from typing import Union, Iterator
from copy import deepcopy
import pytz


class Date(dt.datetime):
    """
    Date class, extends datetime.datetime, adding some convenience functionality
    """

    timezone_UTC = pytz.UTC
    timezone_NY = pytz.timezone("America/New_York")

    @classmethod
    def to_date(cls, other: Union['Date', dt.datetime, dt.date, str, int]) -> 'Date':
        """
        Convert a date-like object to an actual 'Date' object.
        :param other: date-like, an object to convert into a proper 'Date'
        :return: Date, the date representation of this other date
        """
        if isinstance(other, Date):
            return other
        elif isinstance(other, dt.datetime):
            return Date.from_datetime(other)
        elif isinstance(other, dt.date):
            return Date.from_datetime_date(other)
        elif isinstance(other, str):
            try:
                return Date.from_str(other)
            except Exception:
                try:
                    return Date.from_str_iso(other)
                except Exception:
                    return Date.from_str_utc(other)
        elif isinstance(other, int):
            return Date.from_int(other)
        # Some type we can't handle.
        raise TypeError(f"unexpected type in to_date")

    @classmethod
    def create(cls,
               year=None, month=None, day=None, hour=0, minute=0, second=0, microsecond=0,
               tzinfo=pytz.UTC,
               ymd: int = None) -> 'Date':
        if ymd is not None:
            year = int(ymd / 10000)
            month = int(ymd / 100) % 100
            day = ymd % 100
        return cls(year=year, month=month, day=day, hour=hour, minute=minute, second=second, microsecond=microsecond,
                   tzinfo=tzinfo)

    @classmethod
    def from_datetime(cls, date: dt.datetime, tzinfo=pytz.UTC) -> 'Date':
        """ Create a Date from a datetime object """
        tzinfo_ = date.tzinfo or tzinfo
        return cls(year=date.year, month=date.month, day=date.day, hour=date.hour, minute=date.minute,
                   second=date.second, microsecond=date.microsecond, tzinfo=tzinfo_, fold=date.fold)

    @classmethod
    def from_datetime_date(cls, date: dt.date) -> 'Date':
        """ Create a Date from a datetime.date object """
        return cls(year=date.year, month=date.month, day=date.day, tzinfo=pytz.UTC)

    @classmethod
    def from_str(cls, date: str, fmt: str = '%Y-%m-%d', tzinfo=pytz.UTC) -> 'Date':
        """
        Create a Date obj from string with known format
        :param date: str, a date, e.g. '2015-02-01'
        :param fmt: str, format of the date string, e.g. '%Y-%m-%d'
        :return: Date, the str date converted to Date obj
        """
        return cls.from_datetime(dt.datetime.strptime(date, fmt), tzinfo)

    @classmethod
    def from_str_iso(cls, date: str) -> 'Date':
        """
        Create a Date obj from string in ISO format: '2022-02-03 00:00:00+00:00'
        :param date: str, int ISO format
        :return: Date, the str date converted to Date obj
        """
        return cls.from_datetime(dt.datetime.fromisoformat(date))

    @classmethod
    def from_str_utc(cls, date: str) -> 'Date':
        return cls.from_datetime(dt.datetime.strptime(date, "%Y-%m-%dT%H:%M:%S%fZ"))

    @classmethod
    def from_int(cls, date: int, tzinfo=pytz.UTC) -> 'Date':
        """
        Create a Date obj from an int representation
        :param date: int, e.g. 20180101
        :param tzinfo: tzinfo, time zone information
        :return: Date, the int date converted to Date obj
        """
        return cls.from_str(date=str(date), fmt='%Y%m%d', tzinfo=tzinfo)

    def to_int(self) -> int:
        """ Convert Date to int. Only the date (no time) """
        return 10000 * self.year + 100 * self.month + self.day

    def first_day_of_month(self) -> 'Date':
        """ Return the date of the first day of this month. """
        return Date.create(year=self.year, month=self.month, day=1)

    def first_of_next_month(self) -> 'Date':
        """ Return the date on the first of the next month. """
        month = self.month
        if month < 12:
            return Date.create(year=self.year, month=self.month + 1, day=1)
        else:
            return Date.create(year=self.year + 1, month=1, day=1)

    def last_day_of_month(self) -> 'Date':
        """ Return the date of the last day of this month. """
        year, month = self.year, self.month
        if month == 2:
            day = 29 if calendar.isleap(self.year) else 28
        elif month == 1 or month == 3 or month == 5 or month == 7 or month == 8 or month == 10 or month == 12:
            day = 31
        else:
            day = 30
        return Date.create(year=year, month=month, day=day)

    def start_of_day(self) -> 'Date':
        """ Return 00:00 of this day. """
        return Date.create(day=self.day, month=self.month, year=self.year, tzinfo=self.tzinfo)

    def start_of_next_day(self) -> 'Date':
        """ Return 00:00 of the next day """
        return self.start_of_day() + 1

    @property
    def day_of_year(self) -> int:
        """ Get the day of year of a date. Jan 1st = 1"""
        return self.timetuple().tm_yday

    @classmethod
    def today(cls) -> 'Date':
        date_now = cls.now()
        return Date(day=date_now.day, year=date_now.year, month=date_now.month, tzinfo=date_now.tzinfo)

    def copy(self) -> 'Date':
        """ Create a deep copy of this date """
        return deepcopy(self)

    @classmethod
    def now(cls, tz=None) -> 'Date':
        """ Overload datetime.now() so it uses UTC time and time zone information by default. """
        if tz is None:
            dt_date = dt.datetime.now(tz=Date.timezone_UTC)
        else:
            dt_date = dt.datetime.now(tz=tz)
        return Date.from_datetime(dt_date)

    def to_str(self, fmt: str = '%Y-%m-%d') -> str:
        return self.strftime(fmt)

    def day_of_week(self) -> int:
        """ Day of the week: Monday = 1, ..., Sunday = 7 """
        return self.weekday() + 1

    def __add__(self, amount: Union[dt.timedelta, int]) -> 'Date':
        if isinstance(amount, dt.timedelta):
            return super().__add__(amount)

        return super().__add__(dt.timedelta(days=amount))

    def __sub__(self, amount: Union[dt.timedelta, int, 'Date']) -> 'Date':
        if isinstance(amount, dt.timedelta) or isinstance(amount, Date):
            return super().__sub__(amount)

        return super().__sub__(dt.timedelta(days=amount))

    @staticmethod
    def days_between(start: Union['Date', dt.datetime], end: Union['Date', dt.datetime]) -> int:
        """
        Calculate the number of days between two dates, ignoring granularity below a day
        :param start: Date, the start date
        :param end: Date, the end date
        :return: int, number of days between start and end
        """
        return (dt.datetime.date(end) - dt.datetime.date(start)).days

    @staticmethod
    def yield_range(start: 'Date', end: 'Date') -> Iterator['Date']:
        """
        Yields a range of dates between start and end, incrementing by one day
        :param start: Date, the start date
        :param end: Date, the end date
        :return: Iterator of Date objects, for each date between start and end inclusive
        """
        date = start
        while date <= end:
            yield date
            date += 1

    # def __new__(cls, year=None, month=None, day=None, hour=0, minute=0, second=0,
    #             microsecond=0, tzinfo=pytz.UTC, fold=0):
    #     return super().__new__(cls, year=year, month=month, day=day, hour=hour, minute=minute,
    #                            second=second, microsecond=microsecond, tzinfo=tzinfo, fold=fold)

    def __repr__(self) -> str:
        return '{0}({1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9})'.format(self.__class__.__name__,
                                                                         self.year, self.month, self.day,
                                                                         self.hour, self.minute, self.second,
                                                                         self.microsecond, self.tzinfo, self.fold)

    def __getnewargs__(self) -> tuple:
        return (self.year, self.month, self.day,
                self.hour, self.minute, self.second,
                self.microsecond, self.tzinfo, self.fold)

    def __reduce__(self) -> tuple:
        return (self.__class__, (self.year, self.month, self.day,
                                 self.hour, self.minute, self.second,
                                 self.microsecond, self.tzinfo, self.fold))
