from abc import ABC, abstractmethod
import numpy as np


class VolEstimator(ABC):
    """
    Base class for univariate historical volatility estimation.
    Examples: EWMA, GARCH, flat standard deviation, etc
    """

    @abstractmethod
    def estimate(self, returns: np.ndarray) -> float:
        """
        Main method to estimate vol for a set of returns
        :param returns: np.ndarray, input returns data
        :return: float, volatility estimate
        """
        raise NotImplementedError

    def sliding_estimate(self, returns: np.ndarray, window: int, backfill: bool = True) -> np.ndarray:
        """
        A sliding window estimate of volatilies from a set of returns
        :param returns: np.ndarray, input returns data
        :param window: int, sliding window size
        :param backfill: bool, if true, ensures that the output vols are of the same size as returns, otherwise the
            size will be len(returns) - window + 1.  Backfill is necessary to perform de-vol/re-vol, and can be
            overriden (rather than just a flat backfill)
        :return: np.ndarray, vol estimates
        """
        window = min(window, len(returns))
        vols = np.asarray([self.estimate(chunk) for chunk in np.lib.stride_tricks.sliding_window_view(returns, window)])
        if backfill:
            backfilled = self._backfill(data=returns, vols=vols)
            vols = np.concatenate((backfilled, vols))
        return vols

    def revol_returns(self, returns: np.ndarray, window: int) -> np.ndarray:
        """
        Perform a devolatilization/revolatalization step, which takes a time series of returns, removes the
        time-dependent volatility, and rescales them according to the top day estimate of volatility
        :param returns: np.ndarray, input returns data
        :param window: int, sliding window size
        :return: np.ndarray, returns series that has a volatility matching estimate for top day vol
        """
        vols = self.sliding_estimate(returns=returns, window=window, backfill=True)
        out = vols[-1] * returns / vols
        return out

    def _backfill(self, data: np.ndarray, vols: np.ndarray) -> np.ndarray:
        """ Note: you can ovveride this in the estimator, the base impl is to flat backfill the vols """
        missing = len(data) - len(vols)
        return np.full(missing, vols[0], dtype=float)


class VolEstimatorConst(VolEstimator):
    """
    Trivial volatility estimator, which is just the standard deviation in any given window
    """

    def estimate(self, returns: np.ndarray) -> float:
        return np.std(returns)


class EwmaVolEstimator(VolEstimator):
    """ """

    def __init__(self, default_window: int = 250):
        self._default_window = default_window

    def estimate(self, returns: np.ndarray) -> float:
        return np.std(returns)

    def sliding_estimate(self, returns: np.ndarray, window: int, backfill: bool = True) -> np.ndarray:
        """
        A sliding window estimate of volatilies from a set of returns
        :param returns: np.ndarray, input returns data
        :param window: int, sliding window size
        :param backfill: bool, if true, ensures that the output vols are of the same size as returns, otherwise the
            size will be len(returns) - window + 1.  Backfill is necessary to perform de-vol/re-vol, and can be
            overriden (rather than just a flat backfill)
        :return: np.ndarray, vol estimates
        """
        window = min(window, len(returns))
        vols = np.asarray([self.estimate(chunk) for chunk in np.lib.stride_tricks.sliding_window_view(returns, window)])
        if backfill:
            backfilled = self._backfill(data=returns, vols=vols)
            vols = np.concatenate((backfilled, vols))
        return vols
