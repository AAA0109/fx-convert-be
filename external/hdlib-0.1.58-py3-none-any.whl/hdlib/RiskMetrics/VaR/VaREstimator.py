from abc import ABC, abstractmethod
import numpy as np


class VaREstimator(ABC):
    """
    Base class for estimating Value-at-Risk (VaR) from a univariate time series of PnL/returns data (returns at some
    holding period)
    """

    @abstractmethod
    def estimate(self, returns: np.ndarray, var_level: float = 0.99) -> float:
        """
        Main method, estimate the VaR for this entire times series of PnL/returns data (increasing time)
        :param returns: np.ndarray, returns/PnL data (increasing time)
        :param var_level: float, the VaR level
        :return: float, the VaR estimate
        """
        raise NotImplementedError

    def sliding_estimate(self, returns: np.ndarray, window: int) -> np.ndarray:
        """
        Sliding window estimates of VaR. Can be fed into backtest
        :param returns: np.ndarray, returns/PnL data (increasing time)
        :param window: int, the window size for estimation
        :return: np.ndarray, array of estimates of size len(returns) - window + 1, containing VaR estimates in a
        sliding fashion
        """
        estimates = [self.estimate(chunk) for chunk in np.lib.stride_tricks.sliding_window_view(returns, window)]
        return np.asarray(estimates)

