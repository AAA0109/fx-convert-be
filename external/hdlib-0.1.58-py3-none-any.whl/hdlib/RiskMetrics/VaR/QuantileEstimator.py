from abc import ABC, abstractmethod
import numpy as np
from typing import Iterable, Generator
from scipy.stats import t, norm


class QuantileEstimator(ABC):
    """ Base class for quantile estimation, e.g. empirical or via distribution fit """

    @abstractmethod
    def quantile(self, data: np.ndarray, alpha: float) -> float:
        """
        Main method to estimate a single quantile
        :param data: np.ndarray, the uni-variate data series
        :param alpha: float, which quantile (e.g. 0.01, 0.99)
        :return: float, the quantile estimate
        """
        raise NotImplementedError

    def quantiles(self, data: np.ndarray, alphas: Iterable[float]) -> Generator:
        """
        Estiamte quantiles at multiple levels (more efficient when a distribution fit is needed)
        :param data: np.ndarray, the univariate data series
        :param alphas: Iterable of which quantiles (e.g. 0.01, 0.99)
        :return: Generator, yeilding each of the quantiles requested
        """
        for q in alphas:
            yield self.quantile(data=data, alpha=q)


class EmpiricalQuantileEsimator(QuantileEstimator):
    """ Estimates quantile using empirical distribution """

    def quantile(self, data: np.ndarray, alpha: float) -> float:
        return np.quantile(data, alpha)


class StudentQuantileEstimator(QuantileEstimator):
    """ Estimates quantile using a student T fit """

    def quantile(self, data: np.ndarray, alpha: float) -> float:
        t_dist_params = t.fit(data)
        x = t.ppf(alpha, *t_dist_params)
        return x

    def quantiles(self, data: np.ndarray, quantiles: Iterable[float]) -> Generator:
        t_dist_params = t.fit(data)
        qs = t.ppf(quantiles, *t_dist_params)
        for q in qs:
            yield q


class NormalQuantileEstimator(QuantileEstimator):
    """ Estimates quantile using a normal distribution fit """

    def quantile(self, data: np.ndarray, alpha: float) -> float:
        params = norm.fit(data)
        x = norm.ppf(alpha, *params)
        return x

    def quantiles(self, data: np.ndarray, quantiles: Iterable[float]) -> Generator:
        params = norm.fit(data)
        qs = norm.ppf(quantiles, *params)
        for q in qs:
            yield q
