default_app_config = 'tests.validaddrel.apps.AddRelationAppConfig'
