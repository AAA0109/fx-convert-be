from abc import ABC, abstractmethod
from typing import Optional
from enum import Enum

import dateutil.rrule as rr

from hdlib.DateTime.Date import Date
from hdlib.DateTime.Calendar.Calendar import Calendar, CustomCalendar, NullCalendar, RollConvention


class DayCountConvention(Enum):
    ACT_360 = "Actual/360"
    ACT_365 = "Actual/365"
    ACT_365_25 = "Actual/365.25"
    BUS_252 = "Business/252"


class DateGenerator(ABC):
    """
    Base class for date generators, objects that generate some set (possibly infinite) of dates.
    """

    def __init__(self):
        # Represents the "current date" of the date generator.
        # We represent the date generator having no more dates via the current date being None.
        self._current_date: Optional[Date] = None

    def generate(self) -> Optional[Date]:
        """
        Return the currently stored date and move the generator to the next date.
        """
        date = self._current_date
        self.increment()
        return date

    def advance(self, number: int = 1) -> Optional[Date]:
        """
        Advance the date counter by some number of days, returning the next date.
        """
        for _ in range(number):
            self.increment()
        return self.current()

    def current(self) -> Optional[Date]:
        return self._current_date

    @abstractmethod
    def increment(self) -> Optional[Date]:
        """
        Move the date generator to the next date and return that date.
        :return: Returns the next date or None if there is no next date.
        """
        raise NotImplementedError

    def iterate(self):
        """
        Act as a generator.
        """
        while self._current_date is not None:
            yield self.generate()

    def is_ended(self) -> bool:
        """
        Returns true when it is known that there are no dates left
        """
        return self._current_date is None


class DateGeneratorFromCalendar(DateGenerator):
    """
    Generate successive buisiness dates given some calendar, start date, and (optional) end date.
    """

    def __init__(self, start: Date, calendar: Calendar = NullCalendar(), end: Optional[Date] = None):
        super().__init__()
        self._calendar = calendar
        self._start_date = start
        self._end_date = end

        self._current_date = start
        # Recall that we represent the date generator having no more dates via the current date being None.
        if self._end_date is not None and self._end_date < self._start_date:
            self._current_date = None

    def increment(self) -> Optional[Date]:
        if self._current_date is None:
            return None

        self._current_date += 1
        self._current_date = self._calendar.adjust(self._current_date)

        # Check if we have run out of dates.
        if self._end_date is not None and self._end_date < self._current_date:
            self._current_date = None
        return self._current_date


class DateGeneratorRRule(DateGenerator):
    def __init__(self, periodicity: str,
                 start_date: Date,
                 end_date: Optional[Date],
                 calendar: Calendar = NullCalendar(),
                 roll_convention: RollConvention = RollConvention.UNADJUSTED):
        super().__init__()

        self._periodicity = periodicity

        self._start_date = start_date
        self._end_date = end_date

        self._calendar = calendar
        self._roll_convention = roll_convention

        self._gen = self._generator()
        self._current_date = next(self._gen)  # Get rid of the

    def increment(self) -> Optional[Date]:
        date = self._current_date
        if not self.is_ended():
            try:
                self._current_date = next(self._gen)
            except Exception:
                self._current_date = None
        return date

    def _generator(self):
        for d in rr.rrulestr(self._periodicity, dtstart=self._start_date):
            date = self._calendar.adjust(date=Date.from_datetime_date(d),
                                         roll_convention=self._roll_convention)
            if self._end_date and self._end_date < date:
                break
            yield date
