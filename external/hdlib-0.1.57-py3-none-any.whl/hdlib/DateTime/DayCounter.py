from abc import ABC, abstractmethod
from typing import Optional
from enum import Enum

from hdlib.DateTime.Date import Date
from hdlib.DateTime.Calendar.Calendar import Calendar, CustomCalendar, NullCalendar


class DayCountConvention(Enum):
    ACT_360 = "Actual/360"
    ACT_365 = "Actual/365"
    ACT_365_25 = "Actual/365.25"
    BUS_252 = "Business/252"


class DayCounter(ABC):
    """
    Day counter class, used to count the number of days between dates, and to compute the year fraction
    between dates.  New day counters can be created by constructing your own calendar, which determines
    which dates are business dates (e.g. clearing/exchange/libor calendars)
    """

    def __init__(self, include_end_date: bool = False):
        self._include_end_date = include_end_date
        self._end_adjust = 1 if include_end_date else 0

    @abstractmethod
    def year_fraction_from_days(self, days: float) -> float:
        """
        Convert a number of days into a year fraction.
        This is one of two main methods to override
        :param days: int, number of days between two dates
        :return: float, the year fraction corresponding to those days.
        """
        raise NotImplementedError

    def days_between(self, start: Date, end: Date) -> int:
        """
        Count the number of calendar days between two dates.
        This is one of two main methods to override. By default, it computes the actual number of days
        :param start: Date, the start date
        :param end: Date, the end date
        :return: int, number of days between start and end
        """
        return Date.days_between(start=start, end=end) + self._end_adjust

    def year_fraction(self, start: Date, end: Date) -> float:
        """
        Calculate the year fraction between two dates.
        :param start: Date, the start date
        :param end: Date, the end date
        :return: float, year fraction between two dates.
        """
        return self.year_fraction_from_days(days=self.days_between(start=start, end=end))


class DayCounter_ACT_365_25(DayCounter):
    """
    Day counter which assumes 365.25 days in a year, and counts days based on actual dates.
    """

    def __init__(self, include_end_date: bool = False):
        super().__init__(include_end_date=include_end_date)

    def year_fraction_from_days(self, days: float) -> float:
        return float(days) / 365.25


class DayCounter_ACT_365(DayCounter):
    """
    Day counter which assumes 365 days in a year, and counts days based on actual dates.
    """

    def __init__(self, include_end_date: bool = False):
        super().__init__(include_end_date=include_end_date)

    def year_fraction_from_days(self, days: float) -> float:
        """
        Internal Hedge Desk Convention for day counting
        """
        return float(days) / 365.


class DayCounter_HD(DayCounter_ACT_365):
    """
    Default Day counter for HD.
    """
    def __init__(self, include_end_date: bool = False):
        super().__init__(include_end_date=include_end_date)


class DayCounter_ACT_360(DayCounter):
    """
    Day counter which assumes 360 days in a year, and counts days based on actual dates.
    """

    def __init__(self, include_end_date: bool = False):
        super().__init__(include_end_date=include_end_date)

    def year_fraction_from_days(self, days: float) -> float:
        """
        Internal Hedge Desk Convention for day counting
        """
        return float(days) / 360


class DayCounter_Business_252(DayCounter):
    def __init__(self, calendar: Optional[Calendar] = None, include_end_date: bool = False):
        super().__init__(include_end_date=include_end_date)
        self._calendar = calendar or CustomCalendar.new_western_no_holidays()

    def year_fraction_from_days(self, days: float) -> float:
        """
        Internal Hedge Desk Convention for day counting
        """
        return float(days) / 252

    def days_between(self, start: Date, end: Date) -> float:
        """
        Count the number of calendar days between two dates.
        This is one of two main methods to override. By default, it computes the actual number of days
        :param start: Date, the start date
        :param end: Date, the end date
        :return: int, number of days between start and end
        """
        return self._calendar.days_between(start=start, end=end, include_end=self._include_end_date)


def make_day_counter(convention: DayCountConvention = DayCountConvention.ACT_365_25,
                     include_end_date: bool = False,
                     calendar: Calendar = NullCalendar()):
    """ Factory method for a day counter based on convention """
    if convention == DayCountConvention.ACT_360:
        return DayCounter_ACT_360(include_end_date=include_end_date)
    if convention == DayCountConvention.ACT_365:
        return DayCounter_ACT_365(include_end_date=include_end_date)
    if convention == DayCountConvention.ACT_365_25:
        return DayCounter_ACT_365_25(include_end_date=include_end_date)
    if convention == DayCountConvention.BUS_252:
        return DayCounter_Business_252(include_end_date=include_end_date, calendar=calendar)
    raise NotImplementedError("Unsupported calendar convention, please add it here")
