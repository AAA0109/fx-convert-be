from abc import ABC, abstractmethod

from hdlib.DateTime.DayCounter import DayCounter, Date


class TermStructure(ABC):
    """
    Base class for term structures (e.g. Discount Curves, Forward Curves, Yield Curves)
    """

    def __init__(self, ref_date: Date, dc: DayCounter):
        """
        :param ref_date: Date, the valuation/reference date
        :param dc: DayCounter, for measuring time
        """
        self._ref_date = ref_date
        self._dc = dc

    @property
    def ref_date(self) -> Date:
        return self._ref_date

    @property
    def day_counter(self) -> DayCounter:
        return self._dc

    @abstractmethod
    def at_T(self, T: float) -> float:
        """
        Evaluate the term structure at a Time in the future
        :param T: float, time in the future, T >= 0
        :return: float, the term structure evaluated at T
        """
        raise NotImplementedError

    def at_D(self, date: Date) -> float:
        """
        Evaluate the term structure at a date in the future
        :param date: Date, date in the future, date >= ref_date
        :return: float, the term structure evaluated at date
        """
        return self.at_T(T=self._dc.year_fraction(start=self._ref_date, end=date))

    def at_Days(self, days: int):
        """
        Evaluate the term structure at some number of days in the future
        :param days: int, number of days in the future, days >= 0
        :return: float, the term structure evaluated at date
        """
        return self.at_T(T=self._dc.year_fraction_from_days(days))

    def __call__(self, T: float) -> float:
        """
        Evaluate the term structure at a Time in the future
        :param T: float, time in the future, T >= 0
        :return: float, the term structure evaluated at T
        """
        return self.at_T(T)
