from abc import abstractmethod

from hdlib.Core.Currency import Currency

from hdlib.Core.CompanyInterface import CompanyInterface


class AccountInterface(object):
    """
    Class that provides the most basic interface of what information is needed from an account
    """

    @abstractmethod
    def get_name(self) -> str:
        """ Get the name of the account. """
        raise NotImplementedError

    @abstractmethod
    def get_company(self) -> CompanyInterface:
        """ Get the company that owns the account. """
        raise NotImplementedError

    @abstractmethod
    def get_is_live_account(self) -> bool:
        """ Whether this account is a 'live' account. """
        raise NotImplementedError

    @property
    def is_live_account(self) -> bool:
        """ Property alias for get_is_live_account(). """
        return self.get_is_live_account()

    @property
    def domestic_currency(self) -> Currency:
        """ The domestic currency for each account is the same as the company currency """
        return self.get_company().get_company_currency()

    def __hash__(self):
        """ Hash the account. """
        return hash(self.get_name() + ":" + self.get_company().get_name())

    def __str__(self):
        return f"{self.get_company()} @ {self.get_name()}"

    def __repr__(self):
        return f"{self.get_company()} @ {self.get_name()}"


class BasicAccount(AccountInterface):
    """ Implements a basic Account. """

    def __init__(self, name: str, company: CompanyInterface):
        self._name = name
        self._company = company

    def get_name(self) -> str:
        """ Get the name of the account. """
        return self._name

    def get_company(self) -> CompanyInterface:
        """ Get the company that owns the account. """
        return self._company

    def get_is_live_account(self) -> bool:
        """ Whether this account is a 'live' account. """
        return True