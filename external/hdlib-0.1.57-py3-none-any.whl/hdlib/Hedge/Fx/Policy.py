from abc import ABC, abstractmethod
import pandas as pd
from typing import Optional

from hdlib.Hedge.Fx.HedgeCostProvider import HedgeCostProvider
from hdlib.Universe.Universe import Universe
from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccountHistoryProvider
from hdlib.Hedge.Fx.HedgeAccount import HedgeAccountSettings

from hdlib.Hedge.Fx.HedgeAccount import (
    CashExposures
)


class PolicySummary:
    """
    Summarize the result of a policy computing new positions. This includes the newly computed positions,
    an indication of success, and some optional additional info
    """

    def __init__(self, positions: pd.Series, success: bool = True, info: Optional[dict] = None):
        """
        :param positions: pd.Series, the new positions by FxPair (str name)
        :param success: bool, if true then the policy was fully succesful in updating positions
        :param info: dict (optional), used to supply additional information about the policy optimization, e.g.
            for logging
        """
        self.positions = positions
        self.success = success
        self.info = info or {}


class Policy(ABC):
    """ Base class for FX Hedge policies. """

    def __init__(self,
                 settings: HedgeAccountSettings,
                 name: str = "UnknownPolicy"):
        self._settings = settings
        self._name = name

    @property
    def settings(self) -> HedgeAccountSettings:
        return self._settings

    @property
    def name(self) -> str:
        """ Name of policy, just some identifier for logging etc. """
        return self._name

    @abstractmethod
    def new_positions(self,
                      positions: pd.Series,
                      raw_exposures: CashExposures,
                      cash_exposures: CashExposures,
                      universe: Universe,
                      account_history_provider: CashPnLAccountHistoryProvider,
                      cost_provider: HedgeCostProvider) -> PolicySummary:
        """
        Determine the new positions
        :param positions: pd.Series, existing positions in each FX pair (these are the hedge positions)
        :param raw_exposures: CashExposures, not including forward instruments, (ie future cashflows in each currency
            for an account)
        :param cash_exposures: CashExposures, cash exposures, including forwards (which act like pairs of cashflows).
        :param universe: Universe, financial universe on this current date for hedging
        :param account_history_provider: CashPnLAccountHistoryProvider, provides history of hedge account
        :param cost_provider: HedgeCostProvider, provides costs for hedging
        :return: pd.Series, new positions for the hedge
        """
        raise NotImplementedError


class NoHedgeChangePolicy(Policy):
    def __init__(self,
                 settings: HedgeAccountSettings,
                 name: str = "NoHedgeChange"):
        super().__init__(name=name, settings=settings)

    def new_positions(self,
                      positions: pd.Series,
                      raw_exposures: CashExposures,
                      cash_exposures: CashExposures,
                      universe: Universe,
                      account_history_provider: CashPnLAccountHistoryProvider,
                      cost_provider: HedgeCostProvider) -> PolicySummary:
        """ Returns the existing positions as is. """
        return PolicySummary(positions,
                             info={'summary': "No Change Policy"})


class PerfectHedgePolicy(Policy):
    def __init__(self,
                 settings: HedgeAccountSettings,
                 name: str = "PerfectHedge"):
        super().__init__(name=name, settings=settings)
        self._uniform_ratio = settings.custom_settings.get('UniformRatio', 1.)
        if self._uniform_ratio < 0 or self._uniform_ratio > 1.:
            raise ValueError("Uniform hedge ratio must be between 0 and 1")

    def new_positions(self,
                      positions: pd.Series,
                      raw_exposures: CashExposures,
                      cash_exposures: CashExposures,
                      universe: Universe,
                      account_history_provider: CashPnLAccountHistoryProvider,
                      cost_provider: HedgeCostProvider) -> PolicySummary:
        # TODO: need to incorporate margin budget etc
        return PolicySummary(positions=-self._uniform_ratio * cash_exposures.net_exposures(),
                             info={'summary': f'Perfect Hedge Ratio:{self._uniform_ratio}'})
