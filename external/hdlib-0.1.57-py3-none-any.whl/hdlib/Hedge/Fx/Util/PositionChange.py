from typing import Optional

from hdlib.Hedge.Fx.HedgeAccount import HedgeAccountSettings, AccountInterface

import pandas as pd


class PositionChange(object):
    def __init__(self,
                 old_positions: pd.Series,
                 new_positions: pd.Series,
                 settings: Optional[HedgeAccountSettings] = None):
        """
        Class to represent a change in fx positions from old to new positions
        :param settings: HedgeAccountSettings, settings for the account
        :param old_positions: pd.Series, the old positions
        :param new_positions: pd.Series, the new positions. Note that old_positions and new_positions can be
            a different size
        """
        self._settings = settings
        self._old_positions = old_positions
        self._new_positions = new_positions

    @property
    def account(self) -> Optional[AccountInterface]:
        return self._settings.get_account() if self._settings else None

    @property
    def settings(self) -> Optional[HedgeAccountSettings]:
        return self._settings

    @property
    def old_positions(self) -> pd.Series:
        return self._old_positions

    @property
    def new_positions(self) -> pd.Series:
        return self._new_positions

    @property
    def has_changes(self):
        # If exactly one of old and new positions are None, there was a change.
        if self._old_positions is None and self._new_positions is not None \
                or self._old_positions is None and self._new_positions is not None:
            return True

        # If old and new positions were None, there is no changes.
        if self._old_positions is None and self._new_positions is None:
            return False

        # Get the delta positions. If any are non-zero, there was a change in positions.
        delta = self.delta_position()
        for _, d in delta.items():
            if d != 0:
                return True
        # No change in positions.
        return False

    def scale_new_positions(self, factor: float):
        """ Scale the new positions by some factor. """
        self._new_positions *= factor

    def delta_position(self) -> pd.Series:
        """
        Get the change from the old positions to the new positions.
        """
        all_fx = set(self._old_positions.keys()).union(set(self._new_positions.keys()))
        delta = {fx: 0 for fx in all_fx}
        for fx in all_fx:
            delta[fx] = self._new_positions.get(fx, 0.) - self._old_positions.get(fx, 0.)
        index, values = [], []
        for fx, value in delta.items():
            if value != 0:
                index.append(fx)
                values.append(value)
        return pd.Series(data=values, index=index, dtype=float)

    def __str__(self):
        old_positions = []
        for fx, value in self._old_positions.items():
            old_positions.append(f"({fx}: {value})")
        if len(old_positions) == 0:
            old_positions.append("(NONE)")

        new_positions = []
        for fx, value in self._new_positions.items():
            new_positions.append(f"({fx}: {value})")
        if len(new_positions) == 0:
            new_positions.append("(NONE)")

        return f"[ OLD: {', '.join(old_positions)} | NEW: {', '.join(new_positions)} ]"
