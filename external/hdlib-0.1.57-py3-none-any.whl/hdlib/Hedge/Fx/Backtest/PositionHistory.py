from typing import List
import pandas as pd
import os
import matplotlib.pyplot as plt

from hdlib.Hedge.Fx.CashPnLAccount import CashPnLAccount, CashPnLAccountHistoryProvider
from hdlib.Hedge.Fx.HedgeAccount import HedgePositions

import logging

from hdlib.PlotUtil.TimeSeries import plot_time_series_df

pd.options.mode.chained_assignment = None  # default='warn'

logger = logging.getLogger(__name__)


class PositionHistory(object):
    def __init__(self,
                 account_name: str,
                 policy_name: str,
                 fx_names: List[str],
                 do_plotting: bool = False):
        self._account_name = account_name
        self._policy_name = policy_name
        self._fx_names = fx_names
        self._domestic = fx_names[-1][-3:]

        self._dates = []
        self._positions = []
        self._exposures = []
        self._spots = []

        self._accounts = []  # tracks values of account over time

        self._do_plotting = do_plotting

    @property
    def num_dates(self) -> int:
        return len(self._dates)

    @property
    def num_currencies(self) -> int:
        return len(self._fx_names)

    def record_positions(self,
                         hedge_account: HedgePositions,
                         net_exposures: pd.Series,
                         spots: pd.Series,
                         cash_pnl_account: CashPnLAccount):

        if len(hedge_account.positions) != len(self._fx_names):
            raise ValueError("Positions are the wrong size")

        if len(net_exposures) != len(self._fx_names):
            raise ValueError("Exposures are the wrong size")

        self._dates.append(hedge_account.date)
        self._positions.append(hedge_account.positions.values.copy())
        self._exposures.append(net_exposures.values.copy())
        self._spots.append(spots.values)

        self._accounts.append([cash_pnl_account.hedge_position_value,
                               cash_pnl_account.hedge_cash_value,
                               cash_pnl_account.hedge_pnl,
                               cash_pnl_account.cashflows_received,
                               cash_pnl_account.roll_costs,
                               cash_pnl_account.trade_costs,
                               cash_pnl_account.aggregate_cash_balance,
                               cash_pnl_account.aggregate_cash_and_future_npv,
                               cash_pnl_account.future_cashflow_npv])

    def account_to_df(self) -> pd.DataFrame:
        return pd.DataFrame(index=self._dates, data=self._accounts,
                            columns=['HedgePositionValue',
                                     'HedgeCash',
                                     'HedgePnL',
                                     'Cashflows',
                                     'RollCosts',
                                     'TradeCosts',
                                     'CashBalance',
                                     'CashAndFutureNPV',
                                     'FutureCashNPV'])

    def positions_to_df(self) -> pd.DataFrame:
        return pd.DataFrame(index=self._dates, data=self._positions, columns=self._fx_names)

    def exposures_to_df(self) -> pd.DataFrame:
        return pd.DataFrame(index=self._dates, data=self._exposures, columns=self._fx_names)

    def spots_to_df(self) -> pd.DataFrame:
        return pd.DataFrame(index=self._dates, data=self._spots, columns=self._fx_names)

    def write_history(self, out_dir: str, do_plots: bool = True):
        plt.close('all')
        os.makedirs(out_dir, exist_ok=True)

        positions = self.positions_to_df()
        positions.to_csv(f'{out_dir}/Positions.csv')

        exposures = self.exposures_to_df()
        exposures.to_csv(f'{out_dir}/Exposures.csv')

        spots = self.spots_to_df()
        spots.to_csv(f'{out_dir}/Spots.csv')

        account = self.account_to_df()
        account.to_csv(f'{out_dir}/Account.csv')

        if not do_plots:
            return

        plot_dir = f"{out_dir}/plots"
        os.makedirs(plot_dir, exist_ok=True)

        if self._do_plotting:
            self._plot_spots(spots=spots, plot_dir=plot_dir)
            self._plot_account(account=account, plot_dir=plot_dir)
            self._plot_exposures(exposures=exposures, plot_dir=plot_dir)

    def _plot_spots(self, spots: pd.DataFrame, plot_dir: str):
        spots = spots / spots.iloc[0]
        plot_time_series_df(df=spots, fpath=f"{plot_dir}/spots.png", ylabel='Relative Spot')

    def _plot_exposures(self, exposures: pd.DataFrame, plot_dir: str):
        plot_time_series_df(df=exposures, fpath=f"{plot_dir}/plot_exposures.png", ylabel=f'Value(Foreign)')

    def _plot_account(self, account: pd.DataFrame, plot_dir: str):
        # account.index = [date.strftime('%Y-%m-%d') for date in account.index]

        d = account[['HedgeCash', 'CashBalance', 'Cashflows', 'FutureCashNPV']]
        plot_time_series_df(df=d, fpath=f"{plot_dir}/plot_cash_accounts.png", ylabel=f'Value({self._domestic})')

        d = account[['CashAndFutureNPV']]
        plot_time_series_df(df=d, fpath=f"{plot_dir}/plot_cash_and_future.png", ylabel=f'Value({self._domestic})')

        d = account[['HedgePositionValue', 'FutureCashNPV']]
        plot_time_series_df(df=d, fpath=f"{plot_dir}/plot_hedge_position.png", ylabel=f'Value({self._domestic})')

        d = account[['HedgePnL']]
        d['FullPnL'] = account['CashAndFutureNPV'].values - account['CashAndFutureNPV'].iloc[0]
        d['UnhedgedPnL'] = d['FullPnL'].values - d['HedgePnL'].values
        plot_time_series_df(df=d, fpath=f"{plot_dir}/plot_pnl.png", ylabel=f'Value({self._domestic})')
