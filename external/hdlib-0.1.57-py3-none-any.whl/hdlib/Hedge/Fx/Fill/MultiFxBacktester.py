from hdlib.DateTime.Date import Date
from hdlib.Core.FxPair import FxPair
from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Core.Currency import Currency
from hdlib.Hedge.Fx.Fill.MultiFxOrderState import MultiFxOrderFlowState
from hdlib.Hedge.Fx.Fill.MultiFxPolicy import MultiFxPolicy
from hdlib.Hedge.Fx.Fill.Cost import CostOfMultiFxHedge, NoCostOfMultiFxHedge
from hdlib.Hedge.Fx.Fill.Report import FxConversionReport
from hdlib.Hedge.Fx.Fill.FxSpotLevelPolicy import FxSpotProvider

import pandas as pd
from typing import Optional, Sequence, Dict


class MultiFxHedgeBacktester(object):
    """
    Class for backtesting multiple FX hedges
    """
    def __init__(self,
                 domestic: Currency,
                 policy: MultiFxPolicy,
                 spot_provider: FxSpotProvider,
                 prevent_overfill: bool = True,
                 cost: CostOfMultiFxHedge = NoCostOfMultiFxHedge()
                 ):
        """

        :param domestic: Currency, the domestic currency that all cashflows should be converted into
        :param policy: CurrencyHedgePolicy, a policy for converting cash into domestic
        :param cost: CostOfCurrencyHedge, a prescription for cacluating the cost of a hedging strategy
        """
        self._policy = policy
        self._domestic = domestic
        self._spot_provider = spot_provider
        self._prevent_overfill = prevent_overfill
        self._cost = cost

    def test_cashflows_for_date(self,
                                order_date: Date,
                                cashflows: Dict[Currency, Sequence[CashFlow]],
                                spots: Optional[pd.DataFrame] = None) -> Dict[FxPair, FxConversionReport]:
        """
        Run backtest on one or more cashflows in multiple currencies
        :param order_date: Date, the date on which the hedge is ordered
        :param cashflows: Dict[Currency, Sequence[CashFlow]], the cashflows to hedge (convert to domestic)
        :return: Dict[FxPair, FxHedgeReport], a report summarizing the results of the hedge per FxPair
        """
        order_state = MultiFxOrderFlowState.from_cashflows_by_currency(
            order_date=order_date, domestic=self._domestic,
            cashflows=cashflows, prevent_overfill=self._prevent_overfill)

        reports: Dict[FxPair, FxConversionReport] = {}
        # DO: add MultiFxCashflows object?  Has methods for which currencies, whats the final date, etc

        # Find the last date (across all currencies)
        max_date = order_date
        for _, flows in cashflows.items():
            if flows[-1].pay_date > max_date:
                max_date = flows[-1].pay_date

        if spots is None:
            spots = self._spot_provider.multi_fx_spots_in_range(start=order_date,
                                                                end=max_date, fx_pairs=order_state.fx_pairs)

        for pair in order_state.fx_pairs:
            orders = order_state.get_state(fx_pair=pair).orders
            for order in orders:
                if order.due_date not in spots.index:
                    raise ValueError("Your cashflow pay date is not a buisness date")

            reports[pair] = FxConversionReport(orders=orders, spots=spots[pair.name], policy_name=self._policy.name)

        policy = self._policy.copy()
        policy.initialize(date=order_date, order_state=order_state)
        for date in spots.index:
            date = Date.from_datetime_date(date)
            actions = policy.actions(date=date, order_state=order_state)
            order_state.finalize_states()
            for pair, action in actions.items():
                state = order_state.get_state(fx_pair=pair)
                reports[pair].add_action(balance=state.fx_position, action=action)

        for pair in order_state.fx_pairs:
            cost_func = lambda x: self._cost.cost_for_fx_pair(fx_pair=pair, position=x)
            reports[pair].finalize_report(cost=cost_func)

        return reports


