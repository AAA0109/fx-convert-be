from hdlib.DateTime.Date import Date
from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD

from hdlib.Hedge.Fx.Fill.Action import FxHedgeAction
from hdlib.Hedge.Fx.Fill.FxOrderState import FxOrderFlowState
from hdlib.Hedge.Fx.Fill.OneFxRiskBudget import OneFxRiskBudget
from hdlib.Hedge.Fx.Fill.Cost import CostOfFxHedge

from abc import ABC
from typing import List
from copy import deepcopy


class OneFxPolicy(ABC):
    """
    Abstract base class for a single currency hedging policy. A policy is a mapping from a date and a current
    order state (ie how much of a requested currency order has been filled) into an action, ie how much to buy
    """

    def __init__(self, name: str = 'UnknownPolicy'):
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    def action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        """
        Perform a hedging action (how much to buy/sell) in accordance with the policy, given the state on this date.
        The action also updates the state
        :param date: Date, the date on which to perform the action (corresponds to "now")
        :param order_state: CurrencyOrderState, the current state of the order, tracks how much remains to purchase
        :return: CurrencyHedgeAction, the action taken
        """
        action = self._action(date=date, order_state=order_state)

        # Update the order state. Note that this can modify the action as needed to prevent overfill
        order_state.update_state(action=action)

        return action

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        """
        Main method to override. Given the date, its up to you to implement how you go to a data provider and
        pulls data for that date. Each policy requires a potentially different state space, so that is encapsulated
        here, and you return the Action based on the fetched state space.
        Note: You may also override the main action method, if you have a more complext sequence of actions
        that require multiple updates of the state
        """
        return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)

    def initialize(self, date: Date, order_state: FxOrderFlowState):
        """
        Ability to initialize a policy on a start date. For example, a stop loss strategy could initialize itself
        to the spot level on some date
        :param date: Date, the date on which the policy starts
        :param order_state: FxOrderFlowState, the flow state at initialization
        """
        pass

    def copy(self) -> 'OneFxPolicy':
        """
        Create a deep copy of this policy. Allows the policy to maintain state, and/or to be initialized from
        some point in time, dependent on when it is initialized
        """
        return deepcopy(self)


# ======================================


class CompositeOneFxPolicy(OneFxPolicy):
    """
    A composite policy. Actions are taken the order in which you provide the policies. For example,
    you can supply a StopLoss, followed by an AI policy. So first, the stop loss will check if its triggered,
    and then the AI will decide what to do next
    """

    def __init__(self, name: str = 'CompositePolicy'):
        super().__init__(name=name)
        self._policies: List[OneFxPolicy] = []

    def add_policy(self, policy: OneFxPolicy):
        """
        Add another policy. The actions are performed for each policy in the order in which they are added
        :param policy: CurrencyHedgePolicy, a policy
        """
        self._policies.append(policy)

    def action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        # Initialize with a hold action, and update as you go
        action = FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)
        for policy in self._policies:
            if order_state.is_net_filled and order_state.prevent_overfill:
                break
            # Merge in the next action, and update the order state
            action.merge(policy.action(date=date, order_state=order_state))
        return action

    def initialize(self, date: Date, order_state: FxOrderFlowState):
        for policy in self._policies:
            policy.initialize(date=date, order_state=order_state)


# ======================================
# Simple Examples
# ======================================


class DCAOneFxPolicy(OneFxPolicy):
    """
    Simple hedging strategy for testing purposes (acutally used by some people) - DCA = Dollar Cost Averaging,
    which simply averages out the purchase uniformly over the remaining dates
    """

    def __init__(self, dc: DayCounter = DayCounter_HD()):
        self._dc = dc
        super().__init__(name='Dollar Cost Averaging')

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        # DO: need to ensure that we fill the next Immediate order by its due date
        # get_unfilled_orders
        remaining = order_state.net_remain_to_fill

        days = self._dc.days_between(start=date, end=order_state.final_due_date)  # plus one since we go up to pay date
        # uniformly distributes remaining amount across future dates

        amount = remaining / max(days, 1)
        return FxHedgeAction.buy_sell_or_hold(date=date, amount=amount, fx_pair=order_state.fx_pair)


class BuyAndHoldOneFxPolicy(OneFxPolicy):
    """
    Simple hedging strategy for testing purposes. Buys and holds for duration of the order.
    """

    def __init__(self):
        super().__init__(name='Buy and Hold')

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        if not order_state.is_net_filled:  # Buy at first opportunity
            return FxHedgeAction.buy(date=date, amount=order_state.net_remain_to_fill,
                                     fx_pair=order_state.fx_pair)
        return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)


class NoHedgeOneFxPolicy(OneFxPolicy):
    """
    Simple hedging strategy for testing purposes. Buys the spot at the very end
    """

    def __init__(self):
        super().__init__(name='No Hedge')

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        if date >= order_state.final_due_date:  # Buy at first opportunity
            return FxHedgeAction.buy(date=date, amount=order_state.net_remain_to_fill,
                                     fx_pair=order_state.fx_pair)
        return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)


class CapRiskOneFxPolicy(OneFxPolicy):
    def __init__(self,
                 risk_budget: OneFxRiskBudget):
        """
        A currency hedge policy that enforces a cap on the risk each day based on some risk budget
        :param risk_budget: RiskBudget, informs the policy of when exposure exceeds the budget
        """
        super().__init__(name="CapRiskPolicy")
        self._risk_budget = risk_budget

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        """"""
        order_state.date = date
        excess = self._risk_budget.budget_excess(date=date, order_state=order_state)
        if excess > 0:
            return FxHedgeAction.buy(date=date, amount=excess, fx_pair=order_state.fx_pair)
        return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)


class CapDailyCostOneFxPolicy(OneFxPolicy):
    def __init__(self,
                 cost: CostOfFxHedge,
                 max_daily_roll_cost: float):
        """
        Policy that caps the daily roll cost for this fx balance. Balances (either long or short) that exceed the
        allowed daily roll cost are shrunk towards zero to meet the allowed cost

        :param cost: CostOfFxHedge, used to assess roll cost of current fx_balance
        :param max_daily_roll_cost: float, the maximum allowed daily roll cost
        """
        super().__init__(name="CapCostPolicy")
        self._cost = cost
        self._max_cost = max_daily_roll_cost

    def _action(self, date: Date, order_state: FxOrderFlowState) -> FxHedgeAction:
        """"""
        order_state.date = date
        fx_balance = order_state.fx_position
        cost = self._cost.roll_cost(amount=fx_balance, start=date, end=Date.from_datetime_date(date) + 1)

        if cost <= self._max_cost:
            return FxHedgeAction.hold(date=date, fx_pair=order_state.fx_pair)

        cost_per_unit = cost / abs(fx_balance)
        allowed = self._max_cost / cost_per_unit
        excess = abs(fx_balance) - allowed

        if fx_balance > 0:
            return FxHedgeAction.sell(date=date, amount=excess, fx_pair=order_state.fx_pair)

        return FxHedgeAction.buy(date=date, amount=excess, fx_pair=order_state.fx_pair)

