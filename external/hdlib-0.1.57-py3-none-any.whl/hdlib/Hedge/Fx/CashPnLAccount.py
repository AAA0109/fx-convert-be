import numpy as np
import pandas as pd
from bisect import bisect_left
import os

from hdlib.Hedge.Fx.Util.FxMarketConventionConverter import SpotFxCache

from hdlib.DateTime.Date import Date
from hdlib.Hedge.Fx.HedgeCostProvider import HedgeCostProvider
from hdlib.DateTime.DayCounter import DayCounter, DayCounter_HD
from hdlib.Universe.Universe import Universe

from typing import Optional, Tuple
from abc import ABC, abstractmethod


def difference(lhs: pd.Series, rhs: pd.Series) -> pd.Series:
    """
    Take the difference between two series, using the convention that if an index in not present in a series, its value
    is zero.
    """
    diff = {}
    for v in set(lhs.index).union(set(rhs.index)):
        diff[v] = lhs.get(v, 0) - rhs.get(v, 0)
    return pd.Series(index=diff.keys(), data=diff.values())


class CashflowValueAccount(object):
    """
    Object that stores some information about cashflows received, and cashflows in the future.
    """

    def __init__(self,
                 date: Date,
                 cashflows_received: float = 0.,
                 future_cash_npv: float = 0.):
        """
        Initialize a CashflowValueAccount.
        """
        self._last_updated_date = date
        self._cashflows_received = cashflows_received  # Tracks all cashflows received/paid (in domestic)
        self._future_cash_npv = future_cash_npv  # Tracks the NPV of all unreceived cashflows

    def copy(self) -> 'CashflowValueAccount':
        return CashflowValueAccount(self.last_updated_date, self.cash_received, self.future_cash_npv)

    @property
    def last_updated_date(self) -> Date:
        return self._last_updated_date

    @property
    def cash_received(self) -> float:
        return self._cashflows_received

    @property
    def future_cash_npv(self) -> float:
        return self._future_cash_npv

    def refresh(self,
                date: Date,
                spots: pd.Series,
                cash_on_date: pd.Series,
                net_exposure: pd.Series):
        """
        Update the account to the given date
        :param date: Date, the latest date
        :param spots: pd.Series, the current spot prices on this date for each fx_pair
        :param cash_on_date: pd.Series, the cashflows received since the last business date up to and including today,
                so this includes any flows on holidays or weekends. These are in the same order as the spots
        :param net_exposure: pd.Series, the current net cash exposure in each pair (no fx applied, this is cash amount)
        """
        if len(spots) != len(cash_on_date):
            raise ValueError("Your spots and cash series must be same dimension")

        # Cashflows Received / Paid
        self._cashflows_received += np.dot(spots.values, cash_on_date.values)

        # NPV of future (not yet received) cashflows
        # TODO: Discounting?
        self._future_cash_npv = np.dot(spots.values, net_exposure.values)

        self._last_updated_date = date


class CashPnLAccount(object):
    """
    Account to keep track of cash balances resulting from cashflows and trading/hedging activity.
    """

    def __init__(self,
                 date: Date,
                 hedge_cash: float = 0.,
                 trade_costs: float = 0.,
                 roll_costs: float = 0.,
                 cashflows_received: float = 0.,
                 future_cash_npv: float = 0.,
                 hedge_position_value: float = 0.,
                 dc: DayCounter = DayCounter_HD()):
        """
        Initialize the Cash account.
        :param date: Date, current date of account (last updated)
        :param dc: DayCounter, used to measure time
        """
        self._dc = dc
        self._date = date

        # Accounts (in units of domestic)
        self._hedge_cash = hedge_cash  # Tracks cashflows used to finance trading in the hedge account
        self._trade_costs = trade_costs  # Tracks costs from trading (recorded as negative number)
        self._roll_costs = roll_costs  # Tracks all roll costs (recorded as negative, assuming roll costs money)

        # Unhedged Component of Accounts

        # Tracks all cashflows received/paid (in domestic)
        self._cashflows_account = CashflowValueAccount(date=date,
                                                       cashflows_received=cashflows_received,
                                                       future_cash_npv=future_cash_npv)

        self._hedge_position_value = hedge_position_value  # Tracks current value of positions in hedge account

    @property
    def date(self) -> Date:
        return self._date

    # =======================================
    # Cashflow Value Properties (same as unhedged value)
    # =======================================

    @property
    def cashflows_received(self) -> float:
        """ Net cashflows in domestic up to current date, where each was
            converted to domestic at spot rate at time of cashflow
        """
        return self._cashflows_account.cash_received

    @property
    def future_cashflow_npv(self) -> float:
        """ NPV of all future (unreceived) cashflows, strictly after today """
        return self._cashflows_account.future_cash_npv

    @property
    def received_and_future_cashflow_npv(self) -> float:
        """
        Sum of all received cashflows, plus NPV of future cash flows.
        """
        return self.cashflows_received + self.future_cashflow_npv

    # =======================================
    # Hedge Value Properties - Relates to PnL / costs from trading activity
    # =======================================

    @property
    def hedge_position_value(self) -> float:
        """ Value of current fx position in units of domestic currency """
        return self._hedge_position_value

    @property
    def hedge_cash_value(self) -> float:
        """
        Value of cash used to finance hedge positions. E.g., purchasing 1 GBP/USD for $1.3 will result in a hedge
        cash value of $-1.3 (full position value, not the margin value required)
        """
        return self._hedge_cash

    @property
    def hedge_pnl(self) -> float:
        """ PnL (in domestic currency) generated via trading activity up to current date """
        return self._hedge_cash + self._hedge_position_value

    @property
    def trade_costs(self) -> float:
        """ Costs of all trading activity in hedge account up to current date"""
        return self._trade_costs

    @property
    def roll_costs(self) -> float:
        """ Aggregate Costs of maintaining overnight positions in the hedge account up to current date """
        return self._roll_costs

    @property
    def net_hedge_pnl(self) -> float:
        """ Net PnL resulting from hedging activity, net of all associated costs """
        return self.hedge_pnl + self._trade_costs + self._roll_costs

    # =======================================
    # Combined Hedge + Cashflow Value Properties
    # =======================================

    @property
    def aggregate_cash_balance(self) -> float:
        """
        :return: float, the aggregate cash balance on current date resulting from cashflows and all trading/hedging
        """
        return self.hedge_pnl + self._trade_costs + self._roll_costs + self.cashflows_received

    @property
    def aggregate_cash_and_future_npv(self) -> float:
        """ Aggregate of all cash recieved / generated, as well as the NPV of unrecieved cashflows """
        return self.aggregate_cash_balance + self.future_cashflow_npv

    # =======================================
    # Modifier Methods
    # =======================================

    def update(self,
               date: Date,
               spots: pd.Series,
               positions: pd.Series,
               old_positions: pd.Series,
               cash_on_date: pd.Series,
               net_exposure: pd.Series,
               cost_provider: HedgeCostProvider
               ):
        """
        Update the account to the given date
        :param date: Date, the latest date
        :param spots: pd.Series, the current spot prices on this date
        :param positions: pd.Series, the current fx hedge account positions on this date
        :param old_positions: pd.Series, the previous fx hedge account positions
        :param cash_on_date: pd.Series, the cashflows received since the last business date up to and including today,
            so this includes any flows on holidays or weekends
        :param net_exposure: pd.Series, the current net cash exposure in each pair (no fx applied, this is cash amount)
        :param cost_provider: HedgeCostProvider, provides costs of trading, roll costs, etc
        """

        # Trade PnL
        position_change = difference(positions, old_positions)
        trade_cash = -np.dot(spots.values, position_change)  # Negative, because purchases cost us domestic
        self._hedge_cash += trade_cash

        # Update current position value
        self._hedge_position_value = np.dot(spots.values, positions.values)

        # Trade Costs
        trade_cost = np.dot(np.abs(position_change),
                            cost_provider.get_spot_fx_transaction_costs(date=date))
        self._trade_costs -= trade_cost

        # Roll Costs (assessed based on the previous positions, held overnight)
        if date != self._date:  # avoid double counting roll costs
            roll_rate_long, roll_rate_short = cost_provider.get_spot_fx_roll_rates(date=date)

            # TODO: double check signs  (note that we do self._roll_costs -= below)
            roll_cost_long = -np.dot(np.maximum(0, old_positions), roll_rate_long)
            roll_cost_short = np.dot(np.minimum(0, old_positions), roll_rate_short)

            days_change = self._dc.days_between(start=self._date, end=date)  # Roll cost is daily rate
            self._roll_costs -= (roll_cost_long + roll_cost_short) * days_change

        # Cashflows Received / Paid
        self._cashflows_account.refresh(date=date, spots=spots, cash_on_date=cash_on_date, net_exposure=net_exposure)
        self._date = date

    def unwind_positions(self,
                         date: Date,
                         spots: pd.Series,
                         old_positions: pd.Series,
                         net_exposure: pd.Series,
                         cost_provider: HedgeCostProvider):
        """ Final method to call at the end of a hedge run, unwind/sell off all hedge positions """
        zeros = pd.Series(index=old_positions.index, data=np.zeros(len(old_positions)))
        self.update(date=date,
                    spots=spots,
                    positions=zeros,
                    old_positions=old_positions,
                    cash_on_date=zeros,
                    net_exposure=net_exposure,
                    cost_provider=cost_provider)

    def copy(self) -> 'CashPnLAccount':
        return CashPnLAccount(date=self._date, hedge_cash=self._hedge_cash, trade_costs=self._trade_costs,
                              roll_costs=self._roll_costs, cashflows_received=self._cashflows_account.cash_received,
                              future_cash_npv=self.future_cashflow_npv, hedge_position_value=self._hedge_position_value,
                              dc=self._dc)


# TODO: make this extend a PnLProvider base class?
class CashPnLAccountHistoryProvider(ABC):
    @abstractmethod
    def get_account_state(self,
                          date: Date = None,
                          roll_down: bool = True,
                          universe: Optional[Universe] = None) -> CashPnLAccount:
        """ If Date is None, supply the first recorded state available """
        raise NotImplementedError

    @abstractmethod
    def get_first_date(self) -> Optional[Date]:
        """ Get first date of recorded history, if available, else None """
        raise NotImplementedError

    def is_empty(self) -> bool:
        """ Check if the history for this account is empty """
        return not self.get_first_date()

    def get_pnl_and_initial_exposure(self,
                                     start_date: Optional[Date],
                                     end_date: Date,
                                     universe: Optional[Universe] = None
                                     ) -> Tuple[Optional[float], Optional[float]]:
        """
        Get the PnL between a start and end date, together with the net cash exposure (NPV) as of the start date.
        :param start_date: Date (optional), the start date for PnL calc (inclusive)
        :param end_date: Date, the end date (e.g. current date) for the PnL
        :param universe, Universe, the financial universe as of end_date
        :return: (float, float) = (PnL, NPV of Cash Exposure), if a hedge was in place as of start date. T
            If no hedge was in place as of the start_date, then None, None is returned
        """
        # Returns the initial exposure as well as the pnl since that exposure
        cash_pnl_account = self.get_account_state(date=end_date, universe=universe)

        if not cash_pnl_account:
            # This account has not yet been hedged
            return None, None

        start_date = start_date if start_date else self.get_first_date()
        cash_pnl_account_start = self.get_account_state(date=start_date)

        # TODO: note that if cashflows are added, this will look like a pnl ...
        #  but its not (same with a lookahead horizon as that horizon picks up more)

        pnl_to_date = cash_pnl_account.aggregate_cash_and_future_npv \
                      - cash_pnl_account_start.aggregate_cash_and_future_npv

        # If pnl is positive, the target is less restrictive.
        exposure_from_start = cash_pnl_account_start.future_cashflow_npv

        return pnl_to_date, exposure_from_start


class CashPnLAccountHistoryProvider_Cached(CashPnLAccountHistoryProvider):
    def __init__(self):
        self._dates = []
        self._states = []

    def get_account_state(self,
                          date: Date = None,
                          roll_down: bool = True,
                          universe: Optional[Universe] = None) -> Optional[CashPnLAccount]:
        """ If Date is None, supply the first recorded state available """
        if not self._dates:
            return None

        if date is None or date >= self._dates[-1]:
            return self._states[-1]

        if date <= self._dates[0]:
            return self._states[0]

        index = bisect_left(self._dates, date)
        for j in (index - 1, index):
            if date == self._dates[j]:
                return self._states[j]

        if roll_down:
            return self._dates[max(0, index - 1)]
        return self._dates[min(len(self._dates) - 1, index)]

    def get_first_date(self) -> Optional[Date]:
        """ Get first date of recorded history, if available, else None """
        return self._dates[0] if self._dates else None

    def record_state(self, cash_pnl_account: CashPnLAccount):
        self._dates.append(cash_pnl_account.date)
        self._states.append(cash_pnl_account.copy())

    def account_to_df(self) -> pd.DataFrame:
        data = [[cash_pnl_account.hedge_position_value,
                 cash_pnl_account.cashflows_received,
                 cash_pnl_account.roll_costs,
                 cash_pnl_account.trade_costs,
                 cash_pnl_account.aggregate_cash_balance,
                 cash_pnl_account.aggregate_cash_and_future_npv,
                 cash_pnl_account.future_cashflow_npv] for cash_pnl_account in self._states]

        return pd.DataFrame(index=self._dates, data=data,
                            columns=['HedgePositionValue',
                                     'NetCashReceived',
                                     'RollCosts',
                                     'TradeCosts',
                                     'CashBalance',
                                     'CashAndFutureNPV',
                                     'FutureCashNPV'])

    def write_history(self, base_dir: str):
        os.makedirs(base_dir, exist_ok=True)
        self.account_to_df().to_csv(f'{base_dir}/Account.csv')


class CashPnLAccountHistoryProvider_Empty(CashPnLAccountHistoryProvider):
    """ A Cash PnL account history provider that doesn't do anything. """
    def get_account_state(self,
                          date: Date = None,
                          roll_down: bool = True,
                          universe: Optional[Universe] = None) -> CashPnLAccount:
        """ If Date is None, supply the first recorded state available """
        return CashPnLAccount(date=date)

    def get_first_date(self) -> Optional[Date]:
        """ Get first date of recorded history, if available, else None """
        return None
