import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Iterable
import os
import toml

from hdlib.Core.FxPair import FxPair
from hdlib.Core.Currency import make_currency, Currency
from hdlib.DateTime.DayCounter import DayCounter_HD, DayCounter

from hdlib.Universe.Historical.HistUniverseProvider import HistUniverseProvider
from hdlib.Universe.Universe import Universe, Date
from hdlib.Universe.FX.FxUniverse import FxAssets, FxUniverse, FxCorrelations
from hdlib.Universe.Asset.FxAsset import FxAsset
from hdlib.Universe.Asset.IrAsset import IrAsset

from hdlib.TermStructures.ForwardCurve import ForwardCurve, FlatForwardCurve, InterpolatedForwardCurve
from hdlib.TermStructures.DiscountCurve import DiscountCurve_ConstRate
from hdlib.DataProvider.Fx.FxVolProvider import FxVolProvider, FxSpotVols, CachedFxVolProvider
from hdlib.DataProvider.Fx.FxSpotProvider import CachedFxSpotProvider
from hdlib.DataProvider.Fx.FxCorrProvider import CachedFxCorrProvider

import logging

logger = logging.getLogger(__name__)


class HPConfig(object):
    def __init__(self, config_path: str):
        """
        Configuration for the file driven Historical universe provider
        :param config_path: str, path to the config
        """
        self._config = self._load_config(config_path)

    @property
    def base_dir(self):
        return self._config['base_dir']

    @property
    def domestic_currency(self):
        return self._config['domestic_currency']

    @property
    def currencies(self):
        return self._config['currencies']

    @property
    def fx_forwards_path(self):
        return os.path.join(self.base_dir, self._config['fx_forwards_fname'])

    @property
    def fx_spot_vols_path(self):
        fname = self._config.get('fx_spot_vols_fname', None)
        return os.path.join(self.base_dir, fname) if fname else ""

    @property
    def fx_spot_corrs_path(self):
        fname = self._config.get('fx_spot_corrs_fname', None)
        return os.path.join(self.base_dir, fname) if fname else ""

    def _load_config(self, config_path: str) -> Dict:
        try:
            config = toml.load(config_path)
            config = config['proxy_world_config']
            self._base_dir = config['base_dir']
            return config
        except Exception as e:
            logger.error("Error loading proxy world config toml :" + str(e))
            raise e


class HistUniverseProvider_Files(HistUniverseProvider):
    def __init__(self, config_path: str):
        """
        Historical Universe provider, where data is retrieved from files (in the systems file convention format)
        :param config_path: str, path the to HDConfig (.toml)
        """
        super().__init__()
        logger.info(f"Initializing Historical UProvider from {config_path}")
        self._config = HPConfig(config_path)
        self._dc: DayCounter = DayCounter_HD()  # this could be configured

        self._currencies: List[Currency] = self._read_currencies()

        self._domestic_currency: Optional[Currency] = \
            make_currency(self._config.domestic_currency) if self._config.domestic_currency else None

        self._fx_pairs: List[FxPair] = []
        self._fx_fwds: pd.DataFrame = pd.DataFrame()

        self._fx_spot_provider: Optional[CachedFxSpotProvider] = None
        self._fx_vol_provider: Optional[CachedFxVolProvider] = None
        self._fx_corr_provider: Optional[CachedFxCorrProvider] = None

        self._dates: List[Date] = []
        self._cached_date_index = 0

        self._load_data()

    @property
    def day_counter(self) -> DayCounter:
        return self._dc

    def get_all_fx_spots(self) -> pd.DataFrame:
        return self._fx_spot_provider.fx_spot_full_history()

    def get_all_fx_spot_vols(self) -> pd.DataFrame:
        return self._fx_vol_provider.fx_spot_vols_full_history()

    def get_dates(self, start: Date, end: Date) -> Iterable[Date]:
        for date in self._dates:
            if start <= date <= end:
                yield date

    def get_n_dates(self, start: Date, num_dates: int) -> Iterable[Date]:
        n = 0
        for date in self._dates:
            if start <= date:
                n += 1
                yield date
            if num_dates <= n:
                return

    def get_n_uniform_dates(self, start: Date, num_dates: int) -> Iterable[Date]:
        n, index = 0, -1
        for it, date in enumerate(self._dates):
            if start <= date:
                index = it
                break
        if index == -1:
            return []
        num_available_dates = len(self._dates) - index
        spacing = int(np.floor(num_available_dates / num_dates))
        # Not enough dates.
        if spacing == 0:
            return self.get_n_dates(start, num_dates)
        else:
            while index < len(self._dates) and n < num_dates:
                n += 1
                date = self._dates[index]
                index += spacing
                yield date

    def get_all_dates(self) -> Iterable[Date]:
        return self._dates

    def get_next_date(self, date: Date) -> Date:
        if len(self._dates) == 0:
            raise ValueError(f"there are no dates in this universe provider")

        # Handle some edge cases.

        if date < self._dates[0]:
            self._cached_date_index = 0
            return self._dates[0]
        elif self._dates[-1] <= date:
            raise RuntimeError(f"the date {date} is not in the universe provider")

        # While this method of linearly searching might seem slower than binary search,
        # I'm counting on the fact that the typical pattern will call the universe provider one
        # day after another, so it really just needs to go to the next date.

        cached_date = self._dates[self._cached_date_index]
        if cached_date == date:
            return cached_date

        elif cached_date < date:
            self._cached_date_index += 1
            while self._cached_date_index < len(self._dates):
                cached_date = self._dates[self._cached_date_index]
                if date < cached_date:
                    return cached_date
                self._cached_date_index += 1
            raise ValueError(f"there is no next date after {date}")
        else:
            self._cached_date_index -= 1
            while self._cached_date_index < len(self._dates):
                cached_date = self._dates[self._cached_date_index]
                # If we have walked the date back far enough that
                if cached_date <= date:
                    self._cached_date_index += 1
                    return self._dates[self._cached_date_index]
                self._cached_date_index -= 1
            raise ValueError(f"the date {date} is not in the universe provider")

    def get_top_date(self) -> Date:
        return self._dates[-1]

    def make_universe(self, date: Date) -> Universe:
        """ Main Method to construct the Universe on a given date """

        # Initialize the universe
        u = Universe(ref_date=date, dc=self._dc)

        # Add IR Assets
        # TODO: do this properly, hard coded until we get data.
        currencies = self._currencies \
            if not self._domestic_currency else [self._domestic_currency]
        for currency in currencies:
            asset = IrAsset(currency, DiscountCurve_ConstRate(rate=0., ref_date=date, dc=self._dc))
            u.add_ir_asset(asset)

        # Add FX assets, with forward curve
        spots = self._fx_spot_provider.fx_spots_on_date(date=date)
        for pair in self._fx_pairs:
            fwd_curve = self._make_fx_fwd_curve(pair=pair, date=date, spot_fx=spots.loc[str(pair)])
            asset = FxAsset(pair, fwd_curve=fwd_curve)
            u.add_fx_asset(asset)

        # Create vols provider
        u.fx_universe.fx_vols = self._fx_vol_provider.fx_spot_vols_on_date(date=date)

        # Create FX correlation provider
        u.fx_universe.fx_corrs = self._fx_corr_provider.fx_correlations(date=date)

        return u

    def get_currencies(self) -> List[Currency]:
        return self._currencies

    # =================
    # Private Methods
    # =================

    def _load_data(self):
        logger.info(f"Historical UProvider: loading data")
        forwards_path = self._config.fx_forwards_path
        df = pd.read_csv(forwards_path, index_col=0)
        df.index = pd.to_datetime(df.index, utc=True)  # Make TZ aware
        self._dates = [Date.from_datetime(date) for date in df.index]

        self._fx_fwds = df

        pairs = []
        if self._domestic_currency:
            # In this case a domestic currency is supplied, so we dont need all pairs, just those which treat
            # the quote currency as this domestic
            for curr in self._currencies:
                if curr == self._domestic_currency:
                    continue
                pairs.append(f'{curr}{self._domestic_currency}')
                self._fx_pairs.append(FxPair(curr, self._domestic_currency))

        else:
            # Construct ALL pairs
            for i in range(len(self._currencies)):
                for j in range(len(self._currencies)):
                    if j == i:
                        continue
                    pairs.append(f'{self._currencies[i]}{self._currencies[j]}')
                    self._fx_pairs.append(FxPair(self._currencies[i], self._currencies[j]))

        spots = df[pairs]
        spots.columns = [str(pair) for pair in self._fx_pairs]
        self._fx_spot_provider = CachedFxSpotProvider(spots=spots)

        if self._config.fx_spot_vols_path:
            logger.info(f"Historical UProvider: reading spot vols")
            fx_spot_vols = pd.read_csv(self._config.fx_spot_vols_path, index_col=0)
            fx_spot_vols.index = pd.to_datetime(fx_spot_vols.index, utc=True)  # Make TZ aware
            # fx_spot_vols.index = [Date.from_datetime(date) for date in pd.to_datetime(self._fx_spot_vols.index)]
            self._fx_vol_provider = CachedFxVolProvider(vols=fx_spot_vols)

        if self._config.fx_spot_corrs_path:
            logger.info(f"Historical UProvider: reading spot correlations")
            cols = ['Date']
            cols.extend([str(pair) for pair in self._fx_pairs])
            corrs = pd.read_csv(self._config.fx_spot_corrs_path, index_col=0, usecols=cols)
            corrs.index = pd.to_datetime(corrs.index, utc=True)  # Make TZ aware
            self._fx_corr_provider = CachedFxCorrProvider(corrs=corrs)

    def _read_currencies(self) -> List[Currency]:
        currs = self._config.currencies
        return [make_currency(curr) for curr in currs]

    def _make_fx_fwd_curve(self, pair: FxPair, date: Date, spot_fx: float) -> ForwardCurve:
        # TODO: resolve tenor based on date and FX calendar/convention ... this is just to get going
        # ALSO: there can be more tenors
        tenors = ("ON", "TN", "1W", "2W", "3W",
                  "1M", "2M", "3M", "4M", "5M",
                  "6M", "12M", "15M", "18M",
                  "2Y", "3Y", "4Y", "5Y", "10Y")

        days = (1, 2, 7, 14, 21,
                30, 60, 90, 120, 150,
                180, 365, 455, 548,
                730, 1095, 1460, 1825, 3652)

        name = pair.name.replace("/", "")

        fwds_d = self._fx_fwds.loc[date]

        points = [0.]
        values = [spot_fx]
        for i in range(len(tenors)):
            ticker = f'{name}{tenors[i]}'
            try:
                value = fwds_d[ticker]
                if not np.isnan(value):
                    points.append(self._dc.year_fraction_from_days(days[i]))
                    values.append(spot_fx + value/1000.)
            except Exception:
                # Missing this data in the fwds file
                continue

        if len(points) > 1:
            return InterpolatedForwardCurve.from_linear(ttms=points, forwards=values, ref_date=date, dc=self._dc)

        return FlatForwardCurve(F0=spot_fx, ref_date=date, dc=self._dc)
