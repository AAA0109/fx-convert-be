from hdlib.Universe.Universe import Universe
from hdlib.Instrument.CashFlow import CashFlow
from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair
from hdlib.DateTime.Date import Date

from typing import Iterable, Tuple, Dict

import numpy as np


class CashflowValueSummary(object):
    def __init__(self,
                 currency: Currency,
                 num_flows: int = 0,
                 spot: float = 0.,
                 spot_abs: float = 0.,
                 fwd: float = 0.,
                 fwd_abs: float = 0.,
                 npv: float = 0.,
                 npv_abs: float = 0.):
        """
        Summary of cashflow value for a set of (one or more) cashflows
        :param currency: Currency, the currency in which all values are represented
        :param num_flows: int, number of cashflows
        :param spot: float, the sum of spot values of the casfhlows in the common currency
        :param spot_abs: float, the sum of absolute spot value of the casfhlows in the common currency
        :param fwd: float, the sum of forward values of the casfhlows in the common currency
        :param fwd_abs: float, the sum of forward absolute values of the casfhlows in the common currency
        :param npv:  float, the sum of net present values of the cashflows in the common currency
        :param npv_abs:  float, the sum of absolute net present values of the casfhlows in the common currency
        """
        self.currency = currency
        self.num_flows = num_flows
        self.spot = spot
        self.spot_abs = spot_abs
        self.fwd = fwd
        self.fwd_abs = fwd_abs
        self.npv = npv
        self.npv_abs = npv_abs

    def update_summary(self,
                       spot: float,
                       fwd: float,
                       npv: float):
        """
        Update the summary for a new cashflow
        :param spot: float, the spot value of this cashflow in the common currency
        :param fwd: float, the forward value of this cashflow in the common currency
        :param npv: float, the net present value of this cashflow in the common currency
        """
        self.num_flows += 1

        # Update Fwd
        self.fwd += fwd
        self.fwd_abs += abs(fwd)

        # Update NPV
        self.npv += npv
        self.npv_abs += abs(npv)

        # Update Sum
        self.spot += spot
        self.spot_abs += abs(spot)


class CashFlowPricer(object):
    def __init__(self, universe: Universe):
        """
        Basic Cash flow pricer, able to convert cashflows at multiple points in time and various currencies into
        a common currency, and to obtain net present value (NPV)
        :param universe: Universe, the financial universe
        """
        self._universe = universe
        self._fx_provider = universe.fx_assets
        self._dc = universe.day_counter

    def compute_cashflow_value_summary(self,
                                       cashflows: Iterable[CashFlow], value_currency: Currency) -> CashflowValueSummary:
        summary = CashflowValueSummary(value_currency)
        for cashflow in cashflows:
            # Spot Value
            spot_value = self.convert_cashflow_at_spot(cash=cashflow, value_currency=value_currency)

            # Forward Value
            fwd_value = self.convert_cashflow_forward(cash=cashflow, value_currency=value_currency)

            # Net Present Value (NPV)
            npv = self.discount_cashflow(amount=fwd_value, pay_date=cashflow.pay_date,
                                         discount_currency=value_currency)
            summary.update_summary(spot=spot_value, fwd=fwd_value, npv=npv)

        return summary

    def convert_cashflow_at_spot(self, cash: CashFlow, value_currency: Currency) -> float:
        """
        Convert a cashflow according to spot FX, into another currency
        :param cash: CashFlow, future (deterministic) cashflow to be received
        :param value_currency: Currency, currency to convert cashflow into
        :return: float, converted cashflow
        """
        return self._universe.convert_value(value=cash.amount, from_currency=cash.currency, to_currency=value_currency)

    def convert_cashflow_forward(self, cash: CashFlow, value_currency: Currency) -> float:
        """
        Convert a future cashflow according to forward FX, into another currency
        :param cash: CashFlow, future (deterministic) cashflow to be received
        :param value_currency: Currency, currency to convert cashflow into
        :return: float, converted cashflow
        """
        if cash.pay_date < self._universe.ref_date:
            return 0
        if cash.currency == value_currency:
            return cash.amount

        fx_rate = self._fx_provider.get_fx_forward(cash.pay_date, pair=FxPair(cash.currency, value_currency))
        future_cash = cash.amount * fx_rate
        return future_cash

    def convert_cashflows_forward(self, cashflows: Iterable[CashFlow], value_currency: Currency) -> float:
        """
        Convert multiple future cashflows according to forward FX, into another currency
        :param cashflows: Iterable, a container (e.g. list or array) of cashflows
        :param value_currency: Currency, currency to convert cashflow into
        :return: float, converted cashflow
        """
        fwd = 0
        for cashflow in cashflows:
            fwd += self.convert_cashflow_forward(cash=cashflow, value_currency=value_currency)
        return fwd

    def price_cashflow(self, cash: CashFlow, value_currency: Currency) -> float:
        """
        Price (NPV) a future cashflow according to forward FX, in another currency
        :param cash: CashFlow, future (deterministic) cashflow to be received
        :param value_currency: Currency, currency to convert cashflow into (and discount in this currency)
        :return: float, converted cashflow, discounted in value_currency
        """
        return self.pricing_breakdown(cashflow=cash, value_currency=value_currency)[1]

    def pricing_breakdown(self, cashflow: CashFlow, value_currency: Currency) -> Tuple[float, float]:
        """
        Price (NPV) a future cashflow according to forward FX, in another currency, returning the equivalent futures
        value and the cashflow NPV separately.
        :param cashflow: CashFlow, future (deterministic) cashflow to be received
        :param value_currency: Currency, currency to convert cashflow into (and discount in this currency)
        :return: (float, float), forward price of a forward delivering at the cashflow pay date, and the converted
            cashflow, discounted in value_currency (NPV).
        """
        future_cash = self.convert_cashflow_forward(cashflow, value_currency)
        npv = self.discount_cashflow(amount=future_cash, pay_date=cashflow.pay_date, discount_currency=value_currency)
        return future_cash, npv

    def price_cashflows(self, cashflows: Iterable[CashFlow], value_currency: Currency) -> Tuple[float, float]:
        """
        Price a container/iterable of cashflows
        :param cashflows: Iterable, a container (e.g. list or array) of cashflows
        :param value_currency: Currency, currency to convert cashflow into (and discount in this currency)
        :return: (float, float) = (value, abs(value)), converted cashflow, discounted in value_currency
        """
        value, abs_value = 0, 0
        for cash in cashflows:
            px = self.price_cashflow(cash, value_currency)
            value += px
            abs_value += np.abs(px)
        return value, abs_value

    def sum_cashflow_spot_values(self, cashflows: Iterable[CashFlow], value_currency: Currency) -> Tuple[float, float]:
        """
        Compute sum of spot cash values and absolute values of spots for a container/iterable of cashflows,
        all converted into a common currency
        :param cashflows: Iterable, a container (e.g. list or array) of cashflows
        :param value_currency: Currency, currency to convert cashflow into (and discount in this currency)
        :return: (float, float) = (value, abs(value)), converted cashflow, discounted in value_currency
        """
        return self._universe.sum_cashflow_spot_values(cashflows=cashflows, currency=value_currency)

    def discount_cashflow(self, amount: float, pay_date: Date, discount_currency: Currency) -> float:
        """
        Discount a future cashflow according to domestic, in another currency
        :param amount: float, amount of cashflow to be received
        :param pay_date: Date, when cashflow is received
        :param discount_currency: Currency, discount in this currency
        :return: float, discounted cashflow
        """
        ir_asset = self._universe.get_ir_asset(currency=discount_currency)
        if not ir_asset:
            return np.nan

        return amount * ir_asset.discount_curve.at_D(pay_date)
