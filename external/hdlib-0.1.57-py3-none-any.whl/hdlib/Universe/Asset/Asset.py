from abc import ABC

from hdlib.Core.Currency import Currency
from hdlib.DateTime.Date import Date


class Asset(ABC):
    def __init__(self, ref_date: Date, name: str, currency: Currency):
        """
        Base class for assets.
        Examples:
            1) FX Asset: contains the FX term structures / surfaces for a single FX pair
            2) EQ Asset: equity asset, e.g. SX5E, contains the spot, dividends, surface, discount curve, etc
            3) IR Asset: rates asset, e.g. USD, contains OIS discount curve (and other curves, e.g. IBOR)
            4) CR Asset: credit asset, for fixed income markets
            5) CM Asset: commodity asset (e.g. WTI, Henry)

        :param ref_date: valuation/reference date of universe
        :param name: str, name of the asset
        :param currency: Currency, primary asset currency
        """
        self._name = name
        self._currency = currency
        self._ref_date = ref_date

    @property
    def name(self) -> str:
        return self._name

    @property
    def currency(self) -> Currency:
        return self._currency

    @property
    def ref_date(self) -> Date:
        return self._ref_date
