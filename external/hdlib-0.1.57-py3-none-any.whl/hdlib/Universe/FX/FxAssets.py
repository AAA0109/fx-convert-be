from typing import Dict, Optional, Tuple, List, Iterable, Union
import numpy as np
import pandas as pd
from hdlib.Core.FxPairInterface import FxPairInterface

from hdlib.Universe.Asset.FxAsset import FxAsset
from hdlib.DateTime.Date import Date
from hdlib.Core.Currency import Currency
from hdlib.Core.FxPair import FxPair


class FxAssets(object):
    def __init__(self, ref_date: Date):
        """
        Provides FX spot / forward rates, as of a given reference date, for all known FX pairs
        :param ref_date: Date, the valuation/reference date
        """
        self._assets: Dict[str, FxAsset] = {}
        self._ref_date = ref_date

    @property
    def ref_date(self) -> Date:
        return self._ref_date

    @property
    def currencies(self):
        """Get the set of all currencies that are either the quote or base for any currency pair in the FxAssets."""
        all_currencies = set({})
        for name, asset in self._assets.items():
            all_currencies.add(asset.fx_pair.base)
            all_currencies.add(asset.fx_pair.quote)
        return all_currencies

    def get_all_fx_asset_names(self) -> List[str]:
        return [name for name, _ in self._assets.items()]

    def add_asset(self, asset: FxAsset):
        """
        Add another FX asset to the provider
        :param asset: FxAsset
        """
        self._assets[asset.name] = asset

    def get_asset(self, name: str = None, pair: Union[FxPairInterface, Tuple[Currency, Currency]] = None) -> Optional[FxAsset]:
        """
        Get an FX asset by name (they are stored as "USD/EUR")
        :param pair: currency pair (tuple[base,quote]), must supply this or the name
        :param name: str, name of FX pair, of the form "USD/EUR"
        :return: FxAsset if found, else None
        """
        if not name:
            if isinstance(pair, FxPairInterface):
                name = pair.name
            else:
                name = f"{pair[0].get_mnemonic()}/{pair[1].get_mnemonic()}"

        return self._assets.get(name, None)

    def get_fx_spots(self, names: Optional[Iterable[str]] = None,
                     pairs: Optional[Iterable[FxPairInterface]] = None) -> pd.Series:
        if names is None and pairs is None:
            raise ValueError("either names or pairs must not be None")
        if pairs is not None:
            return pd.Series(index=pairs, data=[self.get_fx_spot(pair=pair) for pair in pairs])
        return pd.Series(index=names, data=[self.get_fx_spot(name=name) for name in names])

    def get_fx_spot(self, name: str = None, pair: FxPairInterface = None) -> float:
        return self.get_fx_forward(date=self._ref_date, name=name, pair=pair)

    def get_fx_forward(self, date: Date, name: str = None, pair: FxPairInterface = None) -> float:
        """
        Get the FX forward rate at some date in the future (ref_date or later)
        :param date: Date, the date in future along the forward curve
        :param pair: currency pair (tuple[base,quote]), must supply this or the name
        :param name: str, name of FX pair, of the form "USD/EUR"
        :return: float, forward rate
        """
        if not name:
            if not pair:
                raise ValueError("You must supply either the name of the pair or the pair of currencies")
            name = pair.name

        fx_asset = self.get_asset(name)
        if fx_asset:
            return fx_asset.fwd_curve.at_D(date=date)

        fx_asset_inv = self.get_asset(f'{name[4:]}/{name[:3]}')  # flip the pair
        if fx_asset_inv:
            return 1 / fx_asset_inv.fwd_curve.at_D(date=date)

        # TODO: need the ability to triangulate, ie chain, currency pairs
        # e.g. USD/GBP = USD/JPY * JPY/GBP
        # However: it is better practice to precompute all of this, and adjust the vol surfaces properly

        return np.nan

