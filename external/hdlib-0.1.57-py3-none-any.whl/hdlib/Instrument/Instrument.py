from abc import ABC, abstractmethod
import numpy as np
from typing import Union

from hdlib.DateTime.Date import Date
from hdlib.Core.Currency import Currency


class Instrument(ABC):
    def __init__(self, expiry: Date, currency_long: Currency):
        """
        Base instrument class.
        :param expiry:
        :param currency_long: Currency, the primary currency, which is currency of cash inflows. Note
        that instruments can have multiple currencies (e.g. cross-currency swaps), but this is the
        currency of cashflows from a long position in the instrument. For now, we assume cashflows in
        all directions are in the same currency
        """
        self._expiry = expiry
        self._currency = currency_long

    @property
    def expiry(self) -> Date:
        """
        Get the expiration date of instrument, AKA the Final Fixing Date. This is not necessarily equal
        to the settlement date, but it cannot be later than the settlement date.
        """
        return self._expiry

    @property
    def currency_long(self) -> Currency:
        return self._currency

    @property
    def currency_short(self) -> Currency:
        return self._currency


class BasicInstrument(Instrument):
    """
    A basic instrument is a single currency, single underlying instrument
    """
    def __init__(self, expiry: Date, currency: Currency):
        super(BasicInstrument, self).__init__(expiry=expiry, currency_long=currency)

    @abstractmethod
    def payoff(self, underlying: Union[float, np.array]) -> Union[float, np.array]:
        raise NotImplementedError

    @property
    def currency(self) -> Currency:
        return self.currency_long


class Forward(BasicInstrument):
    """
    A forward is a struck contract with payoff (F_T - K)
    """
    def __init__(self,
                 strike: float,
                 expiry: Date,
                 currency: Currency):
        super().__init__(expiry=expiry, currency=currency)
        self._strike = strike

    @abstractmethod
    def payoff(self, underlying: Union[float, np.array]) -> Union[float, np.array]:
        return underlying - self._strike


class VanillaOption(BasicInstrument):
    def __init__(self,
                 strike: float,
                 expiry: Date,
                 is_call: bool,
                 currency: Currency):
        """ Vanilla Option """
        super().__init__(expiry=expiry, currency=currency)
        self._strike = strike
        self._is_call = is_call

    @property
    def strike(self) -> float:
        return self._strike

    @property
    def is_call(self) -> bool:
        return self._is_call

    def payoff(self, underlying: Union[float, np.array]) -> Union[float, np.array]:
        """
        Calculate the payoff (cashflow) that would occur given a particular value of the underlying
        :param underlying: float or array of underlying value
        :return: float or array, matches type that was supplied
        """
        return np.maximum(0, underlying - self._strike) if self._is_call \
            else np.maximum(0, self._strike - underlying)
