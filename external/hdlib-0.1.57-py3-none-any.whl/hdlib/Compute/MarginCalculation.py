from typing import Iterable, Dict

import numpy as np

from hdlib.Core.Currency import Currency

from hdlib.Hedge.Cash.CashPositions import CashPositions, VirtualFxPosition


class IBMarginCalculator:
    def __init__(self, spot_fx_cache, margin_rates_cache):
        self.spot_fx_cache = spot_fx_cache
        self.margin_rates_cache = margin_rates_cache

    def compute_margin_from_vfx(self,
                                virtual_fx: Iterable[VirtualFxPosition],
                                domestic: Currency,
                                additional_cash: Dict[Currency, float] = None):
        cash_positions = CashPositions()
        # Add cash from virtual Fx positions.
        for v_fx in virtual_fx:
            cash_positions.add_cash_from_virtual_fx(v_fx)

        # Potentially add additional cash.
        if additional_cash:
            for currency, amount in additional_cash.items():
                cash_positions.add_cash(currency=currency, amount=amount)
        return self.compute_margin(cash_positions=cash_positions, domestic=domestic)

    def compute_margin(self, cash_positions: CashPositions, domestic: Currency) -> float:
        """
        Compute margin for a set of cash positions, with a specified domestic currency (called base currency in IB
        documentation, not to be confused with the base currency of an Fx pair).

        See https://ibkr.info/article/970 for an example of how to calculate margin.
        """
        positive_positions = []
        negative_positions = []

        for currency, amount in cash_positions.cash_by_currency.items():
            if amount == 0:
                continue
            # Convert amount to value in base (domestic) currency.
            value = self.spot_fx_cache.convert_value(value=amount, from_currency=currency, to_currency=domestic)
            if np.isnan(value):
                raise ValueError(f"could not convert from {currency} to {domestic}")
            rate = self.margin_rates_cache.get_rate_for_currency(currency=currency)
            if np.isnan(rate):
                raise ValueError(f"could not get the margin rate for {currency}")

            if 0 < amount:
                positive_positions.append(np.array([rate, value]))
            else:
                # Accumulate a *positive* number for the negative position.
                negative_positions.append(np.array([rate, -value]))

        # Sort positive net liquid domestic equivalents by smallest rate to largest rate.
        positive_positions = list(sorted(positive_positions, key=lambda x: x[0]))

        # Calculate the margin requirement on that portion which may be used to off-set the negative net liq value
        margin = 0

        it = 0
        for rate1, negative_position in sorted(negative_positions, reverse=True, key=lambda x: x[1]):
            while it < len(positive_positions):
                rate2, amount = positive_positions[it]
                haircut = max(rate1, rate2)
                # Start with the largest negative currency balance.
                if negative_position < amount:
                    # We only have to use part of this position to cover the remaining negative positions.
                    positive_positions[it][1] -= negative_position
                    margin += haircut * negative_position
                    break
                else:
                    # We consume the entire positive position, and need to consume more to cover the negative.
                    negative_position -= amount
                    positive_positions[it][1] = 0
                    margin += haircut * amount
                    it += 1

        return margin
