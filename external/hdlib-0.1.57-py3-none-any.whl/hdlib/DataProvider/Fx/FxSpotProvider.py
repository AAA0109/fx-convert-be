from hdlib.Core.FxPairInterface import FxPairInterface
from hdlib.DateTime.Date import Date

import pandas as pd
from typing import Iterable
from abc import ABC, abstractmethod


class FxSpotProvider(ABC):
    """
    Base class for data providers that can provide spot fx data. Note that a provider may be able to provide many
    types of data, but to qualify as an FxSpotProvider, it must simply implement this interface
    """

    @abstractmethod
    def fx_spot(self, date: Date, fx_pair: FxPairInterface) -> float:
        """
        Get Fx Spot rate on a given date
        :param date: Date, the date to observe the spot
        :param fx_pair: FxPair, the fx pair
        :return: float, the spot fx rate
        """
        raise NotImplementedError

    @abstractmethod
    def fx_spots_in_range(self, start: Date, end: Date, fx_pair: FxPairInterface) -> pd.Series:
        """
        Get the spot Fx rates between a range of dates. The main method to override
        :param start: Date, the start date for spot time series (inclusive)
        :param end: Date, the end date for spot time series (inclusive)
        :param fx_pair: FxPair, the pair for the time series
        :return: pd.Series, a series of Date to values in increasing date order
        """
        raise NotImplementedError

    def multi_fx_spots_in_range(self, start: Date, end: Date, fx_pairs: Iterable[FxPairInterface]) -> pd.DataFrame:
        """
        Get the spot Fx rates between a range of dates, for multiple fx_pairs. Note that the date index corresponds to
        dates for which we have at least one pair, so some values can be nan if there is no FX for a given pair on that
        date
        :param start: Date, the start date for spot time series (inclusive)
        :param end: Date, the end date for spot time series (inclusive)
        :param fx_pairs: iterable of FxPair, the fx pairs for the time series
        :return: pd.DataFrame, index is dates (in increasing order), one column per fx_pair
        """
        spots = []
        columns = []
        for fx_pair in fx_pairs:
            spots.append(self.fx_spots_in_range(start=start, end=end, fx_pair=fx_pair))
            columns.append(str(fx_pair))

        df = pd.concat(spots, axis=1)
        df.columns = columns
        return df


class CachedFxSpotProvider(FxSpotProvider):
    """
    A simple SpotFxProvider which caches all the spot data it knows from the beginning in a DataFrame.
    """

    def __init__(self, spots: pd.DataFrame):
        """"""
        self._spots = spots

    def fx_spots_in_range(self, start: Date, end: Date, fx_pair: FxPairInterface) -> pd.Series:
        spots = self._spots[fx_pair.name]
        return spots[(start <= spots.index) & (spots.index <= end)]

    def multi_fx_spots_in_range(self, start: Date, end: Date, fx_pairs: Iterable[FxPairInterface]) -> pd.DataFrame:
        spots = self._spots[(fx_pair.name for fx_pair in fx_pairs)]
        return spots[(start <= spots.index) & (spots.index <= end)]

    def fx_spot(self, date: Date, fx_pair: FxPairInterface) -> float:
        spots = self._spots[fx_pair.name]
        return spots.loc[date]

    def fx_spot_full_history(self) -> pd.DataFrame:
        return self._spots

    def fx_spots_on_date(self, date: Date) -> pd.Series:
        return self._spots.loc[date]
