from typing import Dict, Any
import numpy as np
import pandas as pd

from pytorch_lightning.callbacks import EarlyStopping
from darts.metrics import smape

from hdml.Tuning.HyperTuner import HyperTuner, TunedResult
from hdml.Models.Darts.Nbeats import (
    NBEATSModel, DartsNbeats, DartsNbeatsConfig
)

# for optuna
import optuna
import warnings
from pytorch_lightning import LightningModule
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import Callback


class PyTorchLightningPruningCallback(Callback):
    # It has bug with PyTorchLightningPruningCallback in optuna,
    # so we can use a shared code in GitHub instead of optuna one
    # ref: https://github.com/optuna/optuna-examples/issues/166#issuecomment-1403112861
    """PyTorch Lightning callback to prune unpromising trials.
    See `the example <https://github.com/optuna/optuna-examples/blob/
    main/pytorch/pytorch_lightning_simple.py>`__
    if you want to add a pruning callback which observes accuracy.
    Args:
        trial:
            A :class:`~optuna.trial.Trial` corresponding to the current evaluation of the
            objective function.
        monitor:
            An evaluation metric for pruning, e.g., ``val_loss`` or
            ``val_acc``. The metrics are obtained from the returned dictionaries from e.g.
            ``pytorch_lightning.LightningModule.training_step`` or
            ``pytorch_lightning.LightningModule.validation_epoch_end`` and the names thus depend on
            how this dictionary is formatted.
    """

    def __init__(self, trial: optuna.trial.Trial, monitor: str) -> None:
        super().__init__()

        self._trial = trial
        self.monitor = monitor

    def on_validation_end(self, trainer: Trainer, pl_module: LightningModule) -> None:
        # When the trainer calls `on_validation_end` for sanity check,
        # do not call `trial.report` to avoid calling `trial.report` multiple times
        # at epoch 0. The related page is
        # https://github.com/PyTorchLightning/pytorch-lightning/issues/1391.
        if trainer.sanity_checking:
            return

        epoch = pl_module.current_epoch

        current_score = trainer.callback_metrics.get(self.monitor)
        if current_score is None:
            message = (
                f"The metric '{self.monitor}' is not in the evaluation logs for pruning. "
                "Please make sure you set the correct metric name."
            )
            warnings.warn(message)
            return

        self._trial.report(current_score, step=epoch)
        if self._trial.should_prune():
            message = f"Trial was pruned at epoch {epoch}."
            raise optuna.TrialPruned(message)


class NBeatsTunedResult(TunedResult):
    pass


class NbeatsTuner(HyperTuner):
    _model_config: DartsNbeatsConfig
    
    def tune(
            self,
            X_fit: pd.DataFrame,
            y_fit: pd.DataFrame) -> NBeatsTunedResult:
        params_to_optimal = self._model_config.hypertunner_config.get(
            "params_to_optimal", None)
        n_trials = self._model_config.hypertunner_config.get("n_trials", None)
        debug = self._model_config.hypertunner_config.get("debug", False)

        # check if params_to_optimal is None, then set a default params_to_optimal
        if params_to_optimal is None:
            params_to_optimal = {
                "input_chunk_length": {
                    "type": "int",
                    "low": 3,
                    "high": 10, },
                "num_layers": {
                    "type": "int",
                    "low": 2,
                    "high": 6, },
                "dropout": {
                    "type": "float",
                    "low": 0.1,
                    "high": 0.7,
                    "log": True, },
                "generic_architecture": {
                    "type": "categorical",
                    "choices": [False, True], },
            }

        # get best_params_by_optuna
        best_params_by_optuna = self._optimize_hyperparameter_optuna(
            X_fit=X_fit,
            y_fit=y_fit,
            params_to_optimal=params_to_optimal,
            n_trials=n_trials,
            debug=debug
        )

        # update best_params_by_optuna to self.model_config
        for key, val in best_params_by_optuna.items():
            setattr(self._model_config, key, val)

        return NBeatsTunedResult(optimal_config=self._model_config)

    def _optimize_hyperparameter_optuna(
            self,
            X_fit: pd.DataFrame,
            y_fit: pd.DataFrame,
            params_to_optimal: Dict[str, Any],
            n_trials: int = 10,
            debug: bool = False) -> Dict[str, Any]:
        default_model = DartsNbeats(self._model_config)

        train_series, val_series = default_model._create_training_dataset(
            X_fit,
            self._model_config.validation_size)

        # initial optimal_params
        optimal_params = self._model_config.training_params()

        def objective(trial: optuna.trial.Trial):
            for param_name, content in params_to_optimal.items():
                content: dict
                
                if content["type"] == "int":
                    # should behavior like this:
                    # optimal_params["num_layers"] = trial.suggest_int("num_layers", 2, 6)
                    optimal_params[param_name] = trial.suggest_int(
                        name=param_name,
                        low=content.get("low"),
                        high=content.get("high"),
                        # pass by defualt value `1`, if content don't have key "step"
                        step=content.get("step", 1),
                        # pass by defualt value `False`, if content don't have key "log"
                        log=content.get("log", False),
                    )
                elif content["type"] == "float":
                    # should behavior like this:
                    # optimal_params["dropout"] = trial.suggest_float("dropout", 0.0, 0.7, log=True)
                    optimal_params[param_name] = trial.suggest_float(
                        name=param_name,
                        low=content.get("low"),
                        high=content.get("high"),
                        # pass by defualt value `None`, if content don't have key "step"
                        step=content.get("step", None),
                        # pass by defualt value `False`, if content don't have key "log"
                        log=content.get("log", False),
                    )
                elif content["type"] == "categorical":
                    # should behavior like this:
                    # optimal_params["generic_architecture"] = trial.suggest_categorical("generic_architecture", [False, True])
                    optimal_params[param_name] = trial.suggest_categorical(
                        name=param_name,
                        choices=content.get("choices"),
                    )
                else:
                    raise RuntimeError(
                        """optimizing hyperparameter with optuna failed,
                        one or more type of params to optimal are not in 
                        ["int", "float", "categorical"]""")

            # throughout training we'll monitor the validation loss
            # for both pruning and early stopping
            pruner = PyTorchLightningPruningCallback(trial, monitor="val_loss")
            early_stopper = EarlyStopping(
                monitor="val_loss", min_delta=0.05, patience=3, verbose=True)
            callbacks = [pruner, early_stopper]

            # use CPU only
            optimal_params["pl_trainer_kwargs"] = {"callbacks": callbacks,}
            num_workers = 0

            # build the model
            model = NBEATSModel(
                **optimal_params)

            # train the model
            model.fit(
                series=train_series,
                val_series=val_series,
                num_loader_workers=num_workers,
            )

            # reload best model over course of training
            model = NBEATSModel.load_from_checkpoint(
                **self._model_config.loading_params())

            # Evaluate how good it is on the validation set, using sMAPE
            preds = model.predict(series=train_series, n=len(val_series))
            smapes = smape(val_series, preds, n_jobs=-1, verbose=True)
            smape_val = np.mean(smapes)

            return smape_val if smape_val != np.nan else float("inf")

        # for convenience, print some optimization trials information
        def callback(study: optuna.study.Study, trial: optuna.trial.FrozenTrial):
            print(
                f"Current value: {trial.value}, Current params: {trial.params}")
            print(
                f"Best value: {study.best_value}, Best params: {study.best_trial.params}")

        # optimize hyperparameters by minimizing the sMAPE on the validation set
        study = optuna.create_study(direction="minimize")
        study.optimize(objective, n_trials=n_trials, callbacks=[callback])

        return study.best_trial.params
