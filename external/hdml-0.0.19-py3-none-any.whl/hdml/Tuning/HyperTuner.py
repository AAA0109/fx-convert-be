from abc import ABC, abstractmethod
from typing import Any

import pandas as pd

from hdml.Models.ForecasterConfig import ForecasterConfig


# TODO: this will need a lot more work, this is just a stand in until we really understand what we want


class TunedResult(object):
    """
    Object representing the outcome of a hyper parameter tuning run. This will include the parameter settings searched,
    the corresponding metrics, and the best parameter setting relative to selected scoring method
    """
    # TODO: the code
    def __init__(self, optimal_config: ForecasterConfig):
        self._optimal_config = optimal_config  # TODO: other configs tested, and their metrics
        # TODO: optimal metrics (set this in the base TunedResult class)

    @property
    def optimal_config(self) -> ForecasterConfig:
        return self._optimal_config
class HyperTuner(ABC):
    def __init__(self, model_config: ForecasterConfig):
        self._model_config = model_config

    def set_model(self, model: Any) -> 'HyperTuner':
        self._model = model
        return self

    @abstractmethod
    def tune(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> TunedResult:
        raise NotImplementedError
