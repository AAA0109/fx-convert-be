from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Tuning.HyperTuner import HyperTuner


class TunnerFactory:

    def __init__(self, model_config: ForecasterConfig):
        """

        :param model_config: model config
        """
        self._model_config: ForecasterConfig = model_config

    def tunner(self) -> HyperTuner:
        """
        Create a hyper tuner
        """
        model_config = self._model_config
        if model_config.model_name == "darts_nbeats":
            from hdml.Tuning.Darts.NbeatsTuner import NbeatsTuner
            return NbeatsTuner(model_config=model_config)

        if model_config.model_name == "darts_nhits":
            from hdml.Tuning.Darts.NhitsTuner import NhitsTuner
            return NhitsTuner(model_config=model_config)

        raise NotImplementedError(
            f"tunner not implemented for model: {model_config.model_name}")
