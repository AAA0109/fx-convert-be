from abc import ABC, abstractmethod

from hdlib.Core.FxPairInterface import FxPairInterface
from hdlib.DateTime.Date import Date
import pandas as pd

# from apps.optex.lib.utils import load_fx_pair_spreads


class FxDataLoader(ABC):

    @abstractmethod
    def load_data(self,
                  fx_pair: FxPairInterface,
                  start_date: Date,
                  end_date: Date) -> pd.DataFrame:
        raise NotImplementedError


# class FileFxDataLoader(FxDataLoader):
#     def __init__(self, fdir: str):
#         self._fdir = fdir  # f"C:/Sandbox/FxSpread/FxSpotBidAskIntra_15 mins/"
#
#     def load_data(self,
#                   fx_pair: FxPairInterface,
#                   start_date: Date,
#                   end_date: Date) -> pd.DataFrame:
#         symbol = f"{fx_pair.base}{fx_pair.quote}"
#         fpath = f"{self._fdir}/{symbol}.csv"
#
#         return load_fx_pair_spreads(fpath=fpath, min_time=start_date, max_time=end_date)