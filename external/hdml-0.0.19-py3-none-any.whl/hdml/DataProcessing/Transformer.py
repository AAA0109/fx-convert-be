import logging
from abc import ABC

import pandas as pd

logger = logging.getLogger(__name__)


class BaseDataTransformer(ABC):
    """
    transform flat table into timeseries_table.
    timeseries_table has timeseries names as columns and dates as index
    """
    pass


class OptionDataTransformer(BaseDataTransformer):
    pass


class AssetDataTransformer(BaseDataTransformer):
    """
    transform flat table into timeseries_table.
    """

    def transform_data(self, df_raw: pd.DataFrame) -> pd.DataFrame:
        """
        Transform dataframe into input(s) and target(s) associated to particular asset and features
        :param df_raw:
                 date     | feature     |    asset      |  value  |
                ------------------------------------------------------
                2020-01-01  |   rate      |   USD/AUD     |   0.06  |
                2020-01-02  |   fxforward |   USD/CAD     |   0.09  |
                2020-01-03  |   sma       |   USD/MXN     |   0.06  |
                2020-01-04  |   macd      |   USD/GBP     |   0.01  |
                2020-01-05  |   diff      |   USD/JPY     |   0.08  |
                  ...       |   ...       |   ....        |   ....  |
        """

        df_raw["date"] = pd.to_datetime(df_raw["date"], utc=True)
        df_raw["feature-asset"] = df_raw["feature"] + "#" + df_raw["asset"]

        timeseries_table = pd.pivot_table(df_raw, values="value", index="date", columns="feature-asset")
        timeseries_table = self._handle_nan(timeseries_table)
        timeseries_table.columns.name = None
        return timeseries_table

    # ======== Private Methods==================
    @staticmethod
    def _handle_nan(timeseries_table: pd.DataFrame) -> pd.DataFrame:
        # Calculate the number of NaNs per column
        nans_per_column = timeseries_table.isna().sum()

        # Filter columns that have NaN values
        columns_with_nans = nans_per_column[nans_per_column > 0]

        # Calculate the total number of NaNs
        number_of_nans = columns_with_nans.sum()

        if number_of_nans > 0:
            logger.warning(f"There are {number_of_nans} missing values in the dataset!")
            for column, num_nans in columns_with_nans.iteritems():
                logger.warning(f"Column '{column}' has {num_nans} NaN values")

                # Get the index of rows with NaN values for the current column
                nan_rows_index = timeseries_table[timeseries_table[column].isna()].index

                # Convert the index values to strings
                index_as_string = ', '.join(str(index_value) for index_value in nan_rows_index)

                # Log the dates on the index of the DataFrame with NaN values
                logger.warning(f"Dates with NaN values in column '{column}':")
                logger.warning(index_as_string)
            timeseries_table = timeseries_table.interpolate(method='linear', axis=0)
            logger.warning(f"Nan values are filled with linear interpolation")
        return timeseries_table
