from typing import Union

from hdlib.DateTime.Date import Date

from hdml.DataProcessing.DataConfig import DataConfig


class StridedWalkforwardConfig(DataConfig):
    """
    turn yaml config into python object
    """

    def __init__(
            self,
            start_date: Union[Date, str],
            end_date: Union[Date, str],
            length_walkforward_interval: int,
            train_size_proportion: float,
            expanding: bool,
            embargo_period_active: bool = False,
            embargo_period: int = 0,
            stride: int = 1,
            *args, **kwargs
    ):
        """
        to  serialize data config and make sure it's datatype
        :param start_date: start date of walkforward
        :param end_date: end date of walkforward
        :param length_walkforward_interval: total length ( in days ) of one walkforward interval
        :param train_size_proportion: proportion of train size compared to length_walkforward_interval
        :param expanding: if true, training data will expand overtime and no data to be thrown away
        """
        super().__init__(
            start_date=start_date,
            end_date=end_date,
            *args, **kwargs
        )
        self.stride = stride
        self.length_walkforward_interval = length_walkforward_interval
        self.train_size_proportion = train_size_proportion
        self.expanding = expanding
        self.embargo_period_active = embargo_period_active
        self.embargo_period = embargo_period
