from typing import Union

from hdlib.DateTime.Date import Date

from hdml.Utils.Config import BaseConfig


class DataConfig(BaseConfig):
    def __init__(
            self,
            start_date: Union[Date, str],
            end_date: Union[Date, str],
            *args, **kwargs
    ):
        """
        to  serialize data config and make sure it's datatype
        :param start_date: start date (e.g. of walkforward)
        :param end_date: end date (e.g. of walkforward)
        :param args: additional arguments
        :param kwargs: additional arguments
        """
        super().__init__(*args, **kwargs)
        self.start_date = Date.to_date(start_date)
        self.end_date = Date.to_date(end_date)
