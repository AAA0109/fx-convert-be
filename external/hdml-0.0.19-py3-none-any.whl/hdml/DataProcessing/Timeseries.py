"""
Timeseries
----------
It represents a univariate or multivariate time series, with lags. [samples, time, dimensions]

The values are stored in an array of shape `[samples, time, dimensions]`, where
`dimensions` are the dimensions (or "components", or "columns") of multivariate series,
and `samples` are samples data or also known as minibatch.
"""

from datetime import datetime
from typing import List, Sequence, Optional

import numpy as np
import pandas as pd


class TimeSeriesTensor:
    X3D: np.ndarray
    Y3D: pd.DataFrame
    """
    class to handle multidimensional array and indexing
    :param dataset: dataframe 2 dimension, columns correspond to features, index correspond to date
            in this example we have 2 features a and b
            Out[2]:
                          a      b
                0        a0     b0
                1        a1     b1
                2        a2     b2
                3        a3     b3
                4        a4     b4
                ...     ...    ...
                4995  a4995  b4995
                4996  a4996  b4996
                4997  a4997  b4997
                4998  a4998  b4998
                4999  a4999  b4999
    :param sliding_window_dataset:
            column name consist of 3 information
            (input/target) | feature | time lags
            e.g. X | a | t-8
            - input/target. X for input and Y for target
            - feature name. in this example a
            - time lags. in this example t-8 days

            complete table looks like as follow. 9,10,11,12,... are index
            Out[1]:
                     X|a|t-9 X|b|t-9 X|a|t-8 X|b|t-8  ... Y|a|t+4 Y|b|t+4 Y|a|t+5 Y|b|t+5
                9         a0      b0      a1      b1  ...     a13     b13     a14     b14
                10        a1      b1      a2      b2  ...     a14     b14     a15     b15
                11        a2      b2      a3      b3  ...     a15     b15     a16     b16
                12        a3      b3      a4      b4  ...     a16     b16     a17     b17
                13        a4      b4      a5      b5  ...     a17     b17     a18     b18
                ...      ...     ...     ...     ...  ...     ...     ...     ...     ...
                4990   a4981   b4981   a4982   b4982  ...   a4994   b4994   a4995   b4995
                4991   a4982   b4982   a4983   b4983  ...   a4995   b4995   a4996   b4996
                4992   a4983   b4983   a4984   b4984  ...   a4996   b4996   a4997   b4997
                4993   a4984   b4984   a4985   b4985  ...   a4997   b4997   a4998   b4998
                4994   a4985   b4985   a4986   b4986  ...   a4998   b4998   a4999   b4999
    :param sliding_window_input_features: list of input columns
    Out[3]:
        ['X|a|t-9','X|b|t-9', 'X|a|t-8','X|b|t-8','X|a|t-7','X|b|t-7','X|a|t-6','X|b|t-6','X|a|t-5',
         'X|b|t-5','X|a|t-4','X|b|t-4','X|a|t-3','X|b|t-3','X|a|t-2','X|b|t-2','X|a|t-1','X|b|t-1','X|a|t','X|b|t']

    :param sliding_window_target_features: list of target columns
    Out[4]:
        ['Y|a|t+1','Y|b|t+1','Y|a|t+2','Y|b|t+2','Y|a|t+3','Y|b|t+3','Y|a|t+4','Y|b|t+4','Y|a|t+5','Y|b|t+5']
    :param input_features: original input features
    Out[5]: ['a', 'b']
    :param targets: original target features
    Out[6]: ['a', 'b']
    :param lookback: lookback windows
    Out[7]: 10
    :param lookahead: forecast horizon
    Out[7]: 5
    """

    def __init__(self,
                 X: pd.DataFrame,
                 lookback: int,
                 y: pd.DataFrame = pd.DataFrame(),
                 lookahead: int = 1,
                 start_index_of_targets: int = 0,
                 order_of_3D_array: str = 'SLF', # SLF: samples, lookback, features
                 ):
        """
        :param X: dataframe 2 dimension, columns correspond to features, index correspond to date
                in this example we have 2 features a and b.
        :param lookback: number of time lags
        :param y: dataframe 2 dimension, columns correspond to features, index correspond to date.
                y are compatible with multiple features
        :param lookahead: number of time steps ahead
        :param start_index_of_targets: index of target start
        :return: TimeSeriesTensor object
        """

        self.X = X
        self.y = y
        self.lookback = lookback
        self.lookahead = lookahead
        self.start_index_of_targets = start_index_of_targets
        self.order_of_3D_array = order_of_3D_array

        # sliding_window_dataset stands for sliding window dataset
        self.sliding_window_dataset = self.__class__._build_sliding_window_dataset(
            dataset=self.dataset,
            input_features=self.input_features,
            target_features=self.target_features,
            lookback=self.lookback,
            lookahead=self.lookahead,
            start_index_of_targets=self.start_index_of_targets,
        )

        start_idx = self.lookback - 1
        end_idx = -self.lookahead + 1 - self.start_index_of_targets

        if end_idx == 0:
            if not self.dataset.iloc[start_idx:].index.equals(self.sliding_window_dataset.index):
                raise RuntimeError(f"index of 'dataset' doesn't match with 'sliding_window_dataset'")
        else:
            if not self.dataset.iloc[start_idx:end_idx].index.equals(self.sliding_window_dataset.index):
                raise RuntimeError(f"index of 'dataset' doesn't match with 'sliding_window_dataset'")

        if not len(self.dataset.index) - len(self.sliding_window_dataset.index) == abs(end_idx - start_idx):
            raise RuntimeError(f"there is something wrong with the lookback")

        self.X3D = self._convert_to_tensor(self.sliding_window_dataset.loc[:, self.sliding_window_input_features])
        self.Y3D = self.sliding_window_dataset.loc[:, self.sliding_window_target_features]


    @property
    def input_features(self) -> List[str]:
        """
        :return: list of input features
        """
        return self.X.columns.tolist()

    @property
    def target_features(self) -> List[str]:
        """
        :return: list of target features
        :return:
        """
        return self.y.columns.tolist()

    @property
    def dataset(self) -> pd.DataFrame:
        """
        return X and y merged together.
        :return:
        """
        overlap_cols = set(self.input_features).intersection(self.target_features)
        y_columns = self.y.columns.tolist()
        for col in overlap_cols:
            y_columns.remove(col)
        y = self.y.loc[:,y_columns].copy()

        if len(y_columns) > 0:
            dataset = pd.merge(self.X, y, how='left', left_index=True, right_index=True)
        else:
            dataset = self.X.copy()
        dataset = dataset[~dataset.index.duplicated(keep='first')]
        dataset.sort_index(inplace=True)
        return dataset

    @property
    def sliding_window_input_features(self) -> List[str]:
        return [i for i in self.sliding_window_dataset.columns.tolist() if 'X' in i.split("|")[0]]

    @property
    def sliding_window_target_features(self) -> List[str]:
        return [i for i in self.sliding_window_dataset.columns.tolist() if 'Y' in i.split("|")[0]]

    @property
    def index(self) -> Sequence[datetime]:
        return self.sliding_window_dataset.index

    @property
    def shape(self):
        return self.X3D.shape

    def find_columns_by_keyword(self, string: str, n_col: Optional[int] = None):
        """
        find a group of features by searching
        Example:
        >>> tstensor.find_columns_by_keyword("Y")
        Out[1]:
            ['Y|next_diff_volatility-USD/AUD|t',
             'Y|next_diff_volatility-USD/AUD|t+1',
             'Y|next_diff_volatility-USD/AUD|t+2',
             'Y|next_diff_volatility-USD/AUD|t+3',
             'Y|next_diff_volatility-USD/AUD|t+4']
        the output are all the columns associated to Y
        :param string: keyword
        :param n_col: choose column 1 to 3
        :return:
        """
        if n_col is not None:
            list_ = []
            for i in self.sliding_window_dataset.columns.tolist():
                if i.split("|")[n_col - 1] == string:
                    list_.append(i)
            return list_
        else:
            return [i for i in self.sliding_window_dataset.columns.tolist() if string in i]


    # =========PRIVATE METHODS================
    def _convert_to_tensor(self, x: pd.DataFrame) -> np.ndarray:
        """
        convert dataframe to 3D tensor
        :param x: 2D dataframe
        :return: 3D numpy array [n_samples, lookback, n_features]
        """
        tensor = x.to_numpy().reshape((x.shape[0], self.lookback, len(self.input_features)))
        if self.order_of_3D_array == 'SLF':
            return tensor
        elif self.order_of_3D_array == 'SFL':
            return np.swapaxes(tensor, 1, 2)

    @staticmethod
    def _build_sliding_window_dataset(
            dataset: pd.DataFrame,
            input_features: List[str],
            target_features: List[str],
            lookback: int = 1,
            lookahead: int = 1,
            start_index_of_targets: int = 0,
            dropnan: bool = True
    ) -> pd.DataFrame:
        """
        converting normal dataframe into dataframe that represent sliding window. i.e. it has lags
        :param dataset: dataframe with columns representing features and index representing date
        :param inputs: input features
        :param targets: target features
        :param lookback: lookback window
        :param lookahead: forecast horizon
        :param start_index_of_targets: days to start forecast horizon
        :param dropnan: drop row with nan if exist
        :return: sliding_window_dataset
        Example:
        start_index_of_targets = 3
            Out[3]:
                 X|a|t-3 X|a|t-2 X|a|t-1  X|a|t Y|a|t+3 Y|a|t+4 Y|a|t+5 Y|a|t+6 Y|a|t+7
            9         a6      a7      a8     a9     a12     a13     a14     a15     a16
            10        a7      a8      a9    a10     a13     a14     a15     a16     a17
            11        a8      a9     a10    a11     a14     a15     a16     a17     a18
            12        a9     a10     a11    a12     a15     a16     a17     a18     a19
            13       a10     a11     a12    a13     a16     a17     a18     a19     a20
            ...      ...     ...     ...    ...     ...     ...     ...     ...     ...
            4988   a4985   a4986   a4987  a4988   a4991   a4992   a4993   a4994   a4995
            4989   a4986   a4987   a4988  a4989   a4992   a4993   a4994   a4995   a4996
            4990   a4987   a4988   a4989  a4990   a4993   a4994   a4995   a4996   a4997
            4991   a4988   a4989   a4990  a4991   a4994   a4995   a4996   a4997   a4998
            4992   a4989   a4990   a4991  a4992   a4995   a4996   a4997   a4998   a4999

        we see that the forecast horizon starts from t+3
        """
        cols, names = list(), list()
        """
        (t-n+1, ... t). obeserve data from today till (n-1) days ago
        """
        for i in range(lookback - 1, -1, -1):
            cols.append(dataset.loc[:, input_features].shift(i))
            if i == 0:
                names += [('X|%s|t' % (j)) for j in input_features]
            else:
                names += [('X|%s|t-%d' % (j, i)) for j in input_features]
        # forecast sequence
        """
        (t, t+1, ... t+n-1) by default. Can be adjusted by customizing start_index_of_targets
        """
        if len(target_features) > 0:
            for i in range(start_index_of_targets, lookahead + start_index_of_targets):
                cols.append(dataset.loc[:, target_features].shift(-i))
                if i == 0:
                    names += [('Y|%s|t' % (j)) for j in target_features]
                else:
                    names += [('Y|%s|t+%d' % (j, i)) for j in target_features]

        # put it all together
        agg = pd.concat(cols, axis=1)
        agg.columns = names
        # drop rows with NaN values
        if dropnan:
            agg.dropna(inplace=True)
        return agg

    # =========MAGIC METHODS================
    def __repr__(self):
        return repr(self.X3D)

    def __str__(self) -> str:
        return self.__class__.__name__

    def __getitem__(self, item):
        '''
        e.g. lookback = 5 is equal to x(t),x(t-1),x(t-2),x(t-3),x(t-4)
        input: tuple or list. pass start and end date
        the input of this has to be date. either in the form of string of date time
        '''

        try:
            if isinstance(item, (list, tuple, str, datetime)):
                idx_start = self.dataset.index.get_indexer([item], method='bfill')[0]
                # print("start date", self.dataset.iloc[idx_start].name)
                dataset = self.dataset.iloc[
                          idx_start - self.lookback + 1:idx_start + self.lookahead + self.start_index_of_targets]
            elif isinstance(item, (slice)):
                idx_start = self.dataset.index.get_indexer([item.start], method='bfill')[0]
                idx_stop = self.dataset.index.get_indexer([item.stop], method='ffill')[0]
                # print("start date", self.dataset.iloc[idx_start].name)
                # print("stop date", self.dataset.iloc[idx_stop].name)
                dataset = self.dataset.iloc[
                          idx_start - self.lookback + 1:idx_stop + self.lookahead + self.start_index_of_targets]
            else:
                raise TypeError("indexing is not correct!!")

            if dataset.shape[0] == 0:
                raise RuntimeError(f"slicing results in empty dataset")

        except:
            raise RuntimeError("slicing fails")

        return self.__class__(
            X=dataset.loc[:, self.input_features],
            lookback=self.lookback,
            y=dataset.loc[:, self.target_features],
            lookahead=self.lookahead,
            start_index_of_targets=self.start_index_of_targets
        )

    def __add__(self, other):
        """
        extend time series tensor.
        """
        return self.__class__(
            X=pd.concat([self.X, other.X], axis=0),
            y=pd.concat([self.y, other.y], axis=0),
            lookback=self.lookback,
            lookahead=self.lookahead,
            start_index_of_targets=self.start_index_of_targets
        )

    def __eq__(self, other):
        c1 = (self.dataset.equals(other.dataset))
        c2 = (self.input_features.sort() == other.input_features.sort())
        c3 = (self.target_features.sort() == other.target_features.sort())
        c4 = (self.lookback == other.lookback)
        c5 = (self.lookahead == other.lookahead)
        return c1 and c2 and c3 and c4 and c5