from abc import ABC
from typing import List

from hdml.Utils.Config import BaseConfig


class FeatureConfig(BaseConfig, ABC):
    def __init__(
            self,
            input_features: List[str],
            target_features: List[str],
            *args, **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._input_features = input_features
        self._target_features = target_features

    @property
    def input_features(self) -> List[str]:
        return self._input_features

    @property
    def target_features(self) -> List[str]:
        return self._target_features

    @property
    def all_features(self) -> List[str]:
        features = list(set(self._input_features + self._target_features))
        return features
