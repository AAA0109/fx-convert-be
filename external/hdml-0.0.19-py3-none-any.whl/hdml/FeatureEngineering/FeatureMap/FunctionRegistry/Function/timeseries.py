from typing import List

import numpy as np
import pandas as pd

from hdml.FeatureEngineering.FeatureMap.function_registry import FunctionRegistry

time_series_registry = FunctionRegistry()


@time_series_registry.register("add")
def add_numbers(a: pd.Series, b: pd.Series) -> pd.Series:
    """
    Add two series together element-wise.

    :param a: First series to add.
    :param b: Second series to add.
    :return: New series resulting from the element-wise addition of a and b.
    """
    return a + b


@time_series_registry.register("sub")
def sub_numbers(a: pd.Series, b: pd.Series) -> pd.Series:
    """
    Subtract one series from another element-wise.

    :param a: Series from which to subtract.
    :param b: Series to subtract.
    :return: New series resulting from the element-wise subtraction of b from a.
    """
    return a - b


@time_series_registry.register("log-return")
def log_return(a: pd.Series, order: int = 1) -> pd.Series:
    """
    Compute the logarithmic return of a series based on a given order/lag.

    :param a: Time series data.
    :param order: Lag or order to compute the return. Default is 1.
    :return: Series representing the log return of the data.
    """
    return np.log(a / a.shift(order))


@time_series_registry.register("diff-log-return")
def diff_log_return(a: pd.Series, b: pd.Series, order: int = 1) -> pd.Series:
    """
    Compute the difference between the logarithmic returns of two series.

    :param a: First time series data.
    :param b: Second time series data.
    :param order: Lag or order to compute the return. Default is 1.
    :return: Series representing the difference between log returns of a and b.
    """
    return np.log(a / a.shift(order)) - np.log(b / b.shift(order))


def get_timeseries_function_choices() -> List[str]:
    return [x[0] for x in time_series_registry.choices]


if __name__ == '__main__':
    TIMESERIES_FUNCTION_CHOICES = get_timeseries_function_choices()

    docs = time_series_registry.get_function_docs("add")
    print(docs)
