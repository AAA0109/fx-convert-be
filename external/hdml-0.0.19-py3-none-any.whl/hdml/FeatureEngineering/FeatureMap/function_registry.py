from typing import Any, Callable, Dict, Tuple, get_type_hints, Union
import inspect

class FunctionRegistry:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._registry = {}
        return cls._instance

    def __init__(self) -> None:
        self.functions: Dict[str, Callable[..., Any]] = {}

    def register(self, name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            self.functions[name] = func
            return func

        return decorator

    def call(self, name: str, *args: Tuple[Any, ...], **kwargs: Dict[str, Any]) -> Any:
        if name in self.functions:
            return self.functions[name](*args, **kwargs)
        else:
            raise ValueError(f"No function named '{name}' in registry")

    def get_function_docs(self, name: str) -> Dict[str, Union[str, Dict[str, str]]]:
        """Get documentation about the arguments, types, and the function's docstring from the registry."""
        func = self.functions.get(name)
        if not func:
            raise ValueError(f"No function named '{name}' in registry")

        # Extract argument type hints
        type_hints = get_type_hints(func)

        # Extract docstring
        docstring = inspect.getdoc(func)

        docs = {"docstring": docstring if docstring else "No docstring provided."}
        docs[""] = ""
        docs["Type of each parameters"]=""
        for arg, arg_type in type_hints.items():
            if arg == 'return':
                docs['returns'] = str(arg_type)
            else:
                docs[arg] = str(arg_type)

        return docs

    @property
    def choices(self):
        return [(name, name) for name in self.functions.keys()]
