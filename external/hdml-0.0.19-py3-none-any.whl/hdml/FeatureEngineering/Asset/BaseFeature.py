import numpy as np
import pandas as pd

from hdml.Utils.utils import clean_data


class Series(pd.Series):
    #todo promote this to the higher class
    def __init__(self, data=None, index=None, dtype=None, name=None, copy=False, fastpath=False):
        """
        Initialize the custom Series class.
        """
        super().__init__(data, index, dtype, name, copy, fastpath)

    @property
    def _constructor(self):
        """
        Return the constructor for the custom Series class.
        """
        return Series

    @property
    def series(self) -> 'Series':
        """
        Clean the data in the series and return a new instance of the Series class.
        """
        ts = clean_data(self)
        ts = pd.Series(ts, name="output")
        return self.__class__(ts)

    def log_return(self, order: int = 1) -> 'Series':
        """
        Calculate the log difference of the series and return a new instance of the Series class.

        :param order: The number of periods to shift for forming the difference. Default is 1.
        :return: A Series object containing the log difference values.
        """
        ts = np.log(self / self.shift(order))
        return self.__class__(ts)

    def trend(self, threshold: float = 0.0) -> 'Series':
        """
        Calculate the trend of the series based on a threshold and return a new instance of the Series class.

        :param threshold: The threshold to determine the trend. Default is 0.0.
        :return: A Series object containing the trend values (1 for positive trend, 0 for negative trend).
        """
        ts = self.apply(lambda x: 1 if x > threshold else 0)
        return self.__class__(ts)

    def moving_std(self, window: int) -> 'Series':
        """
        Calculate the moving standard deviation of the series and return a new instance of the Series class.

        :param window: The size of the moving window.
        :return: A Series object containing the moving standard deviation values.
        """
        ts = self.rolling(window).std()
        return self.__class__(ts)

    def moving_average(self, window: int) -> 'Series':
        """
        Calculate the moving average of the series and return a new instance of the Series class.

        :param window: The size of the moving window.
        :return: A Series object containing the moving average values.
        """
        ts = self.rolling(window).mean()
        return self.__class__(ts)
