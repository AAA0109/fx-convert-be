from typing import Optional

import pandas as pd
from hdlib.DateTime.DayCounter import DayCounter_HD

from hdml.FeatureEngineering.Asset.BaseFeature import Series


class EWMA_Squared_Rate_Log_Return:
    def __init__(
            self,
            rate: pd.Series,
            lam: Optional[float] = 0.99,
    ):
        """
        Initialize EWMA.
        :param rate: rate
        :param lam: lambda of ewma. Default is 0.99.
            e.g. 0.99 means 99% of the previous value and 1% of the current value
        """
        self._lam = lam
        self._dc = DayCounter_HD()
        self._df = rate.to_frame()
        self._df.columns = ["rate"]
        self._df["date"] = self._df.index
        self._df["last_date"] = self._df["date"].shift(1)
        self._run()

    def _run(self):
        self._df["sqrt_log_return"] = (Series(self._df["rate"]).log_return() ** 2)
        self._df["annualized_factor"] = self._df.apply(
            lambda x: self._dc.year_fraction(start=x["last_date"], end=x["date"]),
            axis=1)
        self._df["annualized_sqrt_log_return"] = self._df["sqrt_log_return"] / self._df["annualized_factor"]

        self._df[f"EWMA-{self._lam}"] = self._df["annualized_sqrt_log_return"].ewm(alpha=1 - self._lam,
                                                                                   adjust=False).mean()

    def ewma(self) -> pd.Series:
        return self._df[f"EWMA-{self._lam}"]
