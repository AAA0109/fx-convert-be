from typing import List

from hdml.FeatureEngineering.FeatureConfig import FeatureConfig


class AssetFeatureConfig(FeatureConfig):

    def get_features(self) -> List[str]:
        return [f.split("#")[0] for f in self.all_features]

    def get_assets(self) -> List[str]:
        return list(set([f.split("#")[1] for f in self.all_features]))

    def get_target_asset(self) -> List[str]:
        return list(set([f.split("#")[1] for f in self.target_features]))
