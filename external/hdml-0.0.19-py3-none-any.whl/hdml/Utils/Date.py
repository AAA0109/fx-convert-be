import re
from datetime import datetime
from typing import Union

import pandas as pd
from hdlib.DateTime.Date import Date


def date2str(date: Union[Date, datetime, str]) -> str:
    """
    convert date obj into str
    :param date: Date, datetime, str
    :return: str date
    """
    if isinstance(date, str):
        return date
    else:
        if isinstance(date, datetime):
            date = Date.to_date(date)
        return date.to_str("%Y-%m-%d")


def str2date(date: Union[Date, datetime, str], fmt='%Y-%m-%d') -> Date:
    """
    convert str to Date
    :param date: str
    :return: Date
    """
    if isinstance(date, Date):
        return date
    elif isinstance(date, datetime):
        return Date.to_date(date)
    else:
        return Date.from_str(date, fmt)


units = {"D": 1, "W": 7, "M": 30, "Y": 365}
regex = re.compile(r"(\d*?)([DWMY])", re.IGNORECASE)


def convert_duration_to_days(dts):
    """
    convert duration string to days. it supports  D, W, M, Y. and this is case insensitive
    e.g. "1D", "2W", "3M", "4Y"
    :param dts: e.g. "1D", "2W", "3M", "4Y"
    :return: days in integer e.g. 1, 14, 90, 1460
    """
    if isinstance(dts, str):
        dts = regex.findall(dts)
        return sum(float(n or "1") * units[unit.upper()] for n, unit in dts)
    else:
        """in case of nan -> it will convert it to 0"""
        return 0


def convert_minutes_to_weekday_time(minutes: int) -> tuple:
    """Converts the number of minutes since the start of the week back to a day of the week, hour, and minute."""
    minutes_per_day = 24 * 60
    dow = minutes // minutes_per_day
    remaining_minutes = minutes % minutes_per_day
    hour = remaining_minutes // 60
    minute = remaining_minutes % 60
    return dow, hour, minute


def convert_datetime_to_week_minutes(dt: pd.Timestamp) -> int:
    """Converts a datetime object to the number of minutes since the start of the week."""
    minutes_per_day = 24 * 60
    return dt.dayofweek * minutes_per_day + dt.hour * 60 + dt.minute


def is_market_open(minutes: int) -> bool:
    """
    Determines if the market is open based on the provided minutes.

    Parameters:
    - minutes (int): The total number of minutes from a reference point, e.g., start of the week.

    Returns:
    - bool: True if the market is open, False otherwise.

    Notes:
    - The market is open:
      * Monday to Thursday: All day.
      * Friday: Until 22:00.
      * Saturday: Closed.
      * Sunday: From 22:00 onwards.
    """
    dow, hour, _ = convert_minutes_to_weekday_time(minutes)

    # The market is closed on Saturdays
    if dow == 6:
        return False
    # The market is closed on Sundays until 22:00
    elif dow == 7:
        return hour >= 22
    # The market is closed on Fridays after 22:00
    elif dow == 5:
        return hour < 22
    # The market is open from Monday to Thursday
    else:
        return True


def get_regime(hour: int) -> int:
    REGIMES = [
        (list(range(1, 7)), 1),
        (list(range(7, 16)), 2),
        (list(range(16, 21)), 3),
        ([0] + list(range(21, 24)), 4)
    ]
    regime = None
    for range_list, regime_id in REGIMES:
        if hour in range_list:
            regime = regime_id
            break
    return regime


def is_run_optex(hour: int, pair: str) -> Union[bool, int]:
    """
    Determine if a strategic execution should be allowed based on the regime and currency pair.

    :param hour: The hour to check.
    :param pair: The currency pair.
    :return: A tuple of (should_allow_strategic_execution, regime).
    """
    regime = get_regime(hour)

    if regime not in [1, 2, 3, 4]:
        raise ValueError(f"Regime {regime} not supported")

    is_jpy_pair = "JPY" in pair.upper()
    should_allow = (regime in [1, 4]) or (regime == 2 and not is_jpy_pair)

    return should_allow, regime
