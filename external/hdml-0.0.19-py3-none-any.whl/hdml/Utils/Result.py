from typing import Any

import pandas as pd


class FitResult:
    """
    this is a container class to store the information from the model fitting process.
    """
    stopping_criteria: Any  # to answer what is the optimum or maximum criteria
    early_stop: Any
    learning_curve: pd.DataFrame
    fit_instance: Any

    def __init__(self, learning_curve: pd.DataFrame = None, model_result: object = None):
        self.learning_curve = learning_curve
        self.model_result = model_result
        self.stopping_criteria = None
        self.early_stop = None

    def to_dict(self):
        return {k: v for k, v in vars(self).items() if isinstance(v, (int, float, str))}