import pandas as pd

def get_nearest_index(index: pd.Index, idx):
    indexer = index.get_indexer([idx], method='ffill')
    if indexer[0] == -1:
        return index[0]
    return index[indexer][0]
