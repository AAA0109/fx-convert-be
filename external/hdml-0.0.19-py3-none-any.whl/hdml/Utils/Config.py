import copy
import json
from abc import ABC
from pathlib import Path
from typing import Dict, Any

import yaml


class BaseConfig(ABC):
    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs

    @staticmethod
    def yaml_to_dict(path: Path):
        with open(path, "r") as file:
            config_yaml = yaml.safe_load(file)
        return config_yaml

    @classmethod
    def from_yaml(cls, path: Path):
        with open(path, "r") as file:
            config_yaml = yaml.safe_load(file)
        return cls(**config_yaml)

    @classmethod
    def from_dict(cls, config_dict: dict):
        return cls(**config_dict)

    def to_json(self) -> str:
        return json.dumps(self.__dict__)

    def to_dict(self) -> Dict[str, Any]:
        config = copy.deepcopy(vars(self))
        return config

    def get_attrs(self, *args) -> dict:
        dict_ = {}
        for key in args:
            dict_[key] = self.get_attr(key)
        return dict_

    def get_attr(self, key) -> Any:
        return getattr(self, key)

    def set_attr(self, **kwargs):
        """
        this method is useful if you want to pop some kwargs before
        define it as an instance variable.
        :param kwargs: dictionary, the attributes to set
        """
        for key, val in kwargs.items():
            try:
                setattr(self, key, val)
            except:
                print(key, "error")

    @staticmethod
    def remove_attrs_from_dict(dict_: dict, list_: list) -> dict:
        for key in list_:
            del dict_[key]
        return dict_
