import logging
import warnings
from abc import ABC, abstractmethod
from typing import List, Union

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy import argmax
from numpy import sqrt
from sklearn.metrics import f1_score, precision_score
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import roc_curve

warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)


class ThresholdOptimizer(ABC):
    _best_threshold: float

    @abstractmethod
    def calculate(self,
                  y_true: Union[List[float], pd.Series, np.ndarray],
                  y_score: Union[List[float], pd.Series, np.ndarray],
                  *args, **kwargs
                  ):
        raise NotImplemented

    @property
    def best_threshold(self):
        return self._best_threshold


class RocOptimizer(ThresholdOptimizer):
    fpr: np.ndarray
    tpr: np.ndarray
    thresholds: np.ndarray
    gmeans: np.ndarray
    ix: int

    def calculate(
            self,
            y_true: Union[List[float], pd.Series, np.ndarray],
            y_score: Union[List[float], pd.Series, np.ndarray],
            *args, **kwargs
    ):
        """
        :param y_true:ndarray of shape (n_samples,)
        True binary labels. If labels are not either {-1, 1} or {0, 1}, then
        pos_label should be explicitly given.
        :param y_score:ndarray of shape (n_samples,)
        Target scores, can either be probability estimates of the positive
        class, confidence values, or non-thresholded measure of decisions
        (as returned by "decision_function" on some classifiers).

        fpr: np.ndarray. false positive rate
        tpr: np.ndarray. true positive rate
        thresholds: np.ndarray. various thresholds
        gmeans:np.ndarray
        ix:int. index corresponding with the highest gmeans
        """
        self.y_true, self.y_score = y_true, y_score
        # calculate roc curves
        self.fpr, self.tpr, self.thresholds = roc_curve(y_true, y_score, *args, **kwargs)
        # calculate the g-mean for each threshold
        self.gmeans = sqrt(self.tpr * (1 - self.fpr))
        # locate the index of the largest g-mean
        self.ix = argmax(self.gmeans)
        logger.info('Best Threshold=%f, G-Mean=%.3f' % (self.thresholds[self.ix], self.gmeans[self.ix]))
        self._best_threshold = round(self.thresholds[self.ix], 4)

    def plot(self) -> plt:
        # plot the roc curve for the model
        plt.plot([0, 1], [0, 1], linestyle='--', label='No Skill')
        plt.plot(self.fpr, self.tpr, marker='.', label='Logistic')
        plt.scatter(self.fpr[self.ix], self.tpr[self.ix], marker='o', color='black', label='Best')
        # axis labels
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title(
            f"ROC Curve. Best Threshold: {round(self.thresholds[self.ix], 4)}, G-Mean: {round(self.gmeans[self.ix], 4)}")
        plt.legend()
        return plt


class PrCurveOptimizer(ThresholdOptimizer):
    precision: np.ndarray
    recall: np.ndarray
    thresholds: np.ndarray
    fscore: np.ndarray
    ix: int

    def calculate(
            self,
            y_true: Union[List[float], pd.Series, np.ndarray],
            y_score: Union[List[float], pd.Series, np.ndarray],
            *args, **kwargs
    ):
        """
        :param y_true:
        :param y_score:
        :param args:
        :param kwargs:
        :return:
        """
        self.y_true, self.y_score = y_true, y_score
        # calculate pr-curve
        self.precision, self.recall, self.thresholds = precision_recall_curve(y_true, y_score)
        # convert to f score
        self.fscore = (2 * self.precision * self.recall) / (self.precision + self.recall)
        # locate the index of the largest f score
        self.ix = argmax(self.fscore)
        logger.info('Best Threshold=%f, F-Score=%.3f' % (self.thresholds[self.ix], self.fscore[self.ix]))
        self._best_threshold = self.thresholds[self.ix]

    def plot(self):
        # plot the pr-curve for the model
        no_skill = len(self.y_true[self.y_true] == 1) / len(self.y_true)
        plt.plot([0, 1], [no_skill, no_skill], linestyle='--', label='No Skill')
        plt.plot(self.recall, self.precision, marker='.', label='Forecaster')
        plt.scatter(self.recall[self.ix], self.precision[self.ix], marker='o', color='black', label='Best')
        # axis labels
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title(
            f"pr-curve. Best Threshold: {round(self.thresholds[self.ix], 4)}, F-Score: {round(self.fscore[self.ix], 4)}")
        plt.legend()


class BruteForceOptimizer(ThresholdOptimizer):
    f1scores: np.ndarray
    precisionscores: np.ndarray
    thresholds: np.ndarray
    ix_f_score: int
    ix_precision_score: int

    def calculate(
            self,
            y_true: Union[List[float], pd.Series, np.ndarray],
            y_score: Union[List[float], pd.Series, np.ndarray],
            *args, **kwargs
    ):
        self.thresholds = np.arange(0, 1, 0.01)
        # evaluate each threshold
        f1scores = [f1_score(y_true, self._to_labels(y_score, t)) for t in self.thresholds]
        # get best threshold according to F-Score
        ix_f_score = argmax(f1scores)
        logger.info('Best Threshold=%.3f, F-Score=%.5f' % (self.thresholds[ix_f_score], f1scores[ix_f_score]))

        # get best threshold according to precision
        precisionscores = [precision_score(y_true, self._to_labels(y_score, t), average='weighted')
                           for t
                           in self.thresholds]
        # get best threshold
        ix_precision_score = argmax(precisionscores)
        logger.info(
            'Best Threshold=%.3f, Precision=%.5f' % (
                self.thresholds[ix_precision_score], precisionscores[ix_precision_score]))
        self._best_threshold = self.thresholds[ix_precision_score]

    def plot(self):
        pass

    @staticmethod
    def _to_labels(pos_probs, threshold):
        return (pos_probs >= threshold).astype('int')
