import importlib
import os
import shutil
from pathlib import Path
from typing import Dict, Any, Optional

import yaml
from hdlib.AppUtils.log_util import get_logger, logging

logger = get_logger(level=logging.INFO)

try:
    import cPickle as pickle
except ModuleNotFoundError:
    import pickle


class FileSystem(object):
    _path: Path

    def __init__(self, path: Path):
        self._path = path.resolve()
        os.makedirs(self.dir_path, exist_ok=True)
    def __str__(self):
        return str(self._path)

    @property
    def path(self) -> Path:
        return self._path

    @property
    def dir_path(self):
        return self._path.parent

    @property
    def name(self) -> str:
        return self._path.name

    @property
    def suffix(self) -> str:
        return self._path.suffix

    @property
    def stem(self) -> str:
        return self._path.stem

    def move(self):
        """
        thgns related to file system
        """
        pass

    def list(self):
        pass

    def delete_dir_path(self):
        # allowed_scope = Path.cwd().resolve()
        ## Ensure the directory being deleted is within the allowed scope
        # if str(self.dir_path.resolve()).startswith(str(allowed_scope)):
        #     shutil.rmtree(self.dir_path)
        #     logger.info(f"Deleted directory: {self.dir_path}")
        # else:
        #     raise ValueError('Directory is outside of allowed scope')

        if "checkpoint" in str(self.dir_path):
            shutil.rmtree(self.dir_path)
            logger.info(f"Deleted directory: {self.dir_path}")


class ObjectStorage(FileSystem):
    def save(self, obj: Any, stored_file_type: str = "bytes"):
        if stored_file_type == "pickle":
            self.save_object(obj)
        elif stored_file_type == "bytes":
            if not isinstance(obj, bytes):
                obj = pickle.dumps(obj=obj, protocol=pickle.HIGHEST_PROTOCOL)
            self.save_bytes(obj)
        else:
            raise ValueError("stored_file_type must be either 'pickle' or 'bytes'")

    def load(self, stored_file_type: str = "bytes"):
        if stored_file_type == "pickle":
            return self.load_object()
        elif stored_file_type == "bytes":
            obj_bytes = self.load_bytes()
            return pickle.loads(obj_bytes)
        else:
            raise ValueError("stored_file_type must be either 'pickle' or 'bytes'")

    def save_bytes(self, obj: bytes):
        """save data in any file extension/format"""
        with open(self.path, "wb") as binary_file:
            binary_file.write(obj)

    def save_object(self, obj):
        with open(self.path, 'wb') as outp:  # Overwrites any existing file.
            pickle.dump(obj, outp, pickle.HIGHEST_PROTOCOL)

    def load_bytes(self) -> bytes:
        """load data in any file extension/format"""
        with open(self.path, "rb") as binary_file:
            serializer = binary_file.read()
        return serializer

    def load_object(self):
        with open(self.path, 'rb') as inp:
            obj = pickle.load(inp)
        return obj


def extract_yaml_config(path: Path) -> Dict[str, Any]:
    with open(path, "r") as file:
        config_yaml = yaml.safe_load(file)
    return config_yaml


def load_model_from_script(path: Optional[Path] = None, **kwargs) -> Any:
    path = str(path)
    if path is None or kwargs.get("shape") is None:
        return None
    relpath = os.path.relpath(path)
    ts_class = getattr(importlib.import_module(relpath.replace("../", "").replace("/", ".").replace(".py", "")),
                       "TsClass")
    model = ts_class().get_model(kwargs.get("shape"))
    return model
