import itertools
from collections import OrderedDict
from typing import Optional, List, Union

import numpy as np
import pandas as pd


def get_cross_procuct_from_lists(delimiter: str = '-', **kwargs: object) -> List[str]:
    """
    generate permutation among list passed.
    e.g.
    get_cross_procuct_from_lists(l1=['a','b','c',],l2=['d','e','f'])
    output: ['a-d', 'a-e', 'a-f', 'b-d', 'b-e', 'b-f', 'c-d', 'c-e', 'c-f']
    """
    list_ = []
    for idx, (key, vals) in enumerate(OrderedDict(kwargs).items()):
        if idx == 0:
            list_ = vals.copy()
        else:
            temp = []
            for r in itertools.product(list_, vals):
                temp.append(f"{r[0]}{delimiter}{r[1]}")
            list_ = temp
    return list_



def convert_nan_to_none(df: pd.DataFrame) -> pd.DataFrame:
    return df.where(pd.notnull(df), None)


def convert_none_to_nan(df: pd.DataFrame) -> pd.DataFrame:
    return df.where(pd.notnull(df), np.nan)


def convert_nat_to_none(df: pd.DataFrame) -> pd.DataFrame:
    return df.replace({pd.NaT: None})


def clean_data(data_in: Union[pd.Series, pd.DataFrame]) -> Union[pd.Series, pd.DataFrame]:
    """
    sort index and remove duplicated index
    :param data_in: input series
    :return:
    """
    data = data_in.copy(deep=True)
    data.where(pd.notnull(data), np.nan)
    data = data.replace([np.inf, -np.inf], np.nan)
    data.sort_index(inplace=True)
    data = data[~data.index.duplicated(keep='last')]
    return data

def clean_after_extraction(series: pd.Series)-> pd.Series:
    """
    fill nan with forward and then backward fill
    :param series:
    :return:
    """
    series_output = series.copy(deep=True)
    series_output = series_output.replace([np.inf, -np.inf], np.nan)
    series = series_output.fillna(method="ffill").fillna(method='bfill')
    return series
