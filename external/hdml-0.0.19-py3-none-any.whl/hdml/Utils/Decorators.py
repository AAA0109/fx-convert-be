import datetime
import time
from functools import wraps
from typing import Callable


def timer(logger):
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            duration = str(datetime.timedelta(seconds=end_time - start_time))
            logger.info(f"{func.__name__} took {duration} seconds to execute")
            return result

        return wrapper

    return decorator


def requires_columns(required_columns):
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(df, *args, **kwargs):
            if all(column in df.columns for column in required_columns):
                return func(df, *args, **kwargs)
            else:
                raise ValueError(f"DataFrame is missing one or more required columns: {', '.join(required_columns)}")

        return wrapper

    return decorator
