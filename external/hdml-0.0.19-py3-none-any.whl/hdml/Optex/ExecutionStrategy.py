from abc import abstractmethod
import logging

import pandas as pd

from hdlib.DateTime.Date import Date

logger = logging.getLogger(__name__)


class WaitCondition:
    def __init__(self,
                 wait_time: float = None,
                 spread_start: float = None,
                 spread_wait: float = None,
                 base_value: float = None,
                 upper_limit_in_deltas: int = None,
                 lower_limit_in_deltas: int = None,
                 regime: int = None,
                 ):
        self.wait_time = wait_time
        self.spread_start = spread_start
        self.spread_wait = spread_wait
        self.base_value = base_value
        self.upper_limit_in_deltas = upper_limit_in_deltas
        self.lower_limit_in_deltas = lower_limit_in_deltas
        self.regime = regime

    @property
    def expected_saving(self):
        """
            Expected savings is half the difference in spreads between executing now, and waiting. Half b/c on only
            pay half the spread for a buy or a sell (relative to mid price)
        """
        return (self.spread_start - self.spread_wait) / 2

    @property
    def expected_saving_percentage(self):
        return self.expected_saving / self.base_value

    @property
    def delta(self):
        return self.expected_saving

    @property
    def upper_bound(self):
        return self.base_value + self.upper_limit_in_deltas * self.delta

    @property
    def lower_bound(self):
        return self.base_value - self.lower_limit_in_deltas * self.delta


class ExecutionStrategy:
    """
    An abstract class representing the base for execution strategies.
    """

    @abstractmethod
    def name(self) -> str:
        """
        Returns the name of the execution strategy.
        """
        raise NotImplementedError

    @abstractmethod
    def wait_time_hours(self, start_time: Date, end_time: Date) -> float:
        """
        Calculate the wait time in hours for executing a strategy.
        """
        raise NotImplementedError

    def fit_strategy(self, df: pd.DataFrame, *args, **kwargs):
        logger.info("No fit required for this strategy")

    def wait_condition(self, *args, **kwargs) -> WaitCondition:
        return WaitCondition()
