import logging
from abc import abstractmethod

import pandas as pd

logger = logging.getLogger(__name__)


class SpreadGrid(object):
    """
    A class that generates a spread grid.
    """
    MINUTES_PER_DAY = 24 * 60
    MINUTES_PER_WEEK = MINUTES_PER_DAY * 7
    TIME_CHUNKS = 15

    @abstractmethod
    def generate(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError
