import logging
from typing import Dict

import numpy as np
import pandas as pd

from hdml.Optex.SpreadGrid.Base import SpreadGrid
from hdml.Utils.Date import convert_datetime_to_week_minutes

logger = logging.getLogger(__name__)


class PeriodicSpreadGrid(SpreadGrid):
    """
    A class that generates a spread grid.
    """
    MINUTES_PER_DAY = 24 * 60

    def __init__(self, aggregation_methods: Dict[str, str] = None, time_chunks: int = 15, n_week_extend: int = 3):
        """
        :param aggregation_methods: Function to use for aggregating the data. Follow pandas .agg() syntax.
        :param time_chunks: The time interval of the data.
        :param n_week_extend: The number of weeks to extend the data to.
        """
        self.aggregation_methods = aggregation_methods
        self.time_chunks = time_chunks
        self.n_week_extend = n_week_extend

    def generate(self, df: pd.DataFrame):
        """
        Generate the spread grid.
        Note: spread_grid could contain NaN. NaN handling will be up to the caller.
        :param df:
        :return:
        """
        df = self._prepare_data(df)
        df_average = self._aggregate_data(df)
        spread_grid = self._extend_and_fill_data(df_average)
        return spread_grid

    # =========Private methods=========
    def _prepare_data(self, df_in: pd.DataFrame) -> pd.DataFrame:
        """Prepare the data for analysis by enriching and transforming the raw historical data."""
        df = df_in.copy()
        if 'date' not in df.columns:
            df.index.name = 'date'
            df.reset_index(inplace=True)

        df['day_of_week'] = df['date'].dt.dayofweek
        df['hour'] = df['date'].dt.hour
        df['minute'] = df['date'].dt.minute
        # the assumption is that for the same day, same hour, same minute, the rate/spread is the same
        df['time_snapshot'] = df['date'].apply(convert_datetime_to_week_minutes)

        # Add volatility, specific to the date range supplied
        df["vol"] = df['rate'].pct_change().std()
        return df

    def _aggregate_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Aggregate the prepared data to get average rate and spread for each time snapshot."""
        df_sorted = df.sort_values(by=['time_snapshot', 'date'])
        return df_sorted.groupby('time_snapshot').agg(self.aggregation_methods)

    def _extend_and_fill_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Extend and fill the DataFrame to ensure it covers the entire time range of interest.
        We assume that the pattern always periodic, so we extend the data by n_week_extend times
        """
        df_reindexed = df.reindex(pd.RangeIndex(start=0, stop=self.MINUTES_PER_DAY * 7, step=self.time_chunks))
        wma = self._filter_ts(df_reindexed["spread"])  # TODO: convolution isnt wrapping properly in some cases, results in nan
        df_reindexed.loc[:, 'spread'] = wma
        extended_data = pd.concat([df_reindexed.reset_index()] * self.n_week_extend).reset_index(drop=True)
        extended_data.index = pd.RangeIndex(start=0, stop=len(extended_data) * self.time_chunks, step=self.time_chunks)
        return extended_data

    @staticmethod
    def _filter_ts(ts: pd.Series) -> np.ndarray:
        # Define the weights
        weights = np.array([1 / 5, 3 / 5, 1 / 5])
        padded_rate = np.pad(ts.values, (1, 1), mode='wrap')
        return np.convolve(padded_rate, weights[::-1], mode='valid')
