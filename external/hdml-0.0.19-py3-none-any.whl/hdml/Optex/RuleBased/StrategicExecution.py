import logging
from datetime import timedelta
from random import randint
from typing import Dict, Optional, Tuple, Union

import matplotlib.pyplot as plt
import pandas as pd
from hdlib.DateTime.Date import Date

from hdml.Optex.ExecutionStrategy import ExecutionStrategy, WaitCondition
from hdml.Optex.SpreadGrid.Periodic import PeriodicSpreadGrid
from hdml.Utils.Date import convert_datetime_to_week_minutes, convert_minutes_to_weekday_time, is_market_open, \
    is_run_optex
from hdml.Utils.dataframe import get_nearest_index

logger = logging.getLogger(__name__)

START_RATE = "start_rate"
START_SPREAD = "start_spread"

OBJ_RATE = "objective_rate"
OBJ_SPREAD = "objective_spread"
OBJ_TIME = "objective_time"

OPT_RATE = "optimal_rate"
OPT_SPREAD = "optimal_spread"
OPT_TIME = "optimal_time"

ALL_STRAT_STATS = (START_RATE, START_SPREAD, OBJ_RATE, OBJ_SPREAD, OPT_RATE, OPT_SPREAD, OBJ_TIME, OPT_TIME)

class WaitExactly(ExecutionStrategy):
    """
    An execution strategy that waits for an exact amount of time.
    """

    def __init__(self, wait_hours: float = 0.):
        self._wait_hours = wait_hours

    def wait_time_hours(self, start_time: Date, end_time: Date) -> float:
        return self._wait_hours

    def name(self) -> str:
        return 'WaitExactly'


class ExecuteNow(WaitExactly):
    """
    An execution strategy that recommends executing immediately.
    """

    def __init__(self):
        super().__init__(wait_hours=0)

    def name(self) -> str:
        return 'ExecuteNow'


class WaitRandomTime(ExecutionStrategy):
    """
    An execution strategy that waits for a random amount of time within the bounds.
    """

    def wait_time_hours(self, start_time: Date, end_time: Date) -> float:
        total_minutes = int(pd.Timedelta(end_time - start_time).total_seconds() / 60.0)

        # Calculate the number of 15-minute intervals within total_minutes
        total_intervals = total_minutes // 15

        if total_intervals == 0:
            return 0  # Return 0 if there's no 15-minute interval available

        # Get a random number of 15-minute intervals
        random_intervals = randint(0, total_intervals)

        # Convert the random number of 15-minute intervals back to hours
        random_hours = random_intervals * 15 / 60.0
        return random_hours

    def name(self) -> str:
        return 'WaitRandomTime'


class StrategicExecution(ExecutionStrategy):
    """
    An execution strategy that determines the optimal time to execute an order
    """

    def __init__(self, config: dict):
        self._aggregation_methods = config.get("aggregation_methods")
        if self._aggregation_methods is None:
            raise ValueError("aggregation_methods is required")

        self._interval = config.get("interval", 15)  # Time interval in minutes between data observations
        self._pair: str = config.get("pair")
        self._gamma = config.get("gamma", 1)  # Controls volatility penalty
        self._lambda = config.get("lambda", 1)  # Controls max spread penalty in objective 2

        self._upper_limit_in_deltas = config.get("upper_limit_in_deltas", 3)
        self._lower_limit_in_deltas = config.get("lower_limit_in_deltas", 3)
        self._type_objective = config.get("type_objective", 1)

        self._plot_fig = config.get("plot_fig", False)
        self._regime_mode = config.get("regime_mode", False)

        self._spread_grid = pd.DataFrame()

    def name(self) -> str:
        return f'Strategic-Ex'

    def _ensure_is_fit(self):
        if self._spread_grid.empty:
            raise RuntimeError("you never fit this strategy")

    def wait_time_hours(self, start_time: Date, end_time: Date) -> float:
        """
        Calculate the wait time in hours for executing a strategy.
        """
        self._ensure_is_fit()

        start_dt, end_dt = self._convert_to_datetime(start_time, end_time)
        start_minutes, end_minutes = self._calculate_time_range_in_minutes(start_dt, end_dt)
        _, wait_time, _, _, _ = self._optimal_strategy(self._spread_grid, start_minutes, end_minutes)
        return wait_time / 60

    def fit_strategy(self, df: pd.DataFrame, *args, **kwargs):
        logger.info("Fitting strategic execution")
        if df.empty:
            raise RuntimeError("The dataframe to train on is empty")
        self._spread_grid = PeriodicSpreadGrid(self._aggregation_methods).generate(df)
        logger.info("----- Done Fitting strategic execution")

    def wait_condition(
            self,
            start_time: Date,
            end_time: Date,
            base_value: float = None,
            instantaneous_spread: float = None,
    ) -> WaitCondition:
        self._ensure_is_fit()

        start_dt, end_dt = self._convert_to_datetime(start_time, end_time)
        start_minutes, end_minutes = self._calculate_time_range_in_minutes(start_dt, end_dt)

        if start_time.day_of_week() == 7:
            logger.info("Running on a sunday")

        idx_min, wait_time, spread_start, spread_wait, df_active_hours = self._optimal_strategy(
            self._spread_grid, start_minutes, end_minutes
        )

        if self._regime_mode:
            allow_run_optex, regime = is_run_optex(convert_minutes_to_weekday_time(start_minutes)[1], self._pair)

            if not allow_run_optex:
                idx_min, wait_time, spread_start, spread_wait = self._execute_immediately(df_active_hours, spread_start)

        if instantaneous_spread:
            # use at the moment spread instead of the average spread
            spread_start: float = instantaneous_spread

        if self._plot_fig:
            self._plot(
                df=df_active_hours[['objective', 'spread']],
                start_minutes=start_minutes,
                end_minutes=end_minutes,
                idx_min=idx_min
            )

        return WaitCondition(
            wait_time=wait_time / 60,
            spread_start=spread_start,
            spread_wait=spread_wait,
            base_value=base_value,
            upper_limit_in_deltas=self._upper_limit_in_deltas,
            lower_limit_in_deltas=self._lower_limit_in_deltas,
            regime=regime,

        )

    # =========Private methods=========

    @staticmethod
    def _execute_immediately(df_active_hours: pd.DataFrame, spread_start: float) -> Tuple[int, float, float, float]:
        """
        Overrides the optimal strategy and executes immediately.
        :param df_active_hours: dataframe with active hours
        :param spread_start: spread at start time
        :return: idx_min, wait_time, spread_start, spread_wait
        """
        return df_active_hours.index[0], 0.0, spread_start, spread_start

    def _convert_to_datetime(self, start_time: Union[Date, str], end_time: Union[Date, str]) -> tuple:
        """Converts start_time and end_time to datetime objects and returns them as a tuple."""
        start_dt = pd.to_datetime(Date.to_date(start_time))
        end_dt = pd.to_datetime(Date.to_date(end_time))
        assert end_dt > start_dt, "end_time should be greater than start_time"
        return start_dt, end_dt

    def _calculate_time_range_in_minutes(self, start_dt: pd.Timestamp, end_dt: pd.Timestamp) -> Tuple[int, int]:
        """Calculates the time range in minutes between start_dt and end_dt."""
        duration_in_minutes = (end_dt - start_dt).total_seconds() / 60
        start_minutes = convert_datetime_to_week_minutes(start_dt)
        end_minutes = int(start_minutes + duration_in_minutes)
        return start_minutes, end_minutes

    def _optimal_strategy(self,
                          spread_grid: pd.DataFrame,
                          start_minutes: int,
                          end_minutes: int) -> Tuple[int, float, float, float, pd.DataFrame]:
        """
        Calculates the optimal strategy for the given time range.
        """
        df = spread_grid.loc[start_minutes:end_minutes].copy()
        uniform_increment = all(pd.Series(df.index).diff().dropna() == self._interval)
        if not uniform_increment:
            raise ValueError(f"The data is not in {self._interval} minute increments")

        df['t'] = range(0, len(df))
        df["vol*t"] = df["vol"] * df["t"]

        # scale = df["vol*t"].max() / df["spread"].max()
        # df["vol*t"] = df["vol*t"] / scale

        if self._type_objective == 1:
            df = self._objective1(df)
        elif self._type_objective == 2:
            df = self._objective2(df)
        else:
            raise ValueError(f"Objective type {self._type_objective} not supported")

        df["dow"] = df["index"].map(lambda x: convert_minutes_to_weekday_time(x))
        df['market_open'] = df["index"].map(is_market_open)
        df_active_hours = df.loc[df['market_open']]

        # handle nan by dropping them
        # TODO: fix wraparound bug with the convolve function... setting spreads to nan
        df_active_hours = df_active_hours.dropna()

        idx_min = df_active_hours['objective'].idxmin()

        wait_time: float = float(idx_min - start_minutes)
        spread_start: float = df_active_hours['spread'].iloc[0]
        spread_wait: float = df_active_hours['spread'].loc[idx_min]

        if wait_time / 60 >= 10:
            logger.warning(f"Unusually large wait time recommended: {wait_time / 60} hours")

        return idx_min, wait_time, spread_start, spread_wait, df_active_hours

    def _objective1(self, df: pd.DataFrame):
        df.loc[:, "objective"] = df["spread"] + self._gamma * df["vol*t"]
        return df

    def _objective2(self, df: pd.DataFrame):
        # Compute the average of spreads between [0, t]
        expanding_avg = df['spread'].expanding().mean()

        # Subtract spread(0) from the expanding average
        # positive means you will at some point between time 0 and t cross over a period where the spreads are larger
        diff_from_initial = expanding_avg - df['spread'].iloc[0]

        # Compute the expanding maximum of the above difference between [0, t]
        expanding_max_diff = diff_from_initial.expanding().max()

        # Take the maximum of 0 and the expanding_max_diff
        df['G(t)'] = expanding_max_diff.clip(lower=0)
        df.loc[:, "objective"] = df["spread"] + self._gamma * df["vol*t"] + self._lambda * df['G(t)']
        return df

    @staticmethod
    def _plot(df: pd.DataFrame, start_minutes: int, end_minutes: int, idx_min: int):
        df_plot = df.copy()
        # convert minutes to hours
        divider = 60
        df_plot.index = df_plot.index.map(lambda x: x / divider)

        # Plotting rates
        df_plot.plot(marker='o')

        # Plotting vertical line at wait_time and adding text
        start_x = start_minutes / divider
        end_x = end_minutes / divider
        optimal_x = idx_min / divider
        plt.axvline(x=start_x, color='r', linestyle=':', label='Start Time')
        plt.axvline(x=end_x, color='g', linestyle=':', label='End Time')
        plt.axvline(x=optimal_x, color='b', linestyle=':', label='Optimal Time')

        y_min, y_max = plt.ylim()
        y_position = y_min + 0.01 * (y_max - y_min)

        plt.text(start_x, y_position, f'{start_x:.2f} hour', horizontalalignment='center', color='r', fontsize=9,
                 verticalalignment='bottom')
        plt.text(end_x, y_position, f'{end_x:.2f} hour', horizontalalignment='center', color='g', fontsize=9,
                 verticalalignment='bottom')
        plt.text(optimal_x, y_position, f'{optimal_x:.2f} hour', horizontalalignment='center', color='b', fontsize=9,
                 verticalalignment='bottom')

        # Displaying legend and grid
        plt.legend()
        plt.grid(True)
        plt.title("Objective with Start and End Time")
        plt.xlabel("Index (Hours)")
        plt.ylabel("Value")

        plt.tight_layout()
        plt.show()


class StrategicExecutionWithLimits(ExecutionStrategy):
    def __init__(self,
                 rates: pd.Series,
                 strategic_ex: ExecutionStrategy,
                 spread: pd.Series = None,
                 plot_fig: bool = False,
                 ):
        self._strategic_ex = strategic_ex
        self._rates = rates
        self._spread = spread
        self._std_dev_hourly: Optional[float] = None
        self._plot_fig = plot_fig
        self.statistics = {}

    def name(self) -> str:
        return f'Strategic-Ex-Limits'

    def wait_time_hours(self, start_time: Date, end_time: Date) -> float:
        # First ask optimially how long would we wait
        rate_start = self._rates.loc[get_nearest_index(self._rates.index, start_time)]
        spread_start = self._spread.loc[get_nearest_index(self._spread.index, start_time)]
        wc = self._strategic_ex.wait_condition(start_time=start_time,
                                               end_time=end_time,
                                               base_value=rate_start,
                                               )

        objective_time = start_time + timedelta(hours=wc.wait_time)
        execution_time, rate = None, None
        for execution_time, rate in self._rates.to_frame().loc[start_time:objective_time].iterrows():
            if wc.lower_bound < rate.values[0] < wc.upper_bound:
                continue
            else:
                break

        self._store_statistics(rate_start, spread_start, objective_time, execution_time, rate)
        if self._plot_fig:
            self._plot(
                rates=self._rates.loc[start_time:end_time],
                execution_time=execution_time,
                start_time=start_time,
                wait_time=objective_time,
                upper_bound=wc.upper_bound,
                lower_bound=wc.lower_bound,
            )

        wait_time = execution_time - start_time
        time_in_minutes = wait_time.days * 1440 + wait_time.seconds / 60
        time_in_hours = time_in_minutes / 60
        return time_in_hours

    def fit_strategy(self, df: pd.DataFrame, **kwargs):
        self._strategic_ex.fit_strategy(df=df)

    # =========Private methods=========
    def _store_statistics(self,
                          rate_start,
                          spread_start,
                          objective_time,
                          execution_time,
                          rate
                          ):
        self.statistics[START_RATE] = rate_start
        self.statistics[START_SPREAD] = spread_start

        objective_rate = self._rates.loc[get_nearest_index(self._rates.index, objective_time)]
        objective_spread = self._spread.loc[get_nearest_index(self._spread.index, objective_time)]
        self.statistics[OBJ_RATE] = objective_rate
        self.statistics[OBJ_SPREAD] = objective_spread

        optimal_spread = self._spread.loc[get_nearest_index(self._spread.index, execution_time)]
        self.statistics[OPT_RATE] = rate.values[0]
        self.statistics[OPT_SPREAD] = optimal_spread

        self.statistics[OBJ_TIME] = pd.Timestamp(objective_time)
        self.statistics[OPT_TIME] = execution_time

    @staticmethod
    def _plot(
            rates: pd.Series,
            execution_time: Date,
            start_time: Date,
            wait_time: Date,
            upper_bound: float,
            lower_bound: float
    ):
        # Plotting rates
        rates.plot(label='Rates', color='blue', marker='o')

        # Plotting upper and lower bounds
        plt.axhline(y=upper_bound, color='r', linestyle='--', label='Upper Bound')
        plt.axhline(y=lower_bound, color='g', linestyle='--', label='Lower Bound')

        plt.axvline(x=wait_time, color='purple', linestyle=':', label='Wait Time')
        plt.axvline(x=start_time, color='orange', linestyle=':', label='Start Time')
        plt.axvline(x=execution_time, color='cyan', linestyle=':', label='Execution Time')

        y_min, y_max = plt.ylim()
        y_position = y_min + 0.01 * (y_max - y_min)  # Position the text slightly above the x-axis

        plt.text(wait_time, y_position, str(wait_time), horizontalalignment='center', color='purple', fontsize=9,
                 rotation=45, verticalalignment='bottom')
        plt.text(start_time, y_position, str(start_time), horizontalalignment='center', color='b', fontsize=9,
                 rotation=45, verticalalignment='bottom')
        plt.text(execution_time, y_position, str(execution_time), horizontalalignment='center', color='cyan',
                 fontsize=9, rotation=45, verticalalignment='bottom')

        # Displaying legend and grid
        plt.legend()
        plt.grid(True)
        plt.title("Rates with Upper and Lower Bounds")
        plt.xlabel("Date")
        plt.ylabel("Value")

        plt.tight_layout()
        plt.show()


class StrategicExecution_Cached(ExecutionStrategy):
    """
    An execution strategy that retrieves the optimal execution time from
    a cache of trained execution strategies.
    """

    def __init__(self, strats: Dict[Date, ExecutionStrategy], name: str):

        self._strats: Dict[Date, ExecutionStrategy] = strats
        self._dates = list(strats.keys())
        self._current_index = 0
        self._name = name

        self.statistics = {stat: [] for stat in ALL_STRAT_STATS}

    def name(self) -> str:
        return f'{self._name}'

    def wait_time_hours(self, start_time: Date, end_time: Date) -> float:
        strat, date = self._get_strategy(start_time=start_time, end_time=end_time)
        wait_time_hours = strat.wait_time_hours(start_time=start_time, end_time=end_time)
        if getattr(strat, "statistics", None):
            self._store_statistics(strat)
        return wait_time_hours

    # =========Private methods=========
    def _get_strategy(self, start_time: Date, end_time: Date) -> Tuple[ExecutionStrategy, Date]:
        if self._current_index < len(self._dates) - 1:
            while start_time >= self._dates[self._current_index]:
                if self._dates[self._current_index + 1] > start_time:
                    break
                self._current_index += 1
                if self._current_index == len(self._dates) - 1:
                    break

        model_date = self._dates[self._current_index]
        if model_date > end_time:
            raise RuntimeError("You went too far, shouldnt have happened")

        if model_date < start_time - 14:
            logger.warning(f"Your model is old - was trained up to date {model_date}, but used for date: {start_time}")

        return self._strats[model_date], model_date

    def _store_statistics(self, strat):
        for stat in ALL_STRAT_STATS:
            self.statistics[stat].append(strat.statistics[stat])
