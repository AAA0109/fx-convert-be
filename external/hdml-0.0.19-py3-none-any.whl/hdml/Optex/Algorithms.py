from hdml.Optex.ExecutionStrategy import ExecutionStrategy



class OptexAlgorithm(object):

    @staticmethod
    def get(config: dict) -> ExecutionStrategy:
        if config.get("name") == "strategic_execution":
            from hdml.Optex.RuleBased.StrategicExecution import StrategicExecution
            return StrategicExecution(config)
        else:
            raise ValueError("Model not found")
