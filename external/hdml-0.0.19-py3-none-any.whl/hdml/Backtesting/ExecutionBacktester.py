import logging
from typing import Tuple, Optional

import numpy as np
import pandas as pd
from hdlib.DateTime.Date import Date

from hdml.Optex.ExecutionStrategy import ExecutionStrategy

logger = logging.getLogger(__name__)

BUY_AVG = 'buy_avg'
BUY_AVG_SAVED = 'buy_avg_saved'
BUY_MIN_SAVED = 'buy_min_saved'
BUY_WAIT_STD = 'buy_wait_std'

SELL_AVG = 'sell_avg'
SELL_AVG_GAINED = 'sell_avg_gained'
SELL_MIN_GAINED = 'sell_min_gained'
SELL_WAIT_STD = 'sell_wait_std'

AVG_SAVED = 'avg_saved'

SREAD_AVG = 'spread_avg'
SPREAD_MAX = 'spread_max'

WAIT_AVG = 'wait_avg'
WAIT_MIN = 'wait_min'
WAIT_MAX = 'wait_max'

ALL_BT_STATS = [AVG_SAVED, BUY_AVG, BUY_AVG_SAVED, BUY_MIN_SAVED, BUY_WAIT_STD,
                SELL_AVG, SELL_AVG_GAINED, SELL_MIN_GAINED, SELL_WAIT_STD,
                SREAD_AVG, SPREAD_MAX,
                WAIT_AVG, WAIT_MIN, WAIT_MAX]

# All average based stats (for easy group_by)
AVG_BT_STATS = [AVG_SAVED, SREAD_AVG, BUY_AVG, BUY_AVG_SAVED, SELL_AVG,
                SELL_AVG_GAINED, WAIT_AVG, BUY_WAIT_STD, SELL_WAIT_STD]

# All maximum based stats (for easy group_by)
MIN_BT_STATS = [BUY_MIN_SAVED, SELL_MIN_GAINED, WAIT_MIN]

# All minimum based stats (for easy group_by)
MAX_BT_STATS = [SPREAD_MAX, WAIT_MAX]

DESIRED_WAITS = 'desired_waits'


class StrategicBacktester:
    def __init__(self,
                 df: pd.DataFrame,
                 strategy: ExecutionStrategy,
                 max_wait_hours: float = 22):
        self._strategy = strategy
        self._df = df
        self._max_wait_hours = max_wait_hours

        self._desired_times = []
        self._desired_waits = []
        self._ex_times = []
        self._buy_saved = []
        self._sell_gained = []
        self._buy_prices = []
        self._sell_prices = []
        self._spreads = []

        self.statistics: Optional[pd.DataFrame] = None

    def run_backtest_execution(self,
                               start_date: Date,
                               end_date: Date) -> Tuple[pd.DataFrame, pd.Series]:
        logging.info(f"Loading data from {start_date} to {end_date}")
        df = self._df.loc[start_date:end_date]
        logging.info(f"----- Done Loading data, size = {len(df)}")

        logging.info("Starting backtest")
        d = start_date
        while True:
            self._run_date(date=d, df=df)
            d += 1  # Add a day
            if d > end_date:
                break

        logging.info("----- Done backtest")

        if getattr(self._strategy, "statistics", None):
            self.statistics = pd.DataFrame(self._strategy.statistics)

        out = pd.DataFrame(columns=['desired_time', 'desired_wait', 'ex_time', 'buy_price', 'sell_price', 'spread'],
                           data=np.c_[self._desired_times,
                                      self._desired_waits,
                                      self._ex_times,
                                      self._buy_prices,
                                      self._sell_prices,
                                      self._spreads])

        sell_wait_losses = np.array([gained for gained in self._sell_gained if gained < 0])
        buy_wait_losses = np.array([gained for gained in self._buy_saved if gained < 0])

        try:
            buy_saved = np.mean(self._buy_saved)
            sell_gained = np.mean(self._sell_gained)
            avg_saved = (buy_saved + sell_gained) / 2

            stats = pd.Series(
                {AVG_SAVED: avg_saved,
                 BUY_AVG: buy_saved,
                 BUY_AVG_SAVED: np.mean(self._buy_saved),
                 BUY_MIN_SAVED: np.min(self._buy_saved),
                 BUY_WAIT_STD: np.std(sell_wait_losses) if len(sell_wait_losses) > 0 else None,
                 SELL_AVG: np.mean(self._sell_prices),
                 SELL_AVG_GAINED: sell_gained,
                 SELL_MIN_GAINED: np.min(self._sell_gained),
                 SELL_WAIT_STD: np.std(buy_wait_losses) if len(buy_wait_losses) > 0 else None,
                 SREAD_AVG: np.mean(self._spreads),
                 SPREAD_MAX: np.max(self._spreads),
                 WAIT_AVG: np.mean(self._desired_waits),
                 WAIT_MIN: np.min(self._desired_waits),
                 WAIT_MAX: np.max(self._desired_waits),
                 DESIRED_WAITS: self._desired_waits,
                 }
            )
        except Exception as e:
            logger.exception(f"Error computing stats: {e}")
            stats = None
        """
        avg_saved:       Average savings (averaged over buy savings and sell gains)
        buy_avg:         Average price paid to buy
        buy_avg_saved:   Average amount saved when buying (vs buying immediately)
        buy_min_saved:   Worst amount saved when buying (vs buying immediately)
        buy_wait_std:    Standard dev. of savings due to waiting to buy
        sell_avg:        Average price recieved when selling
        sell_avg_gained: Average extra amount earned when selling (vs selling immediately)
        sell_min_gained: Worst extra amount earned when selling (vs selling immediately)
        sell_wait_std:   Standard dev. of savings due to waiting to sell
        spread_avg:      Average spread paid
        spread_max:      Max spread paid
        wait_avg:        Average hours we waited to exectue
        wait_min:        Min. hours we waited to exectue
        wait_max:        Max. we waited to exectue
        """
        return out, stats

    def _run_date(self,
                  df: pd.DataFrame,
                  date: Date):
        if date.day_of_week() in (6, 7):
            # Skip sundays / Saturdays
            return
        row = df[df.index == date]
        if row.empty:
            # Date doesnt have data
            return

        max_time = date.copy()
        max_time += pd.Timedelta(hours=self._max_wait_hours)

        wait_time = self._strategy.wait_time_hours(start_time=date, end_time=max_time)

        ex_time = date.copy()
        ex_time += pd.Timedelta(hours=wait_time)

        try:
            row_ex = df[(df.index >= ex_time) & (df.index <= max_time)].iloc[0]
        except Exception:
            # In this case you went too far, so chose the last possible time you can execute
            row_ex = df[(df.index >= date) & (df.index <= max_time)].iloc[-1]

        if row_ex.empty:
            logger.warning("You waited too long to execute, this shouldnt happen")
            raise RuntimeError

        # Record the price
        self._desired_times.append(ex_time)
        self._desired_waits.append(wait_time)
        self._ex_times.append(row_ex.name)
        self._buy_prices.append(row_ex['rate_ask'])
        self._buy_saved.append(float(row['rate_ask']) - float(row_ex['rate_ask']))  # Positive is good
        self._sell_prices.append(row_ex['rate_bid'])
        self._sell_gained.append(float(row_ex['rate_bid']) - float(row['rate_bid']))  # Positive is good
        self._spreads.append(row_ex['spread'])

        logger.info(f"Done running date: {date}")
