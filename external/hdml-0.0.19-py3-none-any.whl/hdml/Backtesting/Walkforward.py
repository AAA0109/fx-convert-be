import copy
from abc import ABC, abstractmethod
from typing import Dict, Any, Iterable, List, Tuple
import pandas as pd
from math import floor

from hdlib.DateTime.Date import Date


class WalkforwardInterval(object):
    def __init__(self,
                 index: int,
                 train_start: Date,
                 train_end: Date,
                 test_start: Date,
                 test_end: Date
                 ):
        """
        A single walkforward interval, as part of a sequence of walkforward intervals

        train_start <= train_end < test_start <= test_end

        :param index: int, the index in which this interval belongs to the full sequence of walkforward intervals
        :param train_start: Date, the first training date
        :param train_end: Date, the last training date
        :param test_start: Date, the first testing date (must be after validation)
        :param test_end: Date, the last testing date
        """

        assert (train_end > train_start) & (test_end > test_start) & (test_start >= train_end)

        self.index = index
        self.train_start = train_start
        self.train_end = train_end
        self.test_start = test_start
        self.test_end = test_end

    def __repr__(self) -> str:
        df = pd.DataFrame({
            "index": [self.index],
            "train_start": [self.train_start],
            "train_end": [self.train_end],
            "test_start": [self.test_start],
            "test_end": [self.test_end]
        }).T
        df.columns = ["value"]
        return f"{df}"

    @property
    def name(self) -> str:
        return f"{self.test_end.to_str().replace('-', '_')}"

    def update_by_stride(self, stride: int, expanding: bool = False):
        """
        update train_start,train_end, validate_start, validate_end,test_start, test_end by stride
        :param stride: number of days
        :param expanding: expanding means the 'train_start' will not adjust based on stride
        :return: None
        """
        if not expanding:
            self.train_start += stride

        self.train_end += stride

        self.test_start += stride
        self.test_end += stride

        self.index += 1

    def to_dict(self) -> Dict[str, Any]:
        dict_ = copy.deepcopy(vars(self))
        return dict_

    def train_test_split_from_df(self,
                                 df: pd.DataFrame,
                                 input_features: List[str],
                                 target_features: List[str]
                                 ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Split a time series table structure into training and test date
        :param df: pd.DataFrame, with rows indexed by date, and columns contain both
            the features and the labels
        :param input_features: List[str], the labels for the input features
        :param target_features: List[str], the labels for the targets to predict
        :return: Tuple of data frames
        """
        X_train = df.loc[self.train_start:self.train_end, input_features]
        X_test = df.loc[self.test_start:self.test_end, input_features]

        y_train = df.loc[self.train_start:self.train_end, target_features]
        y_test = df.loc[self.test_start:self.test_end, target_features]

        return X_train, X_test, y_train, y_test


class WalkforwardIntervalGenerator(ABC):
    """
    A walkforward interval generator, generates a sequence of WalkforwardInterval
    """

    @abstractmethod
    def yield_intervals(self) -> Iterable[WalkforwardInterval]:
        """
        Generate the full iterable of walk forward intervals
        :return: Iterable[WalkforwardInterval]
        """
        raise NotImplementedError


class StridedWalkforwardIntervalGenerator(WalkforwardIntervalGenerator):
    def __init__(self,
                 start_date: Date,
                 end_date: Date,
                 length_walkforward_interval: int,
                 train_size_proportion: float,
                 stride: int,
                 expanding: bool = False,
                 embargo_period: int = 0,
                 **kwargs
                 ):
        """
        :param start_date: start date of walkforward
        :param end_date: end date of walkforward
        :param length_walkforward_interval: total length ( in days ) of one walkforward interval
        :param train_size_proportion: proportion of train size compared to length_walkforward_interval
        :param stride: number of days the window move forward, stride = int(length_walkforward_interval * (1-train_size_proportion)) by BacktestConfig
        :param expanding: if true, training data will expand overtime and no data to be thrown away
        :param embargo_period: space length between train and test dataset
        :param kwargs:
        """

        assert length_walkforward_interval < (end_date - start_date).days
        assert end_date > start_date
        assert embargo_period >= 0, "Embargo period must be a non-negative value"

        self.expanding = expanding

        # Initialize the interval
        self.start_date = start_date
        self.end_date = end_date
        self.train_size_proportion = train_size_proportion
        self.length_walkforward_interval = length_walkforward_interval
        self.stride = stride
        self.embargo_period = embargo_period

        # For removing gap between last backtest_and_the_first_day_prediction
        # index of interval is start from 0, so don't need +1
        self.final_interval_index = floor(((end_date - start_date).days - length_walkforward_interval) / stride)

        number_of_train_days = int(length_walkforward_interval * train_size_proportion)

        train_start = self.start_date
        train_end = self.start_date + number_of_train_days - embargo_period
        # test_start should not start by the last embargo_period day, so +1
        test_start = train_end + 1
        test_end = self.start_date + length_walkforward_interval

        self.initial_interval = WalkforwardInterval(
            index=0,
            train_start=train_start,
            train_end=train_end,
            test_start=test_start,
            test_end=test_end)


    def yield_intervals(self) -> Iterable[WalkforwardInterval]:
        # Yiled the current interval
        yield copy.deepcopy(self.initial_interval)

        last_interval = copy.deepcopy(self.initial_interval)

        while True:
            future_time = last_interval.test_end + self.stride
            if future_time >= self.end_date:
                break
            last_interval.update_by_stride(stride=self.stride, expanding=self.expanding)

            # If this is the final interval, adjust the test end date to include the remainder
            if ((last_interval.index == self.final_interval_index) \
                and (last_interval.test_end < self.end_date)):
                last_interval.test_end = self.end_date

            yield copy.deepcopy(last_interval)
