import uuid
from pathlib import Path
from typing import Optional, List, Tuple, Dict

import pandas as pd

from hdml.Backtesting.Walkforward import StridedWalkforwardIntervalGenerator
from hdml.DataProcessing.BacktestConfig import StridedWalkforwardConfig
from hdml.Models.Factory.Model import ModelFactory, BaseModelFactory
from hdml.Models.Forecaster import Forecaster
from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Tuning.Factory import TunnerFactory
from hdml.Tuning.HyperTuner import TunedResult
from hdml.Utils.FileSystem import FileSystem
from hdml.Utils.Result import FitResult


class BacktestContainer(object):
    def __init__(self,
                 model: Forecaster,
                 fit_result: FitResult,
                 X_test: pd.DataFrame,
                 y_test: pd.DataFrame,
                 y_pred: pd.DataFrame,
                 identifier: Dict[str, str],
                 tunner_result: Optional[TunedResult] = None,
                 ):
        self.model = model
        self.fit_result = fit_result
        self.X_test = X_test
        self.y_test = y_test
        self.y_pred = y_pred
        self.identifier = identifier
        self.tunner_result = tunner_result


class WalkforwardBacktester(object):
    def __init__(self,
                 input_features: List[str],
                 target_features: List[str],
                 walkforward_config: StridedWalkforwardConfig,
                 model_factory: Optional[BaseModelFactory] = None,
                 model_config: Optional[ForecasterConfig] = None,
                 checkpoint_dir: Optional[Path] = None,
                 ):
        """
        Perform walkforward backtesting
        :param input_features: list of input features
        :param target_features: list of target features
        :param walkforward_config: walkforward config
        :param model_config: model config
        :param checkpoint_dir: checkpoint directory
        """
        self._input_features = input_features
        self._target_features = target_features
        self._model_config = model_config
        self._checkpoint_dir = checkpoint_dir
        self._walkforward_config = walkforward_config
        self._model_factory = model_factory or ModelFactory(model_config)

        # TODO: why does it tune each interval???? maybe do it every so many days (introduce a hyper tune schedule)

    def run_backtest(self, df: pd.DataFrame) -> List[BacktestContainer]:
        if not all(col in df.columns for col in list(set(self._input_features + self._target_features))):
            raise ValueError("Not all columns exist in the DataFrame")
        # define walkforward interval generator
        if self._walkforward_config.embargo_period_active:
            self._walkforward_config.embargo_period = self._model_config.output_chunk_length
        self._walkforward_config.stride = int(
            self._walkforward_config.length_walkforward_interval * (
                    1 - self._walkforward_config.train_size_proportion)) - (self._model_config.input_chunk_length +
                                                                            self._model_config.output_chunk_length)
        walkforward_interval_generator = StridedWalkforwardIntervalGenerator(**self._walkforward_config.to_dict())
        backtest_containers = []

        # generate walkforward intervals for backtesting
        for interval in walkforward_interval_generator.yield_intervals():
            # split data into training and testing data
            # todo padding df with nan gap on X_test?
            X_train, X_test, y_train, y_test = interval.train_test_split_from_df(
                df=df,
                input_features=self._input_features,
                target_features=self._target_features,
            )

            # compute the predictions by running the backest over the interval
            y_pred, model, fit_result, tunner_result = self._run_backtest_interval(X_train, y_train, X_test)

            backtest_containers.append(
                BacktestContainer(
                    model=model,
                    fit_result=fit_result,
                    X_test=X_test,
                    y_test=y_test,
                    y_pred=y_pred,
                    identifier={
                        "model_name": self._model_config.model_name if self._model_config else 'Model',
                        "interval_name": interval.name,
                        "train_start": interval.train_start,
                        "train_end": interval.train_end,
                        "test_start": interval.test_start,
                        "test_end": interval.test_end,
                    },
                    tunner_result=tunner_result,
                )
            )
        return backtest_containers

    # ======================
    # Private
    # ======================

    def _run_backtest_interval(
            self,
            X_fit: pd.DataFrame,
            y_fit: pd.DataFrame,
            X_test: pd.DataFrame,
    ) -> Tuple[pd.DataFrame, Forecaster, FitResult, Optional[TunedResult]]:
        # set checkpoint directory and reset ai

        # TODO: cleanup this file system crap
        if self._checkpoint_dir and self._model_config:
            fs = FileSystem(path=self._checkpoint_dir / "checkpoint" / f"{uuid.uuid4()}" / "ai_checkpoint.pkl")
            self._model_config.work_dir = fs.dir_path

        model = self._model_factory.model()

        tunner_result = None

        # TODO: refactor the tuner factory similarly to ModelFactory, it should be constructed with config
        if self._model_config and self._model_config.tunner_on:
            hyper_tuner = TunnerFactory(model_config=self._model_config).tunner()
            tunner_result = hyper_tuner.set_model(model=model).tune(X_fit, y_fit)
            model = ModelFactory(tunner_result.optimal_config).model()

        # fit ai using X_fit, y_fit
        fit_result = model.fit(X_fit, y_fit)

        # remove checkpoint
        if self._checkpoint_dir:
            fs.delete_dir_path()

        # forecast ai
        y_pred = model.predict(X_test)
        return y_pred, model, fit_result, tunner_result
