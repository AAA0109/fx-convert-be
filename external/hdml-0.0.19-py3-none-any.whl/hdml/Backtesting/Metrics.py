import copy
from typing import Union, Dict, Any, List

import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, \
    f1_score, mean_absolute_error, r2_score,mean_absolute_percentage_error


class Performance:
    value: List[Union[int, float]]
    metric: List[str]
    """
    container for performance value metric.
    Example:
        >>> periods = ("2020-01-01", "2020-02-01", "2020-03-01")
        >>> fxpairs = ("USD/CAD", "USD/AUD", "USD/MXN", "USD/GBP")
        >>> metric_names = ("mae", "f1", "recall", "precision", "accuracy")
        >>> values = (0.5, 0.5, 0.5, 0.5, 0.5)

        >>> p = Perfomance()
        >>> for period in periods:
                for fxpair in fxpairs:
                    for value, metric_name in zip(values,metric_names):
                        p.push(value=value, metric=metric_name, fxpair=fxpair, period=period)
            p.to_dict()
        >>> df_performance = p.to_dataframe()
    Out: 
    Out[1]: 
            id  value     metric   fxpair      period
        0    1    0.5        mae  USD/CAD  2020-01-01
        1    2    0.5         f1  USD/CAD  2020-01-01
        2    3    0.5     recall  USD/CAD  2020-01-01
        3    4    0.5  precision  USD/CAD  2020-01-01
        4    5    0.5   accuracy  USD/CAD  2020-01-01
        5    6    0.5        mae  USD/AUD  2020-01-01
        6    7    0.5         f1  USD/AUD  2020-01-01
        7    8    0.5     recall  USD/AUD  2020-01-01
        8    9    0.5  precision  USD/AUD  2020-01-01
        .    .    .      ...         ...     ...       
    """

    def __init__(self):
        self.id = []
        self.value = []
        self.metric = []

    def push(self, value: Union[float, int] = None, metric: str = None, **kwargs):
        """
        insert value, metric name + other fields you have inserted
        """
        self.id.append(len(self.value) + 1)
        self.value.append(value)
        self.metric.append(metric)

        for key in kwargs.keys():
            if not hasattr(self, key):
                setattr(self, key, [])

        for key, val in kwargs.items():
            getattr(self, key).append(val)

    def to_dict(self) -> Dict[str, Any]:
        dict_ = copy.deepcopy(vars(self))
        return dict_

    def to_dataframe(self):
        return pd.DataFrame(self.to_dict()).dropna()


def calculate_metric(
        performance: Performance,
        y_true: pd.DataFrame,
        y_pred: pd.DataFrame,
        metrics: dict,
        identifier: dict,
):
    """
    :param performance: Performance instance
    :param y_true: ground truth value
    :param y_pred: prediction value
    :param metrics: is a dict that contains keys: metric names and values: sklearn.metric function
    :param identifier: identifier columns in the performance table
    :return:
    """
    # we do align because the len(forecasts) < len(y_test) this is due to lookback window
    # length of y_true will adjust to the length of y_pred
    df_align = pd.merge(y_true, y_pred, left_index=True, right_index=True, how='right')
    for metric_name, fnc in metrics.items():
        performance.push(
            value=fnc(y_true=df_align.iloc[:, 0], y_pred=df_align.iloc[:, 1]),
            metric=metric_name,
            **identifier
        )


def get_which_metrics(task: str) -> dict:
    if task == 'R':
        return {
            "mean_absolute_error": mean_absolute_error,
            # "mean_absolute_percentage_error":mean_absolute_percentage_error,
            # "r2_score": r2_score,
        }

    if task == 'C':
        return {"accuracy_score": accuracy_score,
                "precision_score": precision_score,
                "recall_score": recall_score,
                "f1_score": f1_score}

    raise ValueError(f"task {task} is undefined!")
