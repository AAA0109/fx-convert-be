import logging
import os
from pathlib import Path

import pandas as pd
import tensorflow as tf
from hdlib.DateTime.Date import Date

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Models.TensorFlow.BaseModel import TfForecaster
from hdml.Models.TensorFlow.Blueprints.Regression import tf_model_one_shot_regression

logger = logging.getLogger(__name__)


class TfRegressionOneShotConfig(ForecasterConfig):
    def __init__(
            self,
            model_name: str = "tf_regression",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            batch_size: int = None,
            epochs: int = 2,
            verbose: int = 1,
            validation_size: float = 0.3,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            input_chunk_length = input_chunk_length,
            output_chunk_length = output_chunk_length,
            task=task,
            *args, **kwargs
        )
        self.batch_size = batch_size
        self.epochs = epochs
        self.verbose = verbose
        self.validation_size = validation_size

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class TfRegressionOneShot(TfForecaster):
    model: tf.keras.Model
    model_config: TfRegressionOneShotConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame):
        # Split the data into train and validation sets.
        X_train, X_val, y_train, y_val = self._train_validate_split(X_fit, y_fit, self.model_config.validation_size)

        self.scaler_x = self._fit_scaler(X_train)
        self.scaler_y = self._fit_scaler(y_train)

        scaled_X_train = self._scale_data(X_train, self.scaler_x)
        scaled_X_val = self._scale_data(X_val, self.scaler_x)
        scaled_y_train = self._scale_data(y_train, self.scaler_y)
        scaled_y_val = self._scale_data(y_val, self.scaler_y)

        ts_train = TimeSeriesTensor(X=scaled_X_train, y=scaled_y_train, lookback=self.model_config.lookback,
                                    lookahead=self.model_config.lookahead)
        ts_val = TimeSeriesTensor(X=scaled_X_val, y=scaled_y_val, lookback=self.model_config.lookback,
                                  lookahead=self.model_config.lookahead)

        self.model = tf_model_one_shot_regression(
            (self.model_config.input_chunk_length, len(ts_train.input_features)))

        self.model.compile(
            optimizer="adam",
            loss="mean_squared_error",
            metrics=["mean_absolute_error"],
        )

        checkpoint_filepath = self.model_config.work_dir / 'model.hdf5'

        model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
            filepath=checkpoint_filepath,
            save_weights_only=False,
            monitor='val_loss',
            mode='min',
            verbose=self.model_config.verbose,
            save_best_only=True)

        fit_results = self.model.fit(
            ts_train.X3D,
            ts_train.Y3D,
            batch_size=self.model_config.batch_size,
            epochs=self.model_config.epochs,
            callbacks=[model_checkpoint_callback],
            validation_data=(ts_val.X3D, ts_val.Y3D),
            verbose=0,
        )

        self.model = tf.keras.models.load_model(self.model_config.work_dir / 'model.hdf5')

        return self._store_training_state(fit_results)

    # =============PRIVATE METHODS================