from tensorflow import keras
import tensorflow

def tf_model_one_shot_regression(shape):
    input_TS = keras.Input(shape=shape)
    input_ts = keras.layers.Conv1D(filters=10, kernel_size=3, padding='same', activation='relu')(input_TS)
    input_ts = keras.layers.Bidirectional(keras.layers.LSTM(32, return_sequences=True))(input_ts)
    input_ts = keras.layers.Bidirectional(keras.layers.LSTM(32))(input_ts)
    out = keras.layers.Dense(64, activation='relu')(input_ts)
    out = keras.layers.Dense(1)(out)
    return keras.Model(inputs=input_TS, outputs=out)


def tf_model_regression(shape):
    num_features, out_steps=shape
    multi_lstm_model = tensorflow.keras.Sequential([
        #    tensorflow.keras.Input(shape=inputShape, name="input"),
        # Shape [batch, time, features] => [batch, lstm_units]
        # Adding more `lstm_units` just overfits more quickly.
        tensorflow.keras.layers.LSTM(32, return_sequences=True),
        # tensorflow.keras.layers.LSTM(512, return_sequences=True),
        tensorflow.keras.layers.LSTM(16, return_sequences=False),
        # Shape => [batch, out_steps*features]
        #    tensorflow.keras.layers.Dense(self.out_steps*self.num_features),

        tensorflow.keras.layers.Dense(out_steps * num_features,
                              kernel_initializer=tensorflow.initializers.zeros),
        # Shape => [batch, out_steps, features]
        tensorflow.keras.layers.Reshape([out_steps, num_features])
    ])
    return multi_lstm_model
