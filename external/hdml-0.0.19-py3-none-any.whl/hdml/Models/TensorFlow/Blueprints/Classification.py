"""
put your keras model here
"""
from tensorflow import keras

def tf_model_classification(shape):
    reg_const = 0.001
    input_TS = keras.Input(shape=shape)
    input_ts = keras.layers.LSTM(32, kernel_regularizer=keras.regularizers.L2(reg_const),
                                 recurrent_regularizer=keras.regularizers.L2(reg_const),
                                 bias_regularizer=keras.regularizers.L2(reg_const))(input_TS)
    out = keras.layers.Dense(64, activation='relu', kernel_regularizer=keras.regularizers.L2(reg_const),
                             bias_regularizer=keras.regularizers.L2(reg_const))(input_ts)
    out = keras.layers.Dense(1, activation='sigmoid')(out)
    model = keras.Model(inputs=input_TS, outputs=out)

    return model