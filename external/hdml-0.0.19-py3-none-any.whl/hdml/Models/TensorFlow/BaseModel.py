import logging
from abc import ABC
from typing import Tuple, Optional

import pandas as pd
from sklearn.preprocessing import StandardScaler

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Forecaster import Forecaster
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class TfForecaster(Forecaster, ABC):
    scaler_x: Optional[StandardScaler]
    scaler_y: Optional[StandardScaler]

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        try:
            scaled_X_test = self._scale_data(X_test, self.scaler_x)
            ts_train = TimeSeriesTensor(X=scaled_X_test, lookback=self.model_config.lookback,
                                        lookahead=self.model_config.lookahead)
            forecasts = self._predict_data(ts_train)
            forecasts = pd.DataFrame(forecasts, index=X_test.index)
            forecasts.index.name = "reference_date"
        except:
            raise RuntimeError("forecast fails!")
        return forecasts

    # ========Private methods================
    def _fit_scaler(
            self,
            data: pd.DataFrame,
    ) -> StandardScaler:
        scaler = StandardScaler()
        scaler.fit(data)
        return scaler

    def _scale_data(self, data: pd.DataFrame, scaler: StandardScaler) -> pd.DataFrame:
        if scaler is None:
            return data
        else:
            return pd.DataFrame(scaler.transform(data), index=data.index, columns=data.columns)

    def _inverse_transform_data(self, data: pd.DataFrame, scaler: StandardScaler) -> pd.DataFrame:
        if scaler is None:
            return data
        else:
            return pd.DataFrame(scaler.inverse_transform(data), index=data.index, columns=data.columns)

    def _predict_data(self, data: TimeSeriesTensor) -> pd.DataFrame:
        """
        predict data
        :param data:
        :return:
        """
        forecasts = self.model.predict(data.X3D, verbose=0)
        forecasts = pd.DataFrame(forecasts, index=data.index)
        forecasts.columns = ["forecast"]
        return forecasts

    def _train_validate_split(
            self,
            X_fit: pd.DataFrame,
            y_fit: pd.DataFrame,
            validation_size: float,
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        split data into training and validation
        :param X_fit:
        :param y_fit:
        :param validation_size:
        :return:
        """
        assert len(X_fit) == len(y_fit)

        data_length = len(X_fit)
        validation_samples = round(validation_size * data_length)
        training_samples = data_length - validation_samples

        X_train = X_fit.iloc[:training_samples]
        X_val = X_fit.iloc[training_samples:]

        y_train = y_fit.iloc[:training_samples]
        y_val = y_fit.iloc[training_samples:]
        return X_train, X_val, y_train, y_val

    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training
        feel free to extend with super() or replace this method
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()

        fit_results.fit_instance = fr

        # extract training history
        fit_results.history = pd.DataFrame(fr.history)
        fit_results.history.index += 1

        fit_results.params = fr.params
        fit_results.model = fr.model

        fit_results.criterion = "str(fr.model.criterion)"
        fit_results.best_model_path = "str(fr.trainer.checkpoint_callback.best_model_path)"
        return fit_results
