import logging
import os
from pathlib import Path
from typing import Optional, List, Type

from darts.models.forecasting.transformer_model import TransformerModel
from torch import nn

from hdml.Models.Darts.BaseConfig import DartsPastCovariatesTorchModelConfig
from hdml.Models.Darts.BaseModel import DartsPastCovariatesTorchModel
from hdml.Models.Forecaster import MlAlgo

logger = logging.getLogger(__name__)

MlAlgo.register(TransformerModel)


class DartsTransformerConfig(DartsPastCovariatesTorchModelConfig):
    def __init__(
            self,
            # common params
            model_name: str = "darts_transformer",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            # TorchForecastingModel params
            forecast_horizon: int = 1,
            validation_size: float = 0.3,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            n_jobs: int = 1,
            roll_size: Optional[int] = None,
            num_samples: int = 1,
            num_loader_workers: int = 0,
            mc_dropout: bool = False,
            lower_cutoff: float = None,
            upper_cutoff: float = None,
            # model params
            tunner_on=False,
            n_epochs: int = 2,  # darts default: 100
            nr_epochs_val_period: int = 1,
            batch_size: int = 800,
            save_checkpoints: bool = True,
            force_reset: bool = True,
            d_model: int = 64,
            nhead: int = 4,
            num_encoder_layers: int = 3,
            num_decoder_layers: int = 3,
            dim_feedforward: int = 512,
            dropout: float = 0.1,
            activation: str = "relu",
            custom_encoder: Optional[nn.Module] = None,
            custom_decoder: Optional[nn.Module] = None,
            *args,
            **kwargs,
    ):
        """
        :param n_epochs: Number of epochs over which to train the model. Default: ``100``.
        :param nr_epochs_val_period: Number of epochs to wait before evaluating the validation loss (if a validation
            ``TimeSeries`` is passed to the :func:`fit()` method). Default: ``1``.
        :param batch_size: Number of time series (input and output sequences) used in each training pass. Default: ``32``.
        :param save_checkpoints: Whether or not to automatically save the untrained model and checkpoints from training.
            To load the model from checkpoint, call :func:`MyModelClass.load_from_checkpoint()`, where
            :class:`MyModelClass` is the :class:`TorchForecastingModel` class that was used (such as :class:`TFTModel`,
            :class:`NBEATSModel`, etc.). If set to ``False``, the model can still be manually saved using
            :func:`save_model()` and loaded using :func:`load_model()`. Default: ``False``.
        :param force_reset: If set to ``True``, any previously-existing model with the same name will be reset (all checkpoints will
            be discarded). Default: ``False``.
        :param input_chunk_length: The length of the input sequence fed to the model. Default: ``1``.
        :param output_chunk_length: The length of the forecast of the model. Default: ``1``.
        :param d_model:
            The number of expected features in the transformer encoder/decoder inputs (default=64).
        :param nhead:
            The number of heads in the multi-head attention mechanism (default=4).
        :param num_encoder_layers:
            The number of encoder layers in the encoder (default=3).
        :param num_decoder_layers:
            The number of decoder layers in the decoder (default=3).
        :param dim_feedforward:
            The dimension of the feedforward network model (default=512).
        :param dropout:
            Fraction of neurons affected by Dropout (default=0.1).
        :param activation:
            The activation function of encoder/decoder intermediate layer, (default='relu').
            can be one of the glu variant's FeedForward Network (FFN)[2]. A feedforward network is a
            fully-connected layer with an activation. The glu variant's FeedForward Network are a series
            of FFNs designed to work better with Transformer based models. ["GLU", "Bilinear", "ReGLU", "GEGLU",
            "SwiGLU", "ReLU", "GELU"] or one the pytorch internal activations ["relu", "gelu"]
        :param custom_encoder:
            A custom user-provided encoder module for the transformer (default=None).
        :param custom_decoder:
            A custom user-provided decoder module for the transformer (default=None).
        :param kwargs:
        """
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            validation_size=validation_size,
            past_covariates=past_covariates,
            future_covariates=future_covariates,
            n_jobs=n_jobs,
            roll_size=roll_size,
            num_samples=num_samples,
            num_loader_workers=num_loader_workers,
            mc_dropout=mc_dropout,
            forecast_horizon=forecast_horizon,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            tunner_on=tunner_on,
            *args, **kwargs
        )
        self.n_epochs = n_epochs
        self.nr_epochs_val_period = nr_epochs_val_period
        self.batch_size = batch_size
        self.save_checkpoints = save_checkpoints
        self.force_reset = force_reset
        self.d_model = d_model
        self.nhead = nhead
        self.num_encoder_layers = num_encoder_layers
        self.num_decoder_layers = num_decoder_layers
        self.dim_feedforward = dim_feedforward
        self.dropout = dropout
        self.activation = activation
        self.custom_encoder = custom_encoder
        self.custom_decoder = custom_decoder


class DartsTransformer(DartsPastCovariatesTorchModel):
    model: TransformerModel
    model_config: DartsTransformerConfig
    model_class: Type[TransformerModel] = TransformerModel
    pass
