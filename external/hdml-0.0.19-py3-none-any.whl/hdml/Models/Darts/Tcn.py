import logging
import os
from pathlib import Path
from typing import Optional, Type, List

from darts.models import TCNModel

from hdml.Models.Darts.BaseConfig import DartsPastCovariatesTorchModelConfig
from hdml.Models.Darts.BaseModel import DartsPastCovariatesTorchModel
from hdml.Models.Forecaster import MlAlgo

logger = logging.getLogger(__name__)

MlAlgo.register(TCNModel)


class DartsTcnConfig(DartsPastCovariatesTorchModelConfig):
    def __init__(
            self,
            # common params
            model_name: str = "darts_tcn",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            # TorchForecastingModel params
            forecast_horizon: int = 1,
            validation_size: float = 0.3,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            n_jobs: int = 1,
            roll_size: Optional[int] = None,
            num_samples: int = 1,
            num_loader_workers: int = 0,
            mc_dropout: bool = False,
            lower_cutoff: float = None,
            upper_cutoff: float = None,
            # model params
            tunner_on=False,
            n_epochs: int = 2,  # darts default: 100
            nr_epochs_val_period: int = 1,
            batch_size: int = 800,
            kernel_size: int = 3,
            num_filters: int = 3,
            num_layers: Optional[int] = None,
            dilation_base: int = 2,
            weight_norm: bool = False,
            dropout: float = 0.2,
            save_checkpoints: bool = True,
            force_reset: bool = True,
            *args,
            **kwargs,
    ):
        """
        :param n_epochs: Number of epochs over which to train the model. Default: ``100``.
        :param nr_epochs_val_period: Number of epochs to wait before evaluating the validation loss (if a validation
            ``TimeSeries`` is passed to the :func:`fit()` method). Default: ``1``.
        :param input_chunk_length: The length of the input sequence fed to the model. Default: ``1``.
        :param output_chunk_length: The length of the forecast of the model. Default: ``1``.
        :param kernel_size: The size of every kernel in a convolutional layer.  Default: ``3``.
        :param num_filters: The number of filters in a convolutional layer of the TCN.  Default: ``3``.
        :param weight_norm: Boolean value indicating whether to use weight normalization.  Default: ``False``.
        :param dilation_base: The base of the exponent that will determine the dilation on every level. Default: ``2``.
        :param num_layers: The number of convolutional layers. 
        :param dropout: The dropout rate for every convolutional layer. This is compatible with Monte Carlo dropout
            at inference time for model uncertainty estimation (enabled with ``mc_dropout=True`` at
            prediction time).
        :param batch_size: Number of time series (input and output sequences) used in each training pass. Default: ``32``.
        :param save_checkpoints: Whether or not to automatically save the untrained model and checkpoints from training.
            To load the model from checkpoint, call :func:`MyModelClass.load_from_checkpoint()`, where
            :class:`MyModelClass` is the :class:`TorchForecastingModel` class that was used (such as :class:`TFTModel`,
            :class:`NBEATSModel`, etc.). If set to ``False``, the model can still be manually saved using
            :func:`save_model()` and loaded using :func:`load_model()`. Default: ``False``.
        :param force_reset: If set to ``True``, any previously-existing model with the same name will be reset (all checkpoints will
            be discarded). Default: ``False``.
        :param kwargs:
        """
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            validation_size=validation_size,
            past_covariates=past_covariates,
            future_covariates=future_covariates,
            n_jobs=n_jobs,
            roll_size=roll_size,
            num_samples=num_samples,
            num_loader_workers=num_loader_workers,
            mc_dropout=mc_dropout,
            forecast_horizon=forecast_horizon,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            tunner_on=tunner_on,
            *args, **kwargs
        )
        self.n_epochs = n_epochs
        self.nr_epochs_val_period = nr_epochs_val_period
        self.batch_size = batch_size
        self.kernel_size = kernel_size
        self.num_filters = num_filters
        self.num_layers = num_layers
        self.dilation_base = dilation_base
        self.weight_norm = weight_norm
        self.dropout = dropout
        self.save_checkpoints = save_checkpoints
        self.force_reset = force_reset


class DartsTCN(DartsPastCovariatesTorchModel):
    model: TCNModel
    model_config: DartsTcnConfig
    model_class: Type[TCNModel] = TCNModel
    pass
