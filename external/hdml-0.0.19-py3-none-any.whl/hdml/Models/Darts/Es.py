import logging
import os
from pathlib import Path
from typing import Optional, Dict, Any

import pandas as pd
from darts import TimeSeries
from darts.models.forecasting.exponential_smoothing import ExponentialSmoothing
from darts.utils.utils import ModelMode, SeasonalityMode

from hdml.Models.Darts.BaseConfig import DartsConfig
from hdml.Models.Darts.BaseModel import DartsForecaster
from hdml.Models.Forecaster import MlAlgo
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)

MlAlgo.register(ExponentialSmoothing)


class DartsESConfig(DartsConfig):
    def __init__(
            self,
            input_chunk_length: int = 1,
            output_chunk_length: int = 1,
            model_name: str = "darts_es",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            validation_size: float = 0.3,
            trend: Optional[ModelMode] = ModelMode.ADDITIVE,
            damped: Optional[bool] = False,
            seasonal: Optional[ModelMode] = SeasonalityMode.ADDITIVE,
            seasonal_periods: Optional[int] = None,
            random_state: int = 0,
            num_samples: int = 1,
            forecast_horizon: int = 1,
            *args, **kwargs
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )

        self.forecast_horizon = forecast_horizon
        self.num_samples = num_samples
        self.validation_size = validation_size
        self.trend = trend
        self.damped = damped
        self.seasonal = seasonal
        self.seasonal_periods = seasonal_periods
        self.random_state = random_state

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length

    def training_params(self) -> Dict[str, Any]:
        dict_ = super().training_params()
        self.remove_attrs_from_dict(
            dict_=dict_,
            list_=["task",
                   "input_chunk_length",
                   "output_chunk_length"]
        )
        print(dict_)
        return dict_


class DartsES(DartsForecaster):
    model: ExponentialSmoothing
    model_config: DartsESConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.scaler_x = None
        self.scaler_y = None

        df_X_fit = pd.DataFrame(X_fit.iloc[:, 0])
        train_series = self._to_timeseries(df_X_fit)

        self.model = ExponentialSmoothing(
            trend=self.model_config.trend,
            damped=self.model_config.damped,
            seasonal=self.model_config.seasonal,
            seasonal_periods=self.model_config.seasonal_periods,
            random_state=self.model_config.random_state
        )

        fit_result = self.model.fit(train_series)

        return self._store_training_state(fit_result)

    # =============PRIVATE METHODS================
    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()
        fit_results.criterion = ""
        fit_results.best_model_path = ""
        return fit_results

    def _predict_datum(self, ts_history: TimeSeries) -> TimeSeries:
        
        forecast = self.model.predict(
            n=self.model_config.forecast_horizon,
            num_samples = self.model_config.num_samples)
        
        return forecast
