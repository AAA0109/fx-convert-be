import logging
from abc import ABC, abstractmethod
from typing import Optional, Tuple, List, Type

import pandas as pd
from darts import TimeSeries
from darts.dataprocessing.transformers import Scaler
from darts.models.forecasting.torch_forecasting_model import PastCovariatesTorchModel
from darts.utils.missing_values import fill_missing_values, missing_values_ratio
from hdml.Models.Darts.BaseConfig import DartsPastCovariatesTorchModelConfig, DartsConfig
from hdml.Models.Forecaster import Forecaster
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class DartsForecaster(Forecaster, ABC):
    """
    Forecaster interface to accomodate the algorithms from "Darts":
        https://unit8co.github.io/darts/
    """
    scaler_x: Optional[Scaler]
    scaler_y: Optional[Scaler]
    model_config: DartsConfig

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        :param X_test:
        :return:
                forecasts : pandas.DataFrame
                    Index:
                        reference_time (prediction time)
                    Columns:
                        Name: forecast, dtype: pd.DataFrame
                            Index:
                                horizon_time
                            Columns:
                                Name: <forecasted times series>, dtype: float64
                                Name: <forecasted times series 2>, dtype: float64
                                ....
                                Name: <forecasted times series n>, dtype: float64
        """
        X_test_ts = self._to_timeseries(X_test)
        scaled_X_test_ts = self._scale_data(X_test_ts, self.scaler_x)
        if self.model is None:
            raise Exception("model is not fitted yet!")
        forecasts = self._predict_data(scaled_X_test_ts)
        return forecasts

    # ========Private methods================
    def _predict_data(self, data: TimeSeries) -> pd.DataFrame:
        try:
            forecasts = {"reference_date": [], "forecast": []}
            for i in range(self.model_config.lookback - 1, len(data)):
                ts_history = self._get_history(i, data)
                forecast = self._predict_datum(ts_history)
                forecast = self._inverse_transform_data(forecast, self.scaler_x)
                df_forecast = forecast.pd_dataframe()

                # check if you are trying to forecast "Saturday" or "Sunday"
                if any(elem in set(df_forecast.index.day_name().to_list()) for elem in ["Saturday", "Sunday"]):
                    logger.warning("you are trying to forecast Saturday or Sunday")

                forecasts["forecast"].append(df_forecast.clip(lower=self.model_config.lower_cutoff, upper=self.model_config.upper_cutoff))
                forecasts["reference_date"].append(ts_history.end_time())
            forecasts = pd.DataFrame(forecasts)
            forecasts.set_index("reference_date", inplace=True)
            forecasts.sort_index(inplace=True)
        except Exception as e:
            raise RuntimeError(f"pred_series fails!: {e}")
        return forecasts

    @staticmethod
    def _get_history(i, test_series) -> TimeSeries:
        """
        get history of time series used for forecasting
        :param i:
        :param test_series:
        :return:
        """
        if i == len(test_series) - 1:
            ts_history = test_series.copy()
        else:
            ts_history, _ = test_series.split_after(i)
        # make sure the frequency is business days because sometimes the data loses the frequency
        try:
            return TimeSeries.from_dataframe(
                df=ts_history.pd_dataframe(),
                fill_missing_dates=True,
                freq='B')
        except:
            return TimeSeries.from_dataframe(
                df=ts_history.pd_dataframe(),
                fill_missing_dates=True,
                freq='D')


    @staticmethod
    def _to_timeseries(X: pd.DataFrame) -> TimeSeries:
        """
        convert pandas dataframe to darts TimeSeries object
        :param X: pandas dataframe
        :return: darts TimeSeries object
        """
        # todo frequency should be a input placeholder. this is useful when trading intraday
        try:
            ts_df = X.copy()
            ts_df.reset_index(inplace=True)
            ts_df["date"] = ts_df["date"].dt.strftime('%Y-%m-%d').copy()
            ts_df.columns.name = None

            ts_series = TimeSeries.from_dataframe(
                df=ts_df,
                time_col='date',
                fill_missing_dates=True,
                freq='B'
            )
        except:
            """
            If the frequency is not business day, we resample it to daily frequency
            """
            logger.warning("You are using daily frequency!")
            ts_df = X.copy()
            ts_df = ts_df.resample('D').ffill()
            ts_df.reset_index(inplace=True)
            ts_df["date"] = ts_df["date"].dt.strftime('%Y-%m-%d').copy()
            ts_df.columns.name = None

            ts_series = TimeSeries.from_dataframe(
                df=ts_df,
                time_col='date',
                fill_missing_dates=True,
                freq='D'
            )

        ts_series = fill_missing_values(ts_series)
        if missing_values_ratio(ts_series) != 0:
            raise RuntimeError("You have missing values in you series")
        return ts_series

    def _fit_scaler(self, data: TimeSeries) -> Scaler:
        scaler = Scaler()
        scaler.fit(data)
        return scaler

    def _scale_data(self, data: TimeSeries, scaler: Scaler) -> TimeSeries:
        return scaler.transform(data) if scaler is not None else data

    def _inverse_transform_data(self, data: TimeSeries, scaler: Scaler) -> TimeSeries:
        return scaler.inverse_transform(data) if scaler is not None else data

    # ===========Abstract Methods====================
    @abstractmethod
    def _predict_datum(self, ts_history) -> TimeSeries:
        raise NotImplementedError


class DartsTorchForecastingModel(DartsForecaster, ABC):
    pass


class DartsPastCovariatesTorchModel(DartsTorchForecastingModel, ABC):
    model: PastCovariatesTorchModel
    model_config: DartsPastCovariatesTorchModelConfig
    model_class: Type[PastCovariatesTorchModel]

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        scaled_X_train_ts, scaled_X_val_ts = self._create_training_dataset(X_fit, self.model_config.validation_size)
        self.model = self.model_class(**self.model_config.training_params())
        series_columns, past_covar_columns, future_covar_columns = self._get_columns(scaled_X_train_ts)
        fit_results = self.model.fit(
            series=scaled_X_train_ts[series_columns],
            past_covariates=scaled_X_train_ts[past_covar_columns] if past_covar_columns else None,
            future_covariates=scaled_X_train_ts[future_covar_columns] if future_covar_columns else None,
            val_series=scaled_X_val_ts[series_columns],
            val_past_covariates=scaled_X_val_ts[past_covar_columns] if past_covar_columns else None,
            val_future_covariates=scaled_X_val_ts[future_covar_columns] if future_covar_columns else None,
            verbose=True)
        self.model = self.model_class.load_from_checkpoint(**self.model_config.loading_params())
        return self._store_training_state(fit_results)

    # ========Private methods================
    def _predict_datum(self, ts_history: TimeSeries) -> TimeSeries:
        series_columns, past_covar_columns, future_covar_columns = self._get_columns(ts_history)
        forecast = self.model.predict(
            n=self.model_config.forecast_horizon,
            series=ts_history[series_columns],
            past_covariates=ts_history[past_covar_columns] if past_covar_columns else None,
            future_covariates=ts_history[future_covar_columns] if future_covar_columns else None,
            n_jobs=self.model_config.n_jobs,
            roll_size=self.model_config.roll_size,
            num_samples=self.model_config.num_samples,
            num_loader_workers=self.model_config.num_loader_workers,
            mc_dropout=self.model_config.mc_dropout

        )
        n_stack = len(ts_history.columns) - len(forecast.columns)
        if n_stack > 0:
            # todo: think of a better way to do the padding
            list_ = []
            for i in range(n_stack):
                series = forecast.pd_dataframe().iloc[:, 0]
                series.name = "padding"
                list_.append(series)
            padding = TimeSeries.from_dataframe(pd.concat(list_, axis=1))
            forecast = forecast.stack(padding)

        if missing_values_ratio(forecast) != 0:
            raise RuntimeError("forecast failed probably because of nan value!")
        return forecast

    def _get_columns(self, ts: TimeSeries) -> Tuple[List[str], List[str], List[str]]:
        past_covar_columns = self.model_config.past_covariates
        future_covar_columns = self.model_config.future_covariates
        if past_covar_columns is None and future_covar_columns is None:
            series_columns = ts.columns.to_list()
        else:
            excluded_columns = []
            if past_covar_columns is not None:
                excluded_columns += past_covar_columns
            if future_covar_columns is not None:
                excluded_columns += future_covar_columns
            series_columns = [c for c in ts.columns.to_list() if c not in excluded_columns]
        return series_columns, past_covar_columns, future_covar_columns

    def _create_training_dataset(self, X_fit: pd.DataFrame, validation_size: float) -> Tuple[TimeSeries, TimeSeries]:
        X_train_ts, X_val_ts = self._to_timeseries(X_fit).split_after(validation_size)
        self.scaler_x = self._fit_scaler(X_train_ts)
        scaled_X_train_ts = self._scale_data(X_train_ts, self.scaler_x)
        scaled_X_val_ts = self._scale_data(X_val_ts, self.scaler_x)
        return scaled_X_train_ts, scaled_X_val_ts

    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training process
        feel free to extend with super() or replace this method
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()
        fit_results.fit_instance = fr
        fit_results.input_chunk_length = fr.input_chunk_length
        fit_results.output_chunk_length = fr.output_chunk_length
        fit_results.batch_size = fr.batch_size
        fit_results.n_epochs = fr.n_epochs
        fit_results.criterion = str(fr.model.criterion)
        return fit_results
