import logging
import os
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from darts import TimeSeries
from darts.models.forecasting.theta import FourTheta
from darts.utils.utils import ModelMode, SeasonalityMode, TrendMode

from hdml.Models.Darts.BaseConfig import DartsConfig
from hdml.Models.Darts.BaseModel import DartsForecaster
from hdml.Models.Forecaster import MlAlgo
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)

MlAlgo.register(FourTheta)


class DartsThetaConfig(DartsConfig):
    def __init__(
            self,
            input_chunk_length: int = 1,
            output_chunk_length: int = 1,
            model_name: str = "darts_theta",
            work_dir: Path = os.getcwd(),
            task: str = "R",

            theta: int = 2,
            seasonality_period: Optional[int] = None,
            # season_mode: SeasonalityMode = SeasonalityMode.MULTIPLICATIVE,
            season_mode: SeasonalityMode = SeasonalityMode.NONE,  # default: SeasonalityMode.MULTIPLICATIVE
            model_mode: ModelMode = ModelMode.ADDITIVE,
            trend_mode: TrendMode = TrendMode.LINEAR,
            normalization: bool = True,

            *args,
            **kwargs,
    ):
        """
            :param theta:
                Value of the theta parameter. Defaults to 2.
                If theta = 1, then the fourtheta method restricts to a simple exponential smoothing (SES).
                If theta = 0, then the fourtheta method restricts to a simple `trend_mode` regression.
            :param seasonality_period:
                User-defined seasonality period. If not set, will be tentatively inferred from the training series upon
                calling `fit()`.
            :param model_mode:
                Type of model combining the Theta lines. Either ModelMode.ADDITIVE or ModelMode.MULTIPLICATIVE.
                Defaults to `ModelMode.ADDITIVE`.
            :param season_mode:
                Type of seasonality.
                Either SeasonalityMode.MULTIPLICATIVE, SeasonalityMode.ADDITIVE or SeasonalityMode.NONE.
                Defaults to `SeasonalityMode.MULTIPLICATIVE`.
            :param trend_mode:
                Type of trend to fit. Either TrendMode.LINEAR or TrendMode.EXPONENTIAL.
                Defaults to `TrendMode.LINEAR`.
            :param normalization:
                If `True`, the data is normalized so that the mean is 1. Defaults to `True`.
            :param kwargs:

            Notes
            -----
            Even though this model is an improvement of :class:`Theta`, it is a naive
            implementation of the algorithm, which can potentially be slower.
        """
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            *args, **kwargs
        )
        self.input_chunk_length = input_chunk_length
        self.output_chunk_length = output_chunk_length
        self.theta = theta
        self.seasonality_period = seasonality_period
        self.season_mode = season_mode
        self.model_mode = model_mode
        self.trend_mode = trend_mode
        self.normalization = normalization

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class DartsTheta(DartsForecaster):
    model: FourTheta
    model_config: DartsThetaConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.scaler_x = None
        self.scaler_y = None
        train_series = self._to_timeseries(X_fit)

        self.model = FourTheta(
            theta=self.model_config.theta,
            seasonality_period=self.model_config.seasonality_period,
            season_mode=self.model_config.season_mode,
            model_mode=self.model_config.model_mode,
            trend_mode=self.model_config.trend_mode,
            normalization=self.model_config.normalization
        )
        fit_results = self.model.fit(train_series)
        return self._store_training_state(fit_results)

    # =============PRIVATE METHODS================
    def _predict_datum(self, ts_history: TimeSeries, forecast_horizon=1) -> float:
        forecast = self.model.predict(n=forecast_horizon)
        if np.isnan(forecast.values()[0, 0]):
            raise RuntimeError("forecast failed probably because of nan value!")
        return forecast.values()[0, 0]
    def _store_training_state(self, fr) -> FitResult:
        fit_results = FitResult()
        fit_results.fit_instance = fr
        fit_results.criterion = ""
        fit_results.best_model_path = ""
        return fit_results
