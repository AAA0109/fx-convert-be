import logging
import os
from pathlib import Path
from typing import List, Optional, Type

from darts.models import NBEATSModel

from hdml.Models.Darts.BaseConfig import DartsPastCovariatesTorchModelConfig
from hdml.Models.Darts.BaseModel import DartsPastCovariatesTorchModel
from hdml.Models.Forecaster import MlAlgo

logger = logging.getLogger(__name__)

MlAlgo.register(NBEATSModel)


class DartsNbeatsConfig(DartsPastCovariatesTorchModelConfig):
    def __init__(
            self,
            # common params
            model_name: str = "darts_nbeats",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            # TorchForecastingModel params
            forecast_horizon: int = 1,
            validation_size: float = 0.3,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            n_jobs: int = 1,
            roll_size: Optional[int] = None,
            num_samples: int = 1,
            num_loader_workers: int = 0,
            mc_dropout: bool = False,
            lower_cutoff: float = None,
            upper_cutoff: float = None,
            # tuning params
            tunner_on: bool = False,
            hypertunner_config: Optional[dict] = None,
            # model params
            n_epochs: int = 2,
            nr_epochs_val_period: int = 1,
            num_stacks: int = 30,
            num_blocks: int = 1,
            num_layers: int = 4,
            layer_widths: int = 256,
            expansion_coefficient_dim: int = 5,
            trend_polynomial_degree: int = 2,
            dropout: float = 0.0,
            activation: str = "ReLU",
            batch_size: int = 800,
            generic_architecture: bool = True,
            save_checkpoints: bool = True,
            force_reset: bool = True,
            *args,
            **kwargs,
    ):
        """
        Note: always use keyword arguments for clarity!
        :param n_epochs: Number of epochs over which to train the model. Default: ``100``.
        :param nr_epochs_val_period: Number of epochs to wait before evaluating the validation loss (if a validation
            ``TimeSeries`` is passed to the :func:`fit()` method). Default: ``1``.
        :param input_chunk_length: The length of the input sequence fed to the model.
        :param output_chunk_length: The length of the forecast of the model.
        :param num_stacks: The number of stacks that make up the whole model. Only used if `generic_architecture` is set to `True`.
            The interpretable architecture always uses two stacks - one for trend and one for seasonality.
        :param num_blocks: The number of blocks making up every stack.
        :param num_layers: The number of fully connected layers preceding the final forking layers in each block of every stack.
        :param layer_widths: Determines the number of neurons that make up each fully connected layer in each block of every stack.
            If a list is passed, it must have a length equal to `num_stacks` and every entry in that list corresponds
            to the layer width of the corresponding stack. If an integer is passed, every stack will have blocks
            with FC layers of the same width.
        :param batch_size: Number of time series (input and output sequences) used in each training pass. Default: ``32``.
        :param generic_architecture: Boolean value indicating whether the generic architecture of N-BEATS is used.
            If not, the interpretable architecture outlined in the paper (consisting of one trend
            and one seasonality stack with appropriate waveform generator functions).
        :param save_checkpoints: Whether or not to automatically save the untrained model and checkpoints from training.
            To load the model from checkpoint, call :func:`MyModelClass.load_from_checkpoint()`, where
            :class:`MyModelClass` is the :class:`TorchForecastingModel` class that was used (such as :class:`TFTModel`,
            :class:`NBEATSModel`, etc.). If set to ``False``, the model can still be manually saved using
            :func:`save_model()` and loaded using :func:`load_model()`. Default: ``False``.
        :param force_reset: If set to ``True``, any previously-existing model with the same name will be reset (all checkpoints will
            be discarded). Default: ``False``.
        :param kwargs:
        """
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            validation_size=validation_size,
            past_covariates=past_covariates,
            future_covariates=future_covariates,
            n_jobs=n_jobs,
            roll_size=roll_size,
            num_samples=num_samples,
            num_loader_workers=num_loader_workers,
            mc_dropout=mc_dropout,
            forecast_horizon=forecast_horizon,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            tunner_on=tunner_on,
            hypertunner_config=hypertunner_config,
            *args, **kwargs
        )
        # model params
        self.n_epochs = n_epochs
        self.nr_epochs_val_period = nr_epochs_val_period
        self.num_stacks = num_stacks
        self.num_blocks = num_blocks
        self.num_layers = num_layers
        self.layer_widths = layer_widths
        self.expansion_coefficient_dim = expansion_coefficient_dim
        self.trend_polynomial_degree = trend_polynomial_degree
        self.dropout = dropout
        self.activation = activation
        self.batch_size = batch_size
        self.generic_architecture = generic_architecture
        self.save_checkpoints = save_checkpoints
        self.force_reset = force_reset


class DartsNbeats(DartsPastCovariatesTorchModel):
    model: NBEATSModel
    model_config: DartsNbeatsConfig
    model_class: Type[NBEATSModel] = NBEATSModel
    pass
