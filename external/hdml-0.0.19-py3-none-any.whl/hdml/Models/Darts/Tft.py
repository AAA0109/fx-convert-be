import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import pandas as pd
from darts.models.forecasting.tft_model import TFTModel
from darts.utils.likelihood_models import Likelihood
from torch import nn

from hdml.Models.Darts.BaseConfig import DartsConfig
from hdml.Models.Darts.BaseModel import DartsForecaster
from hdml.Models.Forecaster import MlAlgo
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)

MlAlgo.register(TFTModel)


class DartsTFTConfig(DartsConfig):
    def __init__(
            self,
            model_name: str = "darts_tft",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            n_epochs: int = 2,  # darts default: 100
            nr_epochs_val_period: int = 1,
            batch_size: int = 800,
            save_checkpoints: bool = True,
            force_reset: bool = True,

            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            hidden_size: Union[int, List[int]] = 16,
            lstm_layers: int = 1,
            num_attention_heads: int = 4,
            full_attention: bool = False,
            feed_forward: str = "GatedResidualNetwork",
            dropout: float = 0.1,
            hidden_continuous_size: int = 8,
            categorical_embedding_sizes: Optional[
                Dict[str, Union[int, Tuple[int, int]]]
            ] = None,
            add_relative_index: bool = True,  # with model.fit, need set it True
            loss_fn: Optional[nn.Module] = None,
            likelihood: Optional[Likelihood] = None,
            validation_size: float = 0.3,

            *args,
            **kwargs,
    ):
        """
        :param n_epochs: Number of epochs over which to train the model. Default: ``100``.
        :param nr_epochs_val_period: Number of epochs to wait before evaluating the validation loss (if a validation
            ``TimeSeries`` is passed to the :func:`fit()` method). Default: ``1``.
        :param batch_size: Number of time series (input and output sequences) used in each training pass. Default: ``32``.
        :param save_checkpoints: Whether or not to automatically save the untrained model and checkpoints from training.
            To load the model from checkpoint, call :func:`MyModelClass.load_from_checkpoint()`, where
            :class:`MyModelClass` is the :class:`TorchForecastingModel` class that was used (such as :class:`TFTModel`,
            :class:`NBEATSModel`, etc.). If set to ``False``, the model can still be manually saved using
            :func:`save_model()` and loaded using :func:`load_model()`. Default: ``False``.
        :param force_reset: If set to ``True``, any previously-existing model with the same name will be reset (all checkpoints will
            be discarded). Default: ``False``.
        :param input_chunk_length: The length of the input sequence fed to the model. Default: ``1``.
        :param output_chunk_length: The length of the forecast of the model. Default: ``1``.
        :param hidden_size:  Hidden state size of the TFT. It is the main hyper-parameter and common across the internal TFT architecture.  Default: ``16``.
        :param lstm_layers: Number of layers for the Long Short Term Memory (LSTM) Encoder and Decoder (1 is a good default).
        :param num_attention_heads:  Number of attention heads (4 is a good default)
        :param full_attention: If ``True``, applies multi-head attention query on past (encoder) and future (decoder) parts. Otherwise, only queries on future part. Defaults to ``False``.
        :param feed_forward:  A feedforward network is a fully-connected layer with an activation. TFT Can be one of the glu variant's FeedForward Network (FFN)[2]. The glu variant's FeedForward Network are a series of FFNs designed to work better with Transformer based models. Defaults to ``"GatedResidualNetwork"``. ["GLU", "Bilinear", "ReGLU", "GEGLU", "SwiGLU", "ReLU", "GELU"] or the TFT original FeedForward Network ["GatedResidualNetwork"].
        :param dropout:  Fraction of neurons affected by dropout. This is compatible with Monte Carlo dropout at inference time for model uncertainty estimation (enabled with ``mc_dropout=True`` at prediction time).
        :param hidden_continuous_size: Default for hidden size for processing continuous variables
        :param categorical_embedding_sizes: 
            A dictionary used to construct embeddings for categorical static covariates. The keys are the column names
            of the categorical static covariates. Each value is either a single integer or a tuple of integers.
            For a single integer give the number of unique categories (n) of the corresponding variable. For example
            ``{"some_column": 64}``. The embedding size will be automatically determined by
            ``min(round(1.6 * n**0.56), 100)``.
            For a tuple of integers, give (number of unique categories, embedding size). For example
            ``{"some_column": (64, 8)}``.
            Note that ``TorchForecastingModels`` only support numeric data. Consider transforming/encoding your data
            with `darts.dataprocessing.transformers.static_covariates_transformer.StaticCovariatesTransformer`.
        :param add_relative_index: 
            Whether to add positional values to future covariates. Defaults to ``True``.
            This allows to use the TFTModel without having to pass future_covariates to :func:`fit()` and
            :func:`train()`. It gives a value to the position of each step from input and output chunk relative
            to the prediction point. The values are normalized with ``input_chunk_length``.
        :param loss_fn: nn.Module
            PyTorch loss function used for training. By default, the TFT model is probabilistic and uses a
            ``likelihood`` instead (``QuantileRegression``). To make the model deterministic, you can set the `
            `likelihood`` to None and give a ``loss_fn`` argument.
        :param likelihood: 
            The likelihood model to be used for probabilistic forecasts. By default, the TFT uses  a ``QuantileRegression`` likelihood.
        :param kwargs:
        """
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            *args, **kwargs
        )
        self.n_epochs = n_epochs
        self.nr_epochs_val_period = nr_epochs_val_period
        self.batch_size = batch_size
        self.save_checkpoints = save_checkpoints
        self.force_reset = force_reset

        self.input_chunk_length = input_chunk_length
        self.output_chunk_length = output_chunk_length
        self.hidden_size = hidden_size
        self.lstm_layers = lstm_layers
        self.num_attention_heads = num_attention_heads
        self.full_attention = full_attention
        self.feed_forward = feed_forward
        self.dropout = dropout
        self.hidden_continuous_size = hidden_continuous_size
        self.categorical_embedding_sizes = categorical_embedding_sizes
        self.add_relative_index = add_relative_index
        self.loss_fn = loss_fn
        self.likelihood = likelihood
        self.validation_size=validation_size

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class DartsTFT(DartsForecaster):
    model: TFTModel
    model_config: DartsTFTConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        train_series, val_series = self._create_training_dataset(X_fit, y_fit, self.model_config.validation_size)

        self.model = TFTModel(**self.model_config.training_params())
        fit_results = self.model.fit(
            train_series, val_series=val_series, verbose=True)
        self.model = TFTModel.load_from_checkpoint(**self.model_config.loading_params())
        return self._store_training_state(fit_results)

