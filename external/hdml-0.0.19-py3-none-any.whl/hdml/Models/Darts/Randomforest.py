import logging
import os
from pathlib import Path
from typing import List, Optional, Tuple, Union, Dict, Any

import pandas as pd
from darts.models.forecasting.random_forest import RandomForest

from hdml.Models.Darts.BaseConfig import DartsConfig
from hdml.Models.Darts.BaseModel import DartsForecaster
from hdml.Models.Forecaster import MlAlgo
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)

MlAlgo.register(RandomForest)


class DartsRandomforestConfig(DartsConfig):
    def __init__(
            self,
            model_name: str = "darts_randomforest",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: Union[int, list] = None,
            lags_past_covariates: Union[int, List[int]] = None,
            lags_future_covariates: Union[Tuple[int, int], List[int]] = None,
            output_chunk_length: int = 1,
            add_encoders: Optional[dict] = None,
            n_estimators: Optional[int] = 100,
            max_depth: Optional[int] = None,
            validation_size: float = 0.3,
            *args,
            **kwargs,
    ):
        """
            :param lags:
                Lagged target values used to predict the next time step. If an integer is given the last `lags` past lags
                are used (from -1 backward). Otherwise a list of integers with lags is required (each lag must be < 0).
            :param lags_past_covariates
                Number of lagged past_covariates values used to predict the next time step. If an integer is given the last
                `lags_past_covariates` past lags are used (inclusive, starting from lag -1). Otherwise a list of integers
                with lags < 0 is required.
            :param lags_future_covariates:
                Number of lagged future_covariates values used to predict the next time step. If an tuple (past, future) is
                given the last `past` lags in the past are used (inclusive, starting from lag -1) along with the first
                `future` future lags (starting from 0 - the prediction time - up to `future - 1` included). Otherwise a list
                of integers with lags is required.
            :param output_chunk_length:
                Number of time steps predicted at once by the internal regression model. Does not have to equal the forecast
                horizon `n` used in `predict()`. However, setting `output_chunk_length` equal to the forecast horizon may
                be useful if the covariates don't extend far enough into the future.
            :param add_encoders:
                A large number of past and future covariates can be automatically generated with `add_encoders`.
                This can be done by adding multiple pre-defined index encoders and/or custom user-made functions that
                will be used as index encoders. Additionally, a transformer such as Darts' :class:`Scaler` can be added to
                transform the generated covariates. This happens all under one hood and only needs to be specified at
                model creation.
                Read :meth:`SequentialEncoder <darts.utils.data.encoders.SequentialEncoder>` to find out more about
                ``add_encoders``. Default: ``None``. An example showing some of ``add_encoders`` features:

                .. highlight:: python
                .. code-block:: python

                    add_encoders={
                        'cyclic': {'future': ['month']},
                        'datetime_attribute': {'future': ['hour', 'dayofweek']},
                        'position': {'past': ['absolute'], 'future': ['relative']},
                        'custom': {'past': [lambda idx: (idx.year - 1950) / 50]},
                        'transformer': Scaler()
                    }
                ..
            :param n_estimators : int
                The number of trees in the forest.
            :param max_depth : int
                The maximum depth of the tree. If None, then nodes are expanded until all leaves are pure or until all
                leaves contain less than min_samples_split samples.
            :param kwargs:
                Additional keyword arguments passed to `sklearn.ensemble.RandomForest`.
        """
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            *args, **kwargs
        )
        self.lags = input_chunk_length
        self.lags_past_covariates = lags_past_covariates
        self.lags_future_covariates = lags_future_covariates
        self.output_chunk_length = output_chunk_length
        self.add_encoders = add_encoders
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.validation_size = validation_size

    def training_params(self) -> Dict[str, Any]:
        dict_ = self.remove_attrs_from_dict(
            dict_=self.to_dict(),
            list_=["task", "validation_size", "work_dir", "model_name", "kwargs"]
        )
        return dict_

    def loading_params(self) -> Dict[str, Any]:
        dict_ = self.get_attrs("work_dir")
        dict_["path"] = str(dict_["work_dir"] / 'model.pkl')
        del dict_["work_dir"]
        return dict_

    @property
    def lookback(self) -> int:
        return self.lags

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class DartsRandomForest(DartsForecaster):
    model: RandomForest
    model_config: DartsRandomforestConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.scaler_x = None
        self.scaler_y = None
        train_series = self._to_timeseries(X_fit)

        self.model = RandomForest(**self.model_config.training_params())
        fit_results = self.model.fit(train_series)
        return self._store_training_state(fit_results)

    # =============PRIVATE METHODS================
    def _store_training_state(self, fr) -> FitResult:
        fit_results = FitResult()
        fit_results.fit_instance = fr
        fit_results.criterion = ""
        fit_results.best_model_path = ""
        return fit_results
