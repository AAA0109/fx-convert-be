import logging
import os
from pathlib import Path

from typing import List, Optional, Tuple, Union

import pandas as pd
from darts import TimeSeries
from darts.models.forecasting.gradient_boosted_model import LightGBMModel

from hdml.Models.Darts.BaseConfig import DartsConfig
from hdml.Models.Darts.BaseModel import DartsForecaster
from hdml.Models.Forecaster import MlAlgo
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)

MlAlgo.register(LightGBMModel)


class DartsLightGBMConfig(DartsConfig):
    def __init__(
            self,
            model_name: str = "darts_lightgbm",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            lags:  Union[int, list] = 4,
            input_chunk_length: Union[int, list] = 4,
            lags_past_covariates: Union[int, List[int]] = None,
            lags_future_covariates: Union[Tuple[int, int], List[int]] = None,
            output_chunk_length: int = 1,
            add_encoders: Optional[dict] = None,
            likelihood: str = None,
            quantiles: List[float] = None,
            random_state: Optional[int] = None,
            save_checkpoints: bool = True,
            validation_size: float = 0.3,
            
            forecast_horizon: int = 1,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            max_samples_per_ts: Optional[int] = None,
            num_samples:int = 1,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            task=task,
            *args, **kwargs)
        
        self.lags = lags
        self.lags_past_covariates = lags_past_covariates
        self.lags_future_covariates = lags_future_covariates
        self.add_encoders = add_encoders
        self.likelihood = likelihood
        self.quantiles = quantiles
        self.random_state = random_state
        self.save_checkpoints = save_checkpoints
        self.validation_size = validation_size
        
        #fit & predict params
        self.forecast_horizon = forecast_horizon
        self.past_covariates = past_covariates
        self.future_covariates = future_covariates
        self.max_samples_per_ts = max_samples_per_ts
        self.num_samples = num_samples

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class DartsLightGBM(DartsForecaster):
    model: LightGBMModel
    model_config: DartsLightGBMConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        train_series, val_series = self._create_training_dataset(X_fit, self.model_config.validation_size)

        
        train_series_columns, past_covar_columns, future_covar_columns = self._get_columns(train_series)
        val_series_columns, val_past_covar_columns, val_future_covar_columns = self._get_columns(val_series)
        
        self.model = LightGBMModel(
            lags=self.model_config.lags,
            lags_past_covariates=self.model_config.lags_past_covariates,
            lags_future_covariates=self.model_config.lags_future_covariates,
            output_chunk_length=self.model_config.output_chunk_length,
            add_encoders=self.model_config.add_encoders,
            likelihood=self.model_config.likelihood,
            quantiles=self.model_config.quantiles,
            save_checkpoints=self.model_config.save_checkpoints,
            random_state=self.model_config.random_state
        )

        fit_result = self.model.fit(
            series = train_series[train_series_columns],
            past_covariates=train_series[past_covar_columns] if past_covar_columns else None,
            future_covariates=train_series[future_covar_columns] if future_covar_columns else None,
            val_series=val_series[val_series_columns],
            val_past_covariates=val_series[val_past_covar_columns] if val_past_covar_columns else None,
            val_future_covariates=val_series[val_future_covar_columns] if val_future_covar_columns else None,
            max_samples_per_ts=self.model_config.max_samples_per_ts,
            )
        
        
        return self._store_training_state(fit_result)

    # =============PRIVATE METHODS================
    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()
        fit_results.criterion = ""
        fit_results.best_model_path = ""
        return fit_results

    def _create_training_dataset(self, X_fit: pd.DataFrame, validation_size: float) -> Tuple[TimeSeries, TimeSeries]:
        X_train_ts, X_val_ts = self._to_timeseries(X_fit).split_after(validation_size)
        self.scaler_x = self._fit_scaler(X_train_ts)
        scaled_X_train_ts = self._scale_data(X_train_ts, self.scaler_x)
        scaled_X_val_ts = self._scale_data(X_val_ts, self.scaler_x)
        return scaled_X_train_ts, scaled_X_val_ts
    
    def _predict_datum(self, ts_history: TimeSeries) -> TimeSeries:
        
        series_columns, past_covar_columns, future_covar_columns = self._get_columns(ts_history)
        
        forecast = self.model.predict(
            n= self.model_config.forecast_horizon,
            series=ts_history[series_columns],
            past_covariates=ts_history[past_covar_columns] if past_covar_columns else None,
            future_covariates=ts_history[future_covar_columns] if future_covar_columns else None,
            num_samples=self.model_config.num_samples
            )

        return forecast
    
    def _get_columns(self, ts: TimeSeries) -> Tuple[List[str], List[str], List[str]]:
        past_covar_columns = self.model_config.past_covariates
        future_covar_columns = self.model_config.future_covariates
        if past_covar_columns is None and future_covar_columns is None:
            series_columns = ts.columns.to_list()
        else:
            excluded_columns = []
            if past_covar_columns is not None:
                excluded_columns += past_covar_columns
            if future_covar_columns is not None:
                excluded_columns += future_covar_columns
            series_columns = [c for c in ts.columns.to_list() if c not in excluded_columns]

        return series_columns, past_covar_columns, future_covar_columns