import logging
#
import os
from pathlib import Path
from typing import List, Optional, Type, Tuple

from darts.models import NHiTSModel

from hdml.Models.Darts.BaseConfig import DartsPastCovariatesTorchModelConfig
from hdml.Models.Darts.BaseModel import DartsPastCovariatesTorchModel
from hdml.Models.Forecaster import MlAlgo

MlAlgo.register(NHiTSModel)

logger = logging.getLogger(__name__)


class DartsNhitsConfig(DartsPastCovariatesTorchModelConfig):
    def __init__(
            self,
            # common params
            model_name: str = "darts_nhits",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            # TorchForecastingModel params
            forecast_horizon: int = 1,
            validation_size: float = 0.3,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            n_jobs: int = 1,
            roll_size: Optional[int] = None,
            num_samples: int = 1,
            num_loader_workers: int = 0,
            mc_dropout: bool = False,
            lower_cutoff: float = None,
            upper_cutoff: float = None,
             # tuning params
            tunner_on: bool = False,
            hypertunner_config: Optional[dict] = None,
            # model params
            n_epochs: int = 2,
            nr_epochs_val_period: int = 1,
            num_stacks: int = 10,
            num_blocks: int = 1,
            num_layers: int = 4,
            layer_widths: int = 512,
            pooling_kernel_sizes: Optional[Tuple[Tuple[int]]] = None,
            n_freq_downsample: Optional[Tuple[Tuple[int]]] = None,
            dropout: float = 0.1,
            activation: str = "ReLU",
            batch_size: int = 800,
            MaxPool1d: bool = True,
            save_checkpoints: bool = True,
            force_reset: bool = True,
            *args,
            **kwargs,
    ):
        """An implementation of the N-HiTS model, as presented in [1]_.

        N-HiTS is similar to N-BEATS (implemented in :class:`NBEATSModel`),
        but attempts to provide better performance at lower computational cost by introducing
        multi-rate sampling of the inputs and multi-scale interpolation of the outputs.

        Similar to :class:`NBEATSModel`, in addition to the univariate version presented in the paper,
        this implementation also supports multivariate series (and covariates) by flattening the model inputs
        to a 1-D series and reshaping the outputs to a tensor of appropriate dimensions. Furthermore, it also
        supports producing probabilistic forecasts (by specifying a `likelihood` parameter).

        This model supports past covariates (known for `input_chunk_length` points before prediction time).

        The multi-rate sampling is done via MaxPooling, which is controlled by ``pooling_kernel_sizes``.
        This parameter can be a tuple of tuples, of size (num_stacks x num_blocks), specifying the kernel
        size for each block in each stack. If left to ``None``, some default values will be used based on
        ``input_chunk_length``.
        Similarly, the multi-scale interpolation is controlled by ``n_freq_downsample``, which gives the
        downsampling factors to be used in each block of each stack. If left to ``None``, some default
        values will be used based on the ``output_chunk_length``.

        Parameters
        ----------
        input_chunk_length
            The length of the input sequence fed to the model.
        output_chunk_length
            The length of the forecast of the model.
        num_stacks
            The number of stacks that make up the whole model.
        num_blocks
            The number of blocks making up every stack.
        num_layers
            The number of fully connected layers preceding the final forking layers in each block of every stack.
        layer_widths
            Determines the number of neurons that make up each fully connected layer in each block of every stack.
            If a list is passed, it must have a length equal to `num_stacks` and every entry in that list corresponds
            to the layer width of the corresponding stack. If an integer is passed, every stack will have blocks
            with FC layers of the same width.
        pooling_kernel_sizes
            If set, this parameter must be a tuple of tuples, of size (num_stacks x num_blocks), specifying the kernel
            size for each block in each stack used for the input pooling layer.
            If left to ``None``, some default values will be used based on ``input_chunk_length``.
        n_freq_downsample
            If set, this parameter must be a tuple of tuples, of size (num_stacks x num_blocks), specifying the
            downsampling factors before interpolation, for each block in each stack.
            If left to ``None``, some default values will be used based on ``output_chunk_length``.
        dropout
            The dropout probability to be used in fully connected layers. This is compatible with Monte Carlo dropout
            at inference time for model uncertainty estimation (enabled with ``mc_dropout=True`` at
            prediction time).
        activation
            The activation function of encoder/decoder intermediate layer (default='ReLU').
            Supported activations: ['ReLU','RReLU', 'PReLU', 'Softplus', 'Tanh', 'SELU', 'LeakyReLU',  'Sigmoid']
        MaxPool1d
            Use MaxPool1d pooling. False uses AvgPool1d
        **kwargs
            Optional arguments to initialize the pytorch_lightning.Module, pytorch_lightning.Trainer, and
            Darts' :class:`TorchForecastingModel`.
        """
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            validation_size=validation_size,
            past_covariates=past_covariates,
            future_covariates=future_covariates,
            n_jobs=n_jobs,
            roll_size=roll_size,
            num_samples=num_samples,
            num_loader_workers=num_loader_workers,
            mc_dropout=mc_dropout,
            forecast_horizon=forecast_horizon,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            tunner_on=tunner_on,
            hypertunner_config=hypertunner_config,
            *args, **kwargs
        )
        self.n_epochs = n_epochs
        self.nr_epochs_val_period = nr_epochs_val_period
        self.num_stacks = num_stacks
        self.num_blocks = num_blocks
        self.num_layers = num_layers
        self.layer_widths = layer_widths
        self.pooling_kernel_sizes = pooling_kernel_sizes
        self.n_freq_downsample = n_freq_downsample
        self.dropout = dropout
        self.activation = activation
        self.MaxPool1d = MaxPool1d
        self.batch_size = batch_size
        self.save_checkpoints = save_checkpoints
        self.force_reset = force_reset


class DartsNhits(DartsPastCovariatesTorchModel):
    model: NHiTSModel
    model_config: DartsNhitsConfig
    model_class: Type[NHiTSModel] = NHiTSModel
    pass
