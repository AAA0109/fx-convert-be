import logging
import os
from pathlib import Path
from typing import Optional, List, Union, Type

import torch.nn as nn
from darts.models import BlockRNNModel

from hdml.Models.Darts.BaseConfig import DartsPastCovariatesTorchModelConfig
from hdml.Models.Darts.BaseModel import DartsPastCovariatesTorchModel
from hdml.Models.Forecaster import MlAlgo


logger = logging.getLogger(__name__)

# darts's LSTM is inclueded in BlockRNNModel
LSTMModel = BlockRNNModel
MlAlgo.register(LSTMModel)


class DartsLstmConfig(DartsPastCovariatesTorchModelConfig):
    def __init__(
            self,
            # FitConfig
            model_name: str = "darts_lstm",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            # TunningConfig
            tunner_on: Optional[bool] = False,
            hypertunner_config: Optional[dict] = None,
            # DartsConfig
            lower_cutoff: Optional[float] = None,
            upper_cutoff: Optional[float] = None,
            # DartsTorchForecastingModelConfig
            batch_size: int = 800,  # darts default: 32
            n_epochs: int = 2,  # darts default: 100
            log_tensorboard: bool = False,
            nr_epochs_val_period: int = 1,
            force_reset: bool = True,  # darts default: False
            save_checkpoints: bool = True,  # darts default: False
            add_encoders: Optional[dict] = None,
            random_state: Optional[int] = None,
            pl_trainer_kwargs: Optional[dict] = None,
            show_warnings: bool = False,
            # DartsPastCovariatesTorchModelConfig
            forecast_horizon: int = 1,
            validation_size: float = 0.3,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            n_jobs: int = 1,
            roll_size: Optional[int] = None,
            num_samples: int = 1,
            num_loader_workers: int = 0,
            mc_dropout: bool = False,
            # ModelConfig
            model: Union[str, nn.Module] = "LSTM",
            hidden_dim: int = 25,
            n_rnn_layers: int = 1,
            hidden_fc_sizes: Optional[List] = None,
            dropout: float = 0.0,
            *args, **kwargs
    ):
        """
        reference: darts.models.forecasting.BlockRNNModel
        Duplicate parameter in FitConfig and BlockRNNModel
            :param input_chunk_length: The number of time steps that will be fed to the internal forecasting module
            :param output_chunk_length: Number of time steps to be output by the internal forecasting module.
        
        :param model: Either a string specifying the RNN module type ("RNN", "LSTM" or "GRU"),\
            or a PyTorch module with the same specifications as\
            :class:`darts.models.block_rnn_model._BlockRNNModule`.
        :param hidden_dim: Size for feature maps for each hidden RNN layer (:math:`h_n`).\
            In Darts version <= 0.21, hidden_dim was referred as hidden_size.
        :param n_rnn_layers: Number of layers in the RNN module.
        :param hidden_fc_sizes: Sizes of hidden layers connecting the last hidden layer of the RNN module to the output, if any.
        :param dropout: Fraction of neurons afected by Dropout.
        :param **kwargs: Optional arguments to initialize the pytorch_lightning.Module, pytorch_lightning.Trainer, and\
            Darts' :class:`TorchForecastingModel`.

        """
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            tunner_on=tunner_on,
            hypertunner_config=hypertunner_config,
            batch_size=batch_size,
            n_epochs=n_epochs,
            log_tensorboard=log_tensorboard,
            nr_epochs_val_period=nr_epochs_val_period,
            force_reset=force_reset,
            save_checkpoints=save_checkpoints,
            add_encoders=add_encoders,
            random_state=random_state,
            pl_trainer_kwargs=pl_trainer_kwargs,
            show_warnings=show_warnings,
            forecast_horizon=forecast_horizon,
            validation_size=validation_size,
            past_covariates=past_covariates,
            future_covariates=future_covariates,
            n_jobs=n_jobs,
            roll_size=roll_size,
            num_samples=num_samples,
            num_loader_workers=num_loader_workers,
            mc_dropout=mc_dropout,
            *args, **kwargs
        )
        self.model = model
        self.hidden_dim = hidden_dim
        self.n_rnn_layers = n_rnn_layers
        self.hidden_fc_sizes = hidden_fc_sizes
        self.dropout = dropout


class DartsLSTM(DartsPastCovariatesTorchModel):
    model: LSTMModel
    model_config: DartsLstmConfig
    model_class: Type[LSTMModel] = LSTMModel
