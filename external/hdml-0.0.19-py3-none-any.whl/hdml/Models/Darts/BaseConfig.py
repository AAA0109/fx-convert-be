from abc import ABC
from pathlib import Path
from typing import Dict, Any, Optional, List

from hdml.Models.ForecasterConfig import ForecasterConfig


class DartsConfig(ForecasterConfig, ABC):
    def __init__(
            self,
            # FitConfig
            model_name: str,
            work_dir: Path,
            task: str,
            input_chunk_length: int,
            output_chunk_length: int,
            # TunningConfig
            tunner_on: Optional[bool] = False,
            hypertunner_config: Optional[dict] = None,
            # DartsConfig
            lower_cutoff: Optional[float] = None,
            upper_cutoff: Optional[float] = None,

            *args, **kwargs
    ):
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            tunner_on=tunner_on,
            hypertunner_config=hypertunner_config,
            *args, **kwargs
        )
        self.lower_cutoff = lower_cutoff
        self.upper_cutoff = upper_cutoff

    def training_params(self) -> Dict[str, Any]:
        """
        This function is used to do training params adjustment.
        :return: dictionary that is ready to be passed to model kwargs
        """
        return self.remove_attrs_from_dict(
            dict_=self.to_dict(),
            list_=["task", "lower_cutoff", "upper_cutoff",
                   "tunner_on", "hypertunner_config"]
        )

    def loading_params(self) -> Dict[str, Any]:
        """
        This function is used to do loading params adjustment.
        :return: dictionary that is ready to be passed to model kwargs
        """
        dict_ = self.get_attrs("work_dir", "model_name")
        dict_["work_dir"] = str(dict_["work_dir"])
        dict_["best"] = True
        return dict_


class DartsTorchForecastingModelConfig(DartsConfig, ABC):
    def __init__(
            self,
            # FitConfig
            model_name: str,
            work_dir: Path,
            task: str,
            input_chunk_length: int,
            output_chunk_length: int,
            # TunningConfig
            tunner_on: Optional[bool] = False,
            hypertunner_config: Optional[dict] = None,
            # DartsConfig
            lower_cutoff: Optional[float] = None,
            upper_cutoff: Optional[float] = None,
            # DartsTorchForecastingModelConfig
            batch_size: int = 32,
            n_epochs: int = 100,
            log_tensorboard: bool = False,
            nr_epochs_val_period: int = 1,
            force_reset: bool = False,
            save_checkpoints: bool = False,
            add_encoders: Optional[dict] = None,
            random_state: Optional[int] = None,
            pl_trainer_kwargs: Optional[dict] = None,
            show_warnings: bool = False,

            *args, **kwargs
    ):
        """
        reference: darts.models.forecasting.TorchForecastingModel
        Duplicate parameter in FitConfig and TorchForecastingModel
            model_name: str = None,
            work_dir: str = os.path.join(os.getcwd(), DEFAULT_DARTS_FOLDER),
        """
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            tunner_on=tunner_on,
            hypertunner_config=hypertunner_config,
        )
        self.batch_size = batch_size
        self.n_epochs = n_epochs
        self.log_tensorboard = log_tensorboard
        self.nr_epochs_val_period = nr_epochs_val_period
        self.force_reset = force_reset
        self.save_checkpoints = save_checkpoints
        self.add_encoders = add_encoders
        self.random_state = random_state
        self.pl_trainer_kwargs = pl_trainer_kwargs
        self.show_warnings = show_warnings


class DartsPastCovariatesTorchModelConfig(DartsTorchForecastingModelConfig, ABC):
    def __init__(
            self,
            # FitConfig
            model_name: str,
            work_dir: Path,
            task: str,
            input_chunk_length: int,
            output_chunk_length: int,
            # TunningConfig
            tunner_on: Optional[bool] = False,
            hypertunner_config: Optional[dict] = None,
            # DartsConfig
            lower_cutoff: Optional[float] = None,
            upper_cutoff: Optional[float] = None,
            # DartsTorchForecastingModelConfig
            batch_size: int = 800,  # darts default: 32
            n_epochs: int = 2,  # darts default: 100
            log_tensorboard: bool = False,
            nr_epochs_val_period: int = 1,
            force_reset: bool = True,  # darts default: False
            save_checkpoints: bool = True,  # darts default: False
            add_encoders: Optional[dict] = None,
            random_state: Optional[int] = None,
            pl_trainer_kwargs: Optional[dict] = None,
            show_warnings: bool = False,
            # DartsPastCovariatesTorchModelConfig
            forecast_horizon: int = 1,
            validation_size: float = 0.3,
            past_covariates: List[str] = None,
            future_covariates: List[str] = None,
            n_jobs: int = 1,
            roll_size: Optional[int] = None,
            num_samples: int = 1,
            num_loader_workers: int = 0,
            mc_dropout: bool = False,

            *args, **kwargs
    ):
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            tunner_on=tunner_on,
            hypertunner_config=hypertunner_config,
            lower_cutoff=lower_cutoff,
            upper_cutoff=upper_cutoff,
            batch_size=batch_size,
            n_epochs=n_epochs,
            log_tensorboard=log_tensorboard,
            nr_epochs_val_period=nr_epochs_val_period,
            force_reset=force_reset,
            save_checkpoints=save_checkpoints,
            add_encoders=add_encoders,
            random_state=random_state,
            pl_trainer_kwargs=pl_trainer_kwargs,
            show_warnings=show_warnings,
            *args, **kwargs
        )
        # predict params
        self.forecast_horizon = forecast_horizon
        self.validation_size = validation_size
        self.past_covariates = past_covariates
        self.future_covariates = future_covariates
        self.n_jobs = n_jobs
        self.roll_size = roll_size
        self.num_samples = num_samples
        self.num_loader_workers = num_loader_workers
        self.mc_dropout = mc_dropout

    def training_params(self) -> Dict[str, Any]:
        return self.remove_attrs_from_dict(
            dict_=super().training_params(),
            list_=["forecast_horizon", "validation_size", "past_covariates", "future_covariates", "n_jobs",
                   "roll_size", "num_samples", "num_loader_workers", "mc_dropout"]
        )
