import abc
import logging
from abc import ABC, abstractmethod

import pandas as pd

from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class MlAlgo(metaclass=abc.ABCMeta):
    """
    Abstract machine learning algorithm. We wrap many different ML libraries, with different interfaces,
    so this is used to indicate that we have some MLAlgo that we are calling under the hood.
    """

    @abstractmethod
    def predict(self, *args, **kwargs):
        """
        predict data
        :param X:
        :param kwargs:
        :return:
        """
        raise NotImplementedError

    @abstractmethod
    def fit(self, *args, **kwargs):
        """
        fit the model
        :param X:
        :param kwargs:
        :return:
        """
        raise NotImplementedError


class Forecaster(ABC):
    model: MlAlgo
    model_config: ForecasterConfig

    def __init__(self, model_config):
        """
        define model_config
        :param model_config:
        """
        self.model_config = model_config

    @abstractmethod
    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        """
        Fit the model
        :param X_fit: input data
        :param y_fit: target data
        :return:
        """
        raise NotImplementedError

    @abstractmethod
    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        Get forecast value(s)
        :param X_test: test data
        :return:
        """
        raise NotImplementedError

    def predict(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        Get forecast value(s)
        :param X_test: test data
        :return:
        """
        return self.forecast(X_test)