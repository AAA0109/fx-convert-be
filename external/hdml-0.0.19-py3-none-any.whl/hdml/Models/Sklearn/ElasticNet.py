import logging
import os
from pathlib import Path

import pandas as pd
from sklearn.linear_model import ElasticNet

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Sklearn.BaseConfig import SklearnRegressorConfig
from hdml.Models.Sklearn.BaseModel import SklearnRegressorModel
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SklearnElasticNetConfig(SklearnRegressorConfig):
    def __init__(
            self,
            model_name: str = "sklearn_elastic_net",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,

            forecast_horizon: int = 1,
            alpha: float = 1.0,
            l1_ratio: float = 0.5,
            fit_intercept: bool = True,
            normalize: str = "deprecated",
            precompute: bool = False,
            max_iter: int = 1000,
            copy_X: bool = True,
            tol: float = 1e-4,
            warm_start: bool = False,
            positive: bool = False,
            random_state: int = None,
            selection: str = "cyclic",

            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.forecast_horizon = forecast_horizon
        self.alpha = alpha
        self.l1_ratio = l1_ratio
        self.fit_intercept = fit_intercept
        self.normalize = normalize
        self.precompute = precompute
        self.max_iter = max_iter
        self.copy_X = copy_X
        self.tol = tol
        self.warm_start = warm_start
        self.positive = positive
        self.random_state = random_state
        self.selection = selection


class SklearnElasticNet(SklearnRegressorModel):
    """
    this is univariate only
    """
    model: ElasticNet
    model_config: SklearnElasticNetConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = ElasticNet(
            alpha=self.model_config.alpha,
            l1_ratio=self.model_config.l1_ratio,
            fit_intercept=self.model_config.fit_intercept,
            normalize=self.model_config.normalize,
            precompute=self.model_config.precompute,
            max_iter=self.model_config.max_iter,
            copy_X=self.model_config.copy_X,
            tol=self.model_config.tol,
            warm_start=self.model_config.warm_start,
            positive=self.model_config.positive,
            random_state=self.model_config.random_state,
            selection=self.model_config.selection,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        self.scaler_y = self._fit_scaler(y_fit)
        scaled_Y_fit = self._scale_data(y_fit, self.scaler_y)

        ts = TimeSeriesTensor(X=scaled_X_fit, y=scaled_Y_fit, lookback=self.model_config.lookback)
        flattened_X = ts.X3D.reshape(ts.X3D.shape[0], -1)
        self.model.fit(flattened_X, ts.Y3D.iloc[:, 0])
        return self._store_training_state(self.model)
