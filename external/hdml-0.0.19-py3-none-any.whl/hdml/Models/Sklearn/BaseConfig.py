from abc import ABC

from hdml.Models.Sktime.BaseConfig import SktimeConfig


class SklearnClassifierConfig(SktimeConfig, ABC):
    pass


class SklearnRegressorConfig(SktimeConfig, ABC):
    pass
