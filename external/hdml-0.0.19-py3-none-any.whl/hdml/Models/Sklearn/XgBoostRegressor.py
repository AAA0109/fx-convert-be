import logging
import os
from pathlib import Path

import pandas as pd
from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Sklearn.BaseConfig import SklearnRegressorConfig
from hdml.Models.Sklearn.BaseModel import SklearnRegressorModel
from hdml.Utils.Result import FitResult
from xgboost import XGBRegressor

logger = logging.getLogger(__name__)


class SklearnXGBRegressorRegressionConfig(SklearnRegressorConfig):
    def __init__(
            self,
            model_name: str = "sklearn_gradient_boosting_regression",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            forecast_horizon: int = 1,

            n_estimators: int = 800,
            max_depth: int = 6,
            n_jobs: int = 8,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.forecast_horizon = forecast_horizon
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.n_jobs = n_jobs


class SklearnXGBRegressorRegression(SklearnRegressorModel):
    model: XGBRegressor
    model_config: SklearnXGBRegressorRegressionConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = XGBRegressor(
            n_estimators=self.model_config.n_estimators,
            max_depth=self.model_config.max_depth,
            n_jobs=self.model_config.n_jobs,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        self.scaler_y = self._fit_scaler(y_fit)
        scaled_Y_fit = self._scale_data(y_fit, self.scaler_y)

        ts = TimeSeriesTensor(X=scaled_X_fit, y=scaled_Y_fit, lookback=self.model_config.lookback)

        flattened_X = ts.X3D.reshape(ts.X3D.shape[0], -1)
        self.model.fit(flattened_X, ts.Y3D.iloc[:, 0])
        return self._store_training_state(self.model)
