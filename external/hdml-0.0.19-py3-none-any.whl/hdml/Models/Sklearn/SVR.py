# https://www.sktime.org/en/v0.8.1/examples/rocket.html
import logging
import os
from pathlib import Path

import pandas as pd
from sklearn.svm import SVR

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Sklearn.BaseConfig import SklearnRegressorConfig
from hdml.Models.Sklearn.BaseModel import SklearnRegressorModel
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SklearnSVRConfig(SklearnRegressorConfig):
    def __init__(
            self,
            model_name: str = "sklearn_svr",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,

            forecast_horizon: int = 1,
            kernel: str = "rbf",
            degree: int = 3,
            gamma: str = "scale",
            coef0: float = 0.0,
            tol: float = 1e-3,
            C: float = 1.0,
            epsilon: float = 0.1,

            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.forecast_horizon = forecast_horizon
        self.kernel = kernel
        self.degree = degree
        self.gamma = gamma
        self.coef0 = coef0
        self.tol = tol
        self.C = C
        self.epsilon = epsilon


class SklearnSVR(SklearnRegressorModel):
    """
    this is univariate only
    """
    model: SVR
    model_config: SklearnSVRConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = SVR(
            kernel=self.model_config.kernel,
            degree=self.model_config.degree,
            gamma=self.model_config.gamma,
            coef0=self.model_config.coef0,
            tol=self.model_config.tol,
            C=self.model_config.C,
            epsilon=self.model_config.epsilon,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        self.scaler_y = self._fit_scaler(y_fit)
        scaled_Y_fit = self._scale_data(y_fit, self.scaler_y)

        ts = TimeSeriesTensor(X=scaled_X_fit, y=scaled_Y_fit, lookback=self.model_config.lookback)
        flattened_X = ts.X3D.reshape(ts.X3D.shape[0], -1)
        self.model.fit(flattened_X, ts.Y3D.iloc[:, 0])
        return self._store_training_state(self.model)
