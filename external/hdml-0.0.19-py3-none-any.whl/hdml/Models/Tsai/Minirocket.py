# https://timeseriesai.github.io/tsai/tutorials.html
# https://github.com/timeseriesAI/tsai/blob/main/tutorial_nbs/00c_Time_Series_data_preparation.ipynb
import logging
import os
from pathlib import Path

import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, make_scorer
from tsai.models.MINIROCKET import MiniRocketRegressor

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Tsai.BaseConfig import TsaiRegressorConfig
from hdml.Models.Tsai.BaseModel import TsaiRegressorModel

logger = logging.getLogger(__name__)


class TsaiMiniRocketConfig(TsaiRegressorConfig):
    def __init__(
            self,
            model_name: str = "tsai_minirocket",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            n_features: int = None,
            n_epochs: int = 2,
            max_dilations_per_kernel: int = 32,
            num_features: int = 10000,
            random_state=None,
            alphas: np.array = np.logspace(-3, 3, 7),
            normalize_features=True,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.n_epochs = n_epochs
        self.n_features = n_features
        self.num_features = num_features
        self.max_dilations_per_kernel = max_dilations_per_kernel
        self.random_state = random_state
        self.alphas = alphas
        self.normalize_features = normalize_features


class TsaiMiniRocket(TsaiRegressorModel):
    """
    can handle uni/multi-variate, single/multi-steps horizon
    """
    model: MiniRocketRegressor
    model_config: TsaiMiniRocketConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame):
        rmse_scorer = make_scorer(mean_squared_error, greater_is_better=False)
        self.model = MiniRocketRegressor(
            scoring=rmse_scorer,
            num_features=self.model_config.num_features,
            max_dilations_per_kernel=self.model_config.max_dilations_per_kernel,
            random_state=self.model_config.random_state,
            alphas=self.model_config.alphas,
            normalize_features=self.model_config.normalize_features,
        )

        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        self.scaler_y = self._fit_scaler(y_fit)
        scaled_Y_fit = self._scale_data(y_fit, self.scaler_y)

        ts = TimeSeriesTensor(X=scaled_X_fit, y=scaled_Y_fit, lookback=self.model_config.lookback,
                              order_of_3D_array="SFL")

        # https: // github.com / timeseriesAI / tsai / discussions / 149
        self.model.fit(X=ts.X3D, y=ts.Y3D)
        return self._store_training_state(self.model)
