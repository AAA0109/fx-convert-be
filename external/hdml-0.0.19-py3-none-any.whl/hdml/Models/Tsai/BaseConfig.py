from abc import ABC

from hdml.Models.Sktime.BaseConfig import SktimeConfig


class TsaiClassifierConfig(SktimeConfig, ABC):
    pass


class TsaiRegressorConfig(SktimeConfig, ABC):
    pass
