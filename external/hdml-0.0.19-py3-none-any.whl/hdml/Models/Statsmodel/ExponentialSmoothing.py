import logging
import os
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.tsa.holtwinters import SimpleExpSmoothing

from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Models.Statsmodel.BaseModel import StatsmodelForecaster

logger = logging.getLogger(__name__)
warnings.filterwarnings("ignore")


class StatsmodelEsConfig(ForecasterConfig):
    def __init__(
            self,
            model_name: str = "statsmodel_es",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            n_features: int = None,
            batch_size: int = None,
            epochs: int = 2,
            verbose: int = 1,
            threshold: float = 0.5,

            # new params
            endog: np.ndarray = [],
            initialization_method: str = 'estimated',
            initial_level: float = None,

            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            *args, **kwargs
        )
        self.input_chunk_length = input_chunk_length
        self.output_chunk_length = output_chunk_length
        self.batch_size = batch_size
        self.epochs = epochs
        self.verbose = verbose
        self.n_features = n_features
        self.threshold = threshold

        self.endog = endog
        self.initialization_method = initialization_method
        self.initial_level = initial_level

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class StatsmodelEs(StatsmodelForecaster):
    model: SimpleExpSmoothing
    model_config: StatsmodelEsConfig

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:

        try:
            test_series = X_test.iloc[:, 0]

            forecasts = {"date": [], "forecast": []}

            for i in range(len(test_series) - 1, len(test_series)):

                if i == len(test_series) - 1:
                    ts_history = test_series.copy()
                else:
                    ts_history = test_series.iloc[:i]

                es = SimpleExpSmoothing(ts_history)
                model = es.fit(smoothing_level=0.99, optimized=False)
                forecast = model.forecast(steps=self.model_config.output_chunk_length)

                if np.isnan(forecast.values).any():
                    raise RuntimeError("forecast failed probably because of nan value!")

                forecasts["forecast"].append(forecast.values[0])
                forecasts["date"].append(ts_history.index[-1])
            forecasts = pd.DataFrame(forecasts)

        except:
            raise RuntimeError("pred_series fails!")

        return forecasts

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame):

        X_fit_es = X_fit.iloc[:, 0]

        self.model = SimpleExpSmoothing(
            endog=X_fit_es,
            initialization_method=self.model_config.initialization_method,
            initial_level=self.model_config.initial_level,
        )

        self.model.fit()

        return self._store_training_state(self.model)

    # =============PRIVATE METHODS================
    @staticmethod
    def _to_timeseries(ts_test: pd.DataFrame) -> pd.Series:
        ts_series = ts_test.copy()
        ts_series.reset_index(inplace=True)
        ts_series.reset_index(inplace=True)
        ts_series["date_str"] = ts_series["date"].dt.strftime('%Y-%m-%d').copy()
        ts_series.set_index('date', inplace=True)
        ts_series = ts_series.loc[:, ts_test.values]
        return ts_series
