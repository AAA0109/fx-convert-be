import logging

from hdml.Models.Forecaster import Forecaster
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class StatsmodelForecaster(Forecaster):
    # =============PRIVATE METHODS================
    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training process
        feel free to extend with super() or replace this method
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()
        fit_results.fit_instance = fr
        fit_results.criterion = "str(fr.model.criterion)"
        fit_results.best_model_path = "str(fr.trainer.checkpoint_callback.best_model_path)"
        return fit_results
