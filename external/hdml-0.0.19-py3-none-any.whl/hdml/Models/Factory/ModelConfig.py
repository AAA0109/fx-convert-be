from typing import Type

from hdml.Models.ForecasterConfig import ForecasterConfig


class ModelConfigFactory:

    @staticmethod
    def config(model_name: str) -> Type[ForecasterConfig]:
        """
        return model config given model_name
        :param model_name: model name, e.g. darts_nbeats
        :return:
        """
        # darts
        if model_name == "darts_nbeats":
            from hdml.Models.Darts.Nbeats import DartsNbeatsConfig
            return DartsNbeatsConfig
        elif model_name == "darts_nhits":
            from hdml.Models.Darts.Nhits import DartsNhitsConfig
            return DartsNhitsConfig
        elif model_name == "darts_rnn":
            from hdml.Models.Darts.Rnn import DartsRnnConfig
            return DartsRnnConfig
        elif model_name == "darts_lstm":
            from hdml.Models.Darts.Lstm import DartsLstmConfig
            return DartsLstmConfig
        elif model_name == "darts_tcn":
            from hdml.Models.Darts.Tcn import DartsTcnConfig
            return DartsTcnConfig
        elif model_name == "darts_lightgbm":
            from hdml.Models.Darts.Lightgbm import DartsLightGBMConfig
            return DartsLightGBMConfig
        elif model_name == "darts_tft":
            from hdml.Models.Darts.Tft import DartsTFTConfig
            return DartsTFTConfig
        elif model_name == "darts_transformer":
            from hdml.Models.Darts.Transformer import DartsTransformerConfig
            return DartsTransformerConfig
        elif model_name == "darts_theta":
            from hdml.Models.Darts.Theta import DartsThetaConfig
            return DartsThetaConfig
        elif model_name == "darts_linearregression":
            from hdml.Models.Darts.Linearregression import DartsLinearRegressionConfig
            return DartsLinearRegressionConfig
        elif model_name == "darts_randomforest":
            from hdml.Models.Darts.Randomforest import DartsRandomforestConfig
            return DartsRandomforestConfig
        elif model_name == "darts_es":
            from hdml.Models.Darts.Es import DartsESConfig
            return DartsESConfig
        elif model_name == "darts_autoarima":
            from hdml.Models.Darts.Autoarima import DartsAutoarimaConfig
            return DartsAutoarimaConfig
        # tensorflow
        elif model_name == "tf_classification":
            from hdml.Models.TensorFlow.Classification import TfClassificationConfig
            return TfClassificationConfig
        elif model_name == "tf_regression":
            from hdml.Models.TensorFlow.Regression import TfRegressionConfig
            return TfRegressionConfig
        elif model_name == "tf_regression_one_shot":
            from hdml.Models.TensorFlow.RegressionOneshot import TfRegressionOneShotConfig
            return TfRegressionOneShotConfig
        # statsmodel
        elif model_name == "statsmodel_es":
            from hdml.Models.Statsmodel.ExponentialSmoothing import StatsmodelEsConfig
            return StatsmodelEsConfig
        # Sktime
        elif model_name == "sktime_rocket_regressor":
            from hdml.Models.Sktime.RocketRegressor import SktimeRocketRegressorConfig
            return SktimeRocketRegressorConfig
        elif model_name == "sktime_rocket":
            from hdml.Models.Sktime.Rocket import SktimeRocketConfig
            return SktimeRocketConfig
        elif model_name == "sktime_arsenal":
            from hdml.Models.Sktime.Arsenal import SktimeArsenalConfig
            return SktimeArsenalConfig
        elif model_name == "sktime_muse":
            from hdml.Models.Sktime.Muse import SktimeMuseConfig
            return SktimeMuseConfig
        elif model_name == "sktime_autoets":
            from hdml.Models.Sktime.AutoEts import SktimeAutoETSConfig
            return SktimeAutoETSConfig
        elif model_name == "sktime_prophet":
            from hdml.Models.Sktime.Prophet import SktimeProphetConfig
            return SktimeProphetConfig
        elif model_name == "sktime_autoarima":
            from hdml.Models.Sktime.AutoArima import SktimeAutoARIMAConfig
            return SktimeAutoARIMAConfig
        # sklearn
        elif model_name == "sklearn_gradient_boosting_regression":
            from hdml.Models.Sklearn.GradientBoostingRegression import SklearnGradientBoostingRegressionConfig
            return SklearnGradientBoostingRegressionConfig
        elif model_name == "sklearn_svr":
            from hdml.Models.Sklearn.SVR import SklearnSVRConfig
            return SklearnSVRConfig
        elif model_name == "sklearn_kernel_ridge":
            from hdml.Models.Sklearn.KernelRidge import SklearnKernelRidgeConfig
            return SklearnKernelRidgeConfig
        elif model_name == "sklearn_lgbm_regression":
            from hdml.Models.Sklearn.LgbmRegression import SklearnLgbmRegressionConfig
            return SklearnLgbmRegressionConfig
        elif model_name == "sklearn_elastic_net":
            from hdml.Models.Sklearn.ElasticNet import SklearnElasticNetConfig
            return SklearnElasticNetConfig
        elif model_name == "sklearn_xgboost_regression":
            from hdml.Models.Sklearn.XgBoostRegressor import SklearnXGBRegressorRegressionConfig
            return SklearnXGBRegressorRegressionConfig
        # tsai
        elif model_name == "tsai_minirocket":
            from hdml.Models.Tsai.Minirocket import TsaiMiniRocketConfig
            return TsaiMiniRocketConfig
        else:
            raise ValueError(f"model_name {model_name} not supported")
