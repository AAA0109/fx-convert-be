from hdml.Models.Forecaster import Forecaster
from hdml.Models.ForecasterConfig import ForecasterConfig
from abc import ABC, abstractmethod


class BaseModelFactory(ABC):
    @abstractmethod
    def model(self) -> Forecaster:
        raise NotImplementedError


class ModelFactory(BaseModelFactory):
    def __init__(self, model_config: ForecasterConfig):
        """

        :param model_config: model config
        """
        self._model_config: ForecasterConfig = model_config

    def model(self) -> Forecaster:
        """
        return forecaster model given model_config
        :return: Forecaster
        """
        model_config = self._model_config
        # darts
        if model_config.model_name == "darts_nbeats":
            from hdml.Models.Darts.Nbeats import DartsNbeats
            return DartsNbeats(model_config=model_config)
        elif model_config.model_name == "darts_nhits":
            from hdml.Models.Darts.Nhits import DartsNhits
            return DartsNhits(model_config=model_config)
        elif model_config.model_name == "darts_rnn":
            from hdml.Models.Darts.Rnn import DartsRNN
            return DartsRNN(model_config=model_config)
        elif model_config.model_name == "darts_lstm":
            from hdml.Models.Darts.Lstm import DartsLSTM
            return DartsLSTM(model_config=model_config)
        elif model_config.model_name == "darts_tcn":
            from hdml.Models.Darts.Tcn import DartsTCN
            return DartsTCN(model_config=model_config)
        elif model_config.model_name == "darts_lightgbm":
            from hdml.Models.Darts.Lightgbm import DartsLightGBM
            return DartsLightGBM(model_config=model_config)
        elif model_config.model_name == "darts_tft":
            from hdml.Models.Darts.Tft import DartsTFT
            return DartsTFT(model_config=model_config)
        elif model_config.model_name == "darts_transformer":
            from hdml.Models.Darts.Transformer import DartsTransformer
            return DartsTransformer(model_config=model_config)
        elif model_config.model_name == "darts_theta":
            from hdml.Models.Darts.Theta import DartsTheta
            return DartsTheta(model_config=model_config)
        elif model_config.model_name == "darts_linearregression":
            from hdml.Models.Darts.Linearregression import DartsLinearRegression
            return DartsLinearRegression(model_config=model_config)
        elif model_config.model_name == "darts_randomforest":
            from hdml.Models.Darts.Randomforest import DartsRandomForest
            return DartsRandomForest(model_config=model_config)
        elif model_config.model_name == "darts_es":
            from hdml.Models.Darts.Es import DartsES
            return DartsES(model_config=model_config)
        elif model_config.model_name == "darts_autoarima":
            from hdml.Models.Darts.Autoarima import DartsAutoarima
            return DartsAutoarima(model_config=model_config)
        # tensorflow
        elif model_config.model_name == "tf_classification":
            from hdml.Models.TensorFlow.Classification import TfClassification
            return TfClassification(model_config=model_config)
        elif model_config.model_name == "tf_regression":
            from hdml.Models.TensorFlow.Regression import TfRegression
            return TfRegression(model_config=model_config)
        elif model_config.model_name == "tf_regression_one_shot":
            from hdml.Models.TensorFlow.RegressionOneshot import TfRegressionOneShot
            return TfRegressionOneShot(model_config=model_config)
        # statsmodel
        elif model_config.model_name == "statsmodel_es":
            from hdml.Models.Statsmodel.ExponentialSmoothing import StatsmodelEs
            return StatsmodelEs(model_config=model_config)
        # Sktime
        elif model_config.model_name == "sktime_rocket_regressor":
            from hdml.Models.Sktime.RocketRegressor import SktimeRocketRegressor
            return SktimeRocketRegressor(model_config=model_config)
        elif model_config.model_name == "sktime_rocket":
            from hdml.Models.Sktime.Rocket import SktimeRocket
            return SktimeRocket(model_config=model_config)
        elif model_config.model_name == "sktime_arsenal":
            from hdml.Models.Sktime.Arsenal import SktimeArsenal
            return SktimeArsenal(model_config=model_config)
        elif model_config.model_name == "sktime_muse":
            from hdml.Models.Sktime.Muse import SktimeMuse
            return SktimeMuse(model_config=model_config)
        elif model_config.model_name == "sktime_autoets":
            from hdml.Models.Sktime.AutoEts import SktimeAutoETS
            return SktimeAutoETS(model_config=model_config)
        elif model_config.model_name == "sktime_prophet":
            from hdml.Models.Sktime.Prophet import SktimeProphet
            return SktimeProphet(model_config=model_config)
        elif model_config.model_name == "sktime_autoarima":
            from hdml.Models.Sktime.AutoArima import SktimeAutoARIMA
            return SktimeAutoARIMA(model_config=model_config)
        # sklearn
        elif model_config.model_name == "sklearn_gradient_boosting_regression":
            from hdml.Models.Sklearn.GradientBoostingRegression import SklearnGradientBoostingRegression
            return SklearnGradientBoostingRegression(model_config=model_config)
        elif model_config.model_name == "sklearn_svr":
            from hdml.Models.Sklearn.SVR import SklearnSVR
            return SklearnSVR(model_config=model_config)
        elif model_config.model_name == "sklearn_kernel_ridge":
            from hdml.Models.Sklearn.KernelRidge import SklearnKernelRidge
            return SklearnKernelRidge(model_config=model_config)
        elif model_config.model_name == "sklearn_lgbm_regression":
            from hdml.Models.Sklearn.LgbmRegression import SklearnLgbmRegression
            return SklearnLgbmRegression(model_config=model_config)
        elif model_config.model_name == "sklearn_elastic_net":
            from hdml.Models.Sklearn.ElasticNet import SklearnElasticNet
            return SklearnElasticNet(model_config=model_config)
        elif model_config.model_name == "sklearn_xgboost_regression":
            from hdml.Models.Sklearn.XgBoostRegressor import SklearnXGBRegressorRegression
            return SklearnXGBRegressorRegression(model_config=model_config)
        # tsai
        elif model_config.model_name == "tsai_minirocket":
            from hdml.Models.Tsai.Minirocket import TsaiMiniRocket
            return TsaiMiniRocket(model_config=model_config)
        else:
            raise ValueError("Model not found")
