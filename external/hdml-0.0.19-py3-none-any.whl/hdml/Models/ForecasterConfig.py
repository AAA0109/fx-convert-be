from abc import ABC
from pathlib import Path
from typing import Optional

from hdml.Utils.Config import BaseConfig


class ForecasterConfig(BaseConfig, ABC):
    def __init__(
            self,
            # FitConfig
            model_name: str,
            work_dir: Path,
            task: str,
            input_chunk_length: int,
            output_chunk_length: int,
            # TunningConfig
            tunner_on: Optional[bool] = False,
            hypertunner_config: Optional[dict] = None,

            *args, **kwargs
    ):
        super().__init__(*args, **kwargs)
        self.model_name = model_name
        self.work_dir = work_dir
        if task not in ("C", "R"):
            raise ValueError(
                "task is either 'C' for classification or 'R' for regression")
        self.task = task
        self.input_chunk_length = input_chunk_length
        self.output_chunk_length = output_chunk_length
        self.tunner_on = tunner_on
        self.hypertunner_config = hypertunner_config

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length
