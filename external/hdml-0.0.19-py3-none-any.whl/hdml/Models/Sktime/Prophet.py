import logging
import os
from pathlib import Path

import pandas as pd
from sktime.datatypes._panel._convert import from_2d_array_to_nested
from sktime.forecasting.base._base import DEFAULT_ALPHA
from sktime.forecasting.fbprophet import Prophet

from hdml.Models.Sktime.BaseModel import SktimeClassifierModel
from hdml.Models.Sktime.BaseModel import SktimeClassifierConfig
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SktimeProphetConfig(SktimeClassifierConfig):
    def __init__(
            self,
            model_name: str = "sktime_prophet",
            work_dir: Path = os.getcwd(),
            task: str = "C",
            threshold: float = 0.5,
            # Args due to wrapping
            freq=None,
            add_seasonality=None,
            add_country_holidays=None,
            # Args of fbprophet
            growth="linear",
            growth_floor=0.0,
            growth_cap=None,
            changepoints=None,
            n_changepoints=25,
            changepoint_range=0.8,
            yearly_seasonality="auto",
            weekly_seasonality="auto",
            daily_seasonality="auto",
            holidays=None,
            seasonality_mode="additive",
            seasonality_prior_scale=10.0,
            holidays_prior_scale=10.0,
            changepoint_prior_scale=0.05,
            mcmc_samples=0,
            alpha=DEFAULT_ALPHA,
            uncertainty_samples=1000,
            stan_backend=None,
            verbose=0,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            *args, **kwargs
        )
        self.freq = freq
        self.add_seasonality = add_seasonality
        self.add_country_holidays = add_country_holidays
        self.threshold = threshold

        self.growth = growth
        self.growth_floor = growth_floor
        self.growth_cap = growth_cap
        self.changepoints = changepoints
        self.n_changepoints = n_changepoints
        self.changepoint_range = changepoint_range
        self.yearly_seasonality = yearly_seasonality
        self.weekly_seasonality = weekly_seasonality
        self.daily_seasonality = daily_seasonality
        self.holidays = holidays
        self.seasonality_mode = seasonality_mode
        self.seasonality_prior_scale = seasonality_prior_scale
        self.changepoint_prior_scale = changepoint_prior_scale
        self.holidays_prior_scale = holidays_prior_scale
        self.mcmc_samples = mcmc_samples
        self.alpha = alpha
        self.uncertainty_samples = uncertainty_samples
        self.stan_backend = stan_backend
        self.verbose = verbose

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class SktimeProphet(SktimeClassifierModel):
    model: Prophet
    model_config: SktimeProphetConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = Prophet(
            freq=self.model_config.freq,
            add_seasonality=self.model_config.add_seasonality,
            add_country_holidays=self.model_config.add_country_holidays,
            # Args of fbprophet
            growth=self.model_config.growth,
            growth_floor=self.model_config.growth_floor,
            growth_cap=self.model_config.growth_cap,
            changepoints=self.model_config.changepoints,
            n_changepoints=self.model_config.n_changepoints,
            changepoint_range=self.model_config.changepoint_range,
            yearly_seasonality=self.model_config.yearly_seasonality,
            weekly_seasonality=self.model_config.weekly_seasonality,
            daily_seasonality=self.model_config.daily_seasonality,
            holidays=self.model_config.holidays,
            seasonality_mode=self.model_config.seasonality_mode,
            seasonality_prior_scale=self.model_config.seasonality_prior_scale,
            holidays_prior_scale=self.model_config.holidays_prior_scale,
            changepoint_prior_scale=self.model_config.changepoint_prior_scale,
            mcmc_samples=self.model_config.mcmc_samples,
            alpha=self.model_config.alpha,
            uncertainty_samples=self.model_config.uncertainty_samples,
            stan_backend=self.model_config.stan_backend,
            verbose=self.model_config.verbose,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        scaled_X_fit_nested = from_2d_array_to_nested(scaled_X_fit)
        self.model.fit(scaled_X_fit_nested)
        return self._store_training_state(self.model)

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        :param X_test:
        :return:
            forecasts : pandas.DataFrame
                Index:
                    reference_time (prediction time)
                Columns:
                    Name: forecast, dtype: pd.DataFrame
                        Index:
                            horizon_time
                        Columns:
                            Name: <forecasted times series>, dtype: float64
                            Name: <forecasted times series 2>, dtype: float64
                            ....
                            Name: <forecasted times series n>, dtype: float64
        """
        # try:
        scaled_X_fit = self._scale_data(X_test, self.scaler_x)
        scaled_X_fit_nested = from_2d_array_to_nested(scaled_X_fit)
        fh = len(scaled_X_fit_nested)-1 # ajust size for fh, or will be error about out of range
        # not sure: need fit before using predict_interval for changing len(self.forecasters_.index)
        forecast = self.model.fit(scaled_X_fit_nested)
        coverage = 0.9
        # output are lower bound and upper bound value
        forecast_values = self.model.predict_interval(fh=fh, X=scaled_X_fit_nested,coverage=coverage)['Coverage'][coverage]
        forecast_values = pd.DataFrame(forecast_values, index=X_test.index)
        forecasts = {"reference_date": [], "forecast": []}
        for index, row in forecast_values.iterrows():
            datum = row.to_frame().T
            datum.index += pd.tseries.offsets.BDay(1)
            # count mean of lower and upper
            forecast_value = ((datum["lower"]+datum["upper"])/2)[0]
            # check if you are trying to forecast "Saturday" or "Sunday"
            if any(elem in set(datum.index.day_name().to_list()) for elem in ["Saturday", "Sunday"]):
                logger.warning("you are trying to forecast Saturday or Sunday")

            forecasts["reference_date"].append(index)
            forecasts["forecast"].append(forecast_value)
        forecasts = pd.DataFrame(forecasts)
        forecasts.set_index("reference_date", inplace=True)
        forecasts.sort_index(inplace=True)
        # except:
        #     raise RuntimeError("forecast fails!")
        return forecasts
