from abc import ABC
from pathlib import Path

from hdml.Models.ForecasterConfig import ForecasterConfig


class SktimeConfig(ForecasterConfig, ABC):

    def __init__(
            self,
            model_name: str,
            work_dir: Path,
            task: str,
            input_chunk_length: int,
            output_chunk_length: int,
            *args, **kwargs
    ):
        super().__init__(
            model_name=model_name,
            work_dir=work_dir,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )


class SktimeClassifierConfig(SktimeConfig, ABC):
    pass


class SktimeRegressorConfig(SktimeConfig, ABC):
    pass
