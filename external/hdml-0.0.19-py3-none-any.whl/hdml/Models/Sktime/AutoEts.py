import logging
import os
from pathlib import Path

import pandas as pd
from hdlib.DateTime.Date import Date
from sktime.datatypes._panel._convert import from_2d_array_to_nested
from sktime.forecasting.ets import AutoETS

from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Models.Sktime.BaseModel import SktimeForecaster
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SktimeAutoETSConfig(ForecasterConfig):
    def __init__(
            self,
            model_name: str = "sktime_autoets",
            work_dir: Path = os.getcwd(),
            task: str = "C",
            threshold: float = 0.5,
            error="add",
            trend=None,
            damped_trend=False,
            seasonal=None,
            sp=1,
            initialization_method="estimated",
            initial_level=None,
            initial_trend=None,
            initial_seasonal=None,
            bounds=None,
            dates=None,
            freq=None,
            missing="none",
            start_params=None,
            maxiter=1000,
            full_output=True,
            disp=False,
            callback=None,
            return_params=False,
            auto=False,
            information_criterion="aic",
            allow_multiplicative_trend=False,
            restrict=True,
            additive_only=False,
            ignore_inf_ic=True,
            n_jobs=None,
            random_state=None,
            *args, **kwargs
    ):
        self.threshold = threshold
        # Model params
        self.error = error
        self.trend = trend
        self.damped_trend = damped_trend
        self.seasonal = seasonal
        self.sp = sp
        self.initialization_method = initialization_method
        self.initial_level = initial_level
        self.initial_trend = initial_trend
        self.initial_seasonal = initial_seasonal
        self.bounds = bounds
        self.dates = dates
        self.freq = freq
        self.missing = missing

        # Fit params
        self.start_params = start_params
        self.maxiter = maxiter
        self.full_output = full_output
        self.disp = disp
        self.callback = callback
        self.return_params = return_params
        self.information_criterion = information_criterion
        self.auto = auto
        self.allow_multiplicative_trend = allow_multiplicative_trend
        self.restrict = restrict
        self.additive_only = additive_only
        self.ignore_inf_ic = ignore_inf_ic
        self.n_jobs = n_jobs
        self.random_state = random_state

        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            *args, **kwargs
        )

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class SktimeAutoETS(SktimeForecaster):
    model: AutoETS
    model_config: SktimeAutoETSConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = AutoETS(
            error=self.model_config.error,
            trend=self.model_config.trend,
            damped_trend=self.model_config.damped_trend,
            seasonal=self.model_config.seasonal,
            sp=self.model_config.sp,
            initialization_method=self.model_config.initialization_method,
            initial_level=self.model_config.initial_level,
            initial_trend=self.model_config.trend,
            initial_seasonal=self.model_config.initial_seasonal,
            bounds=self.model_config.bounds,
            dates=self.model_config.dates,
            freq=self.model_config.freq,
            missing=self.model_config.missing,
            start_params=self.model_config.start_params,
            maxiter=self.model_config.maxiter,
            full_output=self.model_config.full_output,
            disp=self.model_config.disp,
            callback=self.model_config.callback,
            return_params=self.model_config.return_params,
            auto=self.model_config.auto,
            information_criterion=self.model_config.information_criterion,
            allow_multiplicative_trend=self.model_config.allow_multiplicative_trend,
            restrict=self.model_config.restrict,
            additive_only=self.model_config.additive_only,
            ignore_inf_ic=self.model_config.ignore_inf_ic,
            n_jobs=self.model_config.n_jobs,
            random_state=self.model_config.random_state,
        )
        # convert DataFrame to sktime format
        X_fit_sktime = from_2d_array_to_nested(X_fit)
        
        # extract labels from data
        y_fit_sktime = y_fit.iloc[:, -1]

        self.model.fit(X_fit_sktime, y_fit_sktime)

        return self._store_training_state(self.model)

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        Forecast given time series and date
        convertion into sktime nested data can be refered in the following link
        https://www.sktime.org/en/v0.8.2/api_reference/auto_generated/sktime.datatypes._panel._convert.from_3d_numpy_to_nested.html
        :param ts_test:
        :param date:
        :return:
        """
        try:
            # todo reshape X
            forecasts = self.model.predict_proba(from_2d_array_to_nested(X_test))[:, 1]
            if self.model_config.threshold is not None:
                forecasts = (forecasts >= self.model_config.threshold).astype(int)
            forecasts = pd.DataFrame(forecasts, index=X_test.index)
            forecasts.columns = ["forecast"]
        except:
            raise RuntimeError("forecast fails!")
        return self._final_forecast_process(forecasts.reset_index(), forecast_date)
