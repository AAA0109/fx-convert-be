import logging
import os
from pathlib import Path
from typing import Optional

import pandas as pd
from sktime.classification.dictionary_based import MUSE
from sktime.datatypes._panel._convert import from_2d_array_to_nested

from hdml.Models.Sktime.BaseConfig import SktimeClassifierConfig
from hdml.Models.Sktime.BaseModel import SktimeClassifierModel
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SktimeMuseConfig(SktimeClassifierConfig):
    def __init__(
            self,
            model_name: str = "sktime_muse",
            work_dir: Path = os.getcwd(),
            task: str = "C",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            n_features: int = None,
            batch_size: int = None,
            epochs: int = 2,
            verbose: int = 1,
            threshold: float = 0.5,

            anova: bool = True,
            bigrams: bool = True,
            window_inc: int = 2,
            p_threshold: float = 0.05,
            use_first_order_differences: bool = True,
            n_jobs: int = 1,
            random_state: Optional[int] = None,

            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.input_chunk_length = input_chunk_length
        self.output_chunk_length = output_chunk_length
        self.batch_size = batch_size
        self.epochs = epochs
        self.verbose = verbose
        self.n_features = n_features
        self.threshold = threshold

        self.anova = anova
        self.bigrams = bigrams
        self.window_inc = window_inc
        self.p_threshold = p_threshold
        self.use_first_order_differences = use_first_order_differences
        self.n_jobs = n_jobs
        self.random_state = random_state

    @property
    def lookback(self) -> int:
        return self.input_chunk_length

    @property
    def lookahead(self) -> int:
        return self.output_chunk_length


class SktimeMuse(SktimeClassifierModel):
    """
        MUSE (MUltivariate Symbolic Extension).

        ref: https://www.sktime.org/en/v0.13.2/api_reference/auto_generated/sktime.classification.dictionary_based.MUSE.html

        Also known as WEASLE-MUSE: implementation of multivariate version of WEASEL,
        referred to as just MUSE from [1].

        Overview: Input n series length m
        WEASEL+MUSE is a multivariate  dictionary classifier that builds a
        bag-of-patterns using SFA for different window lengths and learns a
        logistic regression classifier on this bag.

        There are these primary parameters:
                alphabet_size: alphabet size
                chi2-threshold: used for feature selection to select best words
                anova: select best l/2 fourier coefficients other than first ones
                bigrams: using bigrams of SFA words
                binning_strategy: the binning strategy used to disctrtize into
                                SFA words.

        Parameters
        ----------
        anova: boolean, default=True
            If True, the Fourier coefficient selection is done via a one-way
            ANOVA test. If False, the first Fourier coefficients are selected.
            Only applicable if labels are given
        bigrams: boolean, default=True
            whether to create bigrams of SFA words
        window_inc: int, default=2
            WEASEL create a BoP model for each window sizes. This is the
            increment used to determine the next window size.
        p_threshold: int, default=0.05 (disabled by default)
            Feature selection is applied based on the chi-squared test.
            This is the p-value threshold to use for chi-squared test on bag-of-words
            (lower means more strict). 1 indicates that the test
            should not be performed.
        use_first_order_differences: boolean, default=True
            If set to True will add the first order differences of each dimension
            to the data.
        n_jobs : int, default=1
            The number of jobs to run in parallel for both `fit` and `predict`.
            ``-1`` means using all processors.
        random_state: int or None, default=None
            Seed for random, integer
    """
    model: MUSE
    model_config: SktimeMuseConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = MUSE(
            anova=self.model_config.anova,
            bigrams=self.model_config.bigrams,
            window_inc=self.model_config.window_inc,
            p_threshold=self.model_config.p_threshold,
            use_first_order_differences=self.model_config.use_first_order_differences,
            n_jobs=self.model_config.n_jobs,
            random_state=self.model_config.random_state,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        scaled_X_fit_nested = from_2d_array_to_nested(scaled_X_fit)
        self.model.fit(scaled_X_fit_nested, y_fit.squeeze().values)

        return self._store_training_state(self.model)
