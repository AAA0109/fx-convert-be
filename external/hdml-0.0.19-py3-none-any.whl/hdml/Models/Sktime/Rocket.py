# https://www.sktime.org/en/v0.8.1/examples/rocket.html
import logging
import os
from pathlib import Path

import pandas as pd
from sktime.classification.kernel_based import RocketClassifier
from sktime.datatypes._panel._convert import from_2d_array_to_nested

from hdml.Models.Sktime.BaseConfig import SktimeClassifierConfig
from hdml.Models.Sktime.BaseModel import SktimeClassifierModel
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SktimeRocketConfig(SktimeClassifierConfig):
    def __init__(
            self,
            model_name: str = "sktime_rocket",
            work_dir: Path = os.getcwd(),
            task: str = "C",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            num_kernels: int = 500,
            rocket_transform: str = "rocket",
            max_dilations_per_kernel: int = 32,
            n_features_per_kernel: int = 4,
            use_multivariate: str = "auto",
            n_jobs: int = 1,
            random_state=None,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.num_kernels = num_kernels
        self.rocket_transform = rocket_transform
        self.max_dilations_per_kernel = max_dilations_per_kernel
        self.n_features_per_kernel = n_features_per_kernel
        self.use_multivariate = use_multivariate
        self.n_jobs = n_jobs
        self.random_state = random_state


class SktimeRocket(SktimeClassifierModel):
    """
    can handle uni/multi-variate, single/multi-steps horizon
    """
    model: RocketClassifier
    model_config: SktimeRocketConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = RocketClassifier(
            num_kernels=self.model_config.num_kernels,
            rocket_transform=self.model_config.rocket_transform,
            max_dilations_per_kernel=self.model_config.max_dilations_per_kernel,
            n_features_per_kernel=self.model_config.n_features_per_kernel,
            use_multivariate=self.model_config.use_multivariate,
            n_jobs=self.model_config.n_jobs,
            random_state=self.model_config.random_state,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        scaled_X_fit_nested = from_2d_array_to_nested(scaled_X_fit)
        self.model.fit(scaled_X_fit_nested, y_fit.squeeze().values)
        return self._store_training_state(self.model)
