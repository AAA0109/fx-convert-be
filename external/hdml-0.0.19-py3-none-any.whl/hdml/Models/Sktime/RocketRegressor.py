# https://www.sktime.org/en/v0.8.1/examples/rocket.html
import logging
import os
from pathlib import Path

import pandas as pd
from sktime.regression.kernel_based import RocketRegressor

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Sktime.BaseConfig import SktimeRegressorConfig
from hdml.Models.Sktime.BaseModel import SktimeRegressorModel
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SktimeRocketRegressorConfig(SktimeRegressorConfig):
    def __init__(
            self,
            model_name: str = "sktime_rocket_regressor",
            work_dir: Path = os.getcwd(),
            task: str = "R",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,

            forecast_horizon: int = 1,
            num_kernels: int = 10000,
            rocket_transform: str = "rocket",
            max_dilations_per_kernel: int = 32,
            n_features_per_kernel: int = 4,
            use_multivariate: str = "auto",
            n_jobs: int = 1,
            random_state=None,
            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.forecast_horizon = forecast_horizon
        self.num_kernels = num_kernels
        self.rocket_transform = rocket_transform
        self.max_dilations_per_kernel = max_dilations_per_kernel
        self.n_features_per_kernel = n_features_per_kernel
        self.use_multivariate = use_multivariate
        self.n_jobs = n_jobs
        self.random_state = random_state


class SktimeRocketRegressor(SktimeRegressorModel):
    """
    can handle uni/multi-variate, single/multi-steps horizon
    """
    model: RocketRegressor
    model_config: SktimeRocketRegressorConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame) -> FitResult:
        self.model = RocketRegressor(
            num_kernels=self.model_config.num_kernels,
            rocket_transform=self.model_config.rocket_transform,
            max_dilations_per_kernel=self.model_config.max_dilations_per_kernel,
            n_features_per_kernel=self.model_config.n_features_per_kernel,
            use_multivariate=self.model_config.use_multivariate,
            n_jobs=self.model_config.n_jobs,
            random_state=self.model_config.random_state,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        self.scaler_y = self._fit_scaler(y_fit)
        scaled_Y_fit = self._scale_data(y_fit, self.scaler_y)

        ts = TimeSeriesTensor(X=scaled_X_fit, y=scaled_Y_fit, lookback=self.model_config.lookback,
                              order_of_3D_array="SFL")

        self.model.fit(ts.X3D, ts.Y3D.iloc[:, 0])
        return self._store_training_state(self.model)
