import logging
import os
from pathlib import Path
from typing import Optional

import pandas as pd
from sktime.classification.kernel_based import Arsenal
from sktime.datatypes._panel._convert import from_2d_array_to_nested

from hdml.Models.Sktime.BaseConfig import SktimeClassifierConfig
from hdml.Models.Sktime.BaseModel import SktimeClassifierModel

logger = logging.getLogger(__name__)


class SktimeArsenalConfig(SktimeClassifierConfig):
    def __init__(
            self,
            model_name: str = "sktime_arsenal",
            work_dir: Path = os.getcwd(),
            task: str = "C",
            input_chunk_length: int = 10,
            output_chunk_length: int = 1,
            n_features: int = None,
            batch_size: int = None,
            epochs: int = 2,
            verbose: int = 1,
            threshold: float = 0.5,

            num_kernels: int = 500,
            n_estimators: int = 25,
            rocket_transform: str = "rocket",
            max_dilations_per_kernel: int = 32,
            n_features_per_kernel: int = 4,
            time_limit_in_minutes: int = 0,
            contract_max_n_estimators: int = 4,
            save_transformed_data: bool = False,
            n_jobs: int = 1,
            random_state: Optional[int] = None,

            *args,
            **kwargs,
    ):
        super().__init__(
            work_dir=work_dir,
            model_name=model_name,
            task=task,
            input_chunk_length=input_chunk_length,
            output_chunk_length=output_chunk_length,
            *args, **kwargs
        )
        self.input_chunk_length = input_chunk_length
        self.output_chunk_length = output_chunk_length
        self.batch_size = batch_size
        self.epochs = epochs
        self.verbose = verbose
        self.n_features = n_features
        self.threshold = threshold

        self.num_kernels = num_kernels
        self.n_estimators = n_estimators
        self.rocket_transform = rocket_transform
        self.max_dilations_per_kernel = max_dilations_per_kernel
        self.n_features_per_kernel = n_features_per_kernel
        self.time_limit_in_minutes = time_limit_in_minutes
        self.contract_max_n_estimators = contract_max_n_estimators
        self.save_transformed_data = save_transformed_data
        self.n_jobs = n_jobs
        self.random_state = random_state


class SktimeArsenal(SktimeClassifierModel):
    """
    can handle uni/multi-variate, single/multi-steps horizon
    """
    model: Arsenal
    model_config: SktimeArsenalConfig

    def fit(self, X_fit: pd.DataFrame, y_fit: pd.DataFrame):
        self.model = Arsenal(
            num_kernels=self.model_config.num_kernels,
            n_estimators=self.model_config.n_estimators,
            rocket_transform=self.model_config.rocket_transform,
            max_dilations_per_kernel=self.model_config.max_dilations_per_kernel,
            n_features_per_kernel=self.model_config.n_features_per_kernel,
            time_limit_in_minutes=self.model_config.time_limit_in_minutes,
            contract_max_n_estimators=self.model_config.contract_max_n_estimators,
            save_transformed_data=self.model_config.save_transformed_data,
            n_jobs=self.model_config.n_jobs,
            random_state=self.model_config.random_state,
        )
        self.scaler_x = self._fit_scaler(X_fit)
        scaled_X_fit = self._scale_data(X_fit, self.scaler_x)

        scaled_X_fit_nested = from_2d_array_to_nested(scaled_X_fit)
        self.model.fit(scaled_X_fit_nested, y_fit.squeeze().values)
        return self._store_training_state(self.model)
