import logging
from abc import ABC
from typing import Optional

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sktime.classification import BaseClassifier
from sktime.datatypes._panel._convert import from_2d_array_to_nested
from sktime.regression.base import BaseRegressor

from hdml.DataProcessing.Timeseries import TimeSeriesTensor
from hdml.Models.Forecaster import Forecaster
from hdml.Models.Sktime.BaseConfig import SktimeClassifierConfig, SktimeRegressorConfig
from hdml.Utils.Result import FitResult

logger = logging.getLogger(__name__)


class SktimeForecaster(Forecaster, ABC):
    scaler_x: Optional[StandardScaler]
    scaler_y: Optional[StandardScaler]

    # ========Private methods================
    def _fit_scaler(
            self,
            data: pd.DataFrame,
    ) -> StandardScaler:
        scaler = StandardScaler()
        scaler.fit(data)
        return scaler

    def _scale_data(self, data: pd.DataFrame, scaler: StandardScaler) -> pd.DataFrame:
        if scaler is None:
            return data
        else:
            return pd.DataFrame(scaler.transform(data), index=data.index, columns=data.columns)

    def _inverse_transform_data(self, data: pd.DataFrame, scaler: StandardScaler) -> pd.DataFrame:
        if scaler is None:
            return data
        else:
            return pd.DataFrame(scaler.inverse_transform(data), index=data.index, columns=data.columns)


class SktimeClassifierModel(SktimeForecaster, ABC):
    model: BaseClassifier
    model_config: SktimeClassifierConfig

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        :param X_test:
        :return:
                forecasts : pandas.DataFrame
                    Index:
                        reference_time (prediction time)
                    Columns:
                        Name: forecast, dtype: pd.DataFrame
                            Index:
                                horizon_time
                            Columns:
                                Name: <forecasted times series>, dtype: float64
                                Name: <forecasted times series 2>, dtype: float64
                                ....
                                Name: <forecasted times series n>, dtype: float64
        """
        try:
            scaled_X_fit = self._scale_data(X_test, self.scaler_x)
            scaled_X_fit_nested = from_2d_array_to_nested(scaled_X_fit)
            forecast_values = self.model.predict_proba(scaled_X_fit_nested)
            forecast_values = pd.DataFrame(forecast_values, index=X_test.index)
            forecasts = {"reference_date": [], "forecast": []}
            for index, row in forecast_values.iterrows():
                datum = row.to_frame().T
                datum.index += pd.tseries.offsets.BDay(1)

                # check if you are trying to forecast "Saturday" or "Sunday"
                if any(elem in set(datum.index.day_name().to_list()) for elem in ["Saturday", "Sunday"]):
                    logger.warning("you are trying to forecast Saturday or Sunday")

                forecasts["reference_date"].append(index)
                forecasts["forecast"].append(datum)
            forecasts = pd.DataFrame(forecasts)
            forecasts.set_index("reference_date", inplace=True)
            forecasts.sort_index(inplace=True)
        except:
            raise RuntimeError("forecast fails!")
        return forecasts

    # ========Private methods================
    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()
        fit_results.fit_instance = fr
        fit_results.criterion = "str(fr.model.criterion)"
        fit_results.best_model_path = "str(fr.trainer.checkpoint_callback.best_model_path)"
        return fit_results


class SktimeRegressorModel(SktimeForecaster, ABC):
    model: BaseRegressor
    model_config: SktimeRegressorConfig

    def forecast(self, X_test: pd.DataFrame) -> pd.DataFrame:
        """
        :param X_test:
        :return:
                forecasts : pandas.DataFrame
                    Index:
                        reference_time (prediction time)
                    Columns:
                        Name: forecast, dtype: pd.DataFrame
                            Index:
                                horizon_time
                            Columns:
                                Name: <forecasted times series>, dtype: float64
                                Name: <forecasted times series 2>, dtype: float64
                                ....
                                Name: <forecasted times series n>, dtype: float64
        """
        try:
            scaled_X_fit = self._scale_data(X_test, self.scaler_x)
            ts = TimeSeriesTensor(X=scaled_X_fit, lookback=self.model_config.lookback, order_of_3D_array="SFL")
            forecast_values = self.model.predict(ts.X3D)
            forecast_values = pd.DataFrame(forecast_values, index=ts.index)
            forecast_values = self._inverse_transform_data(forecast_values, self.scaler_y)

            forecasts = {"reference_date": [], "forecast": []}
            for index, row in forecast_values.iterrows():
                datum = row.to_frame().T
                datum.index += pd.tseries.offsets.BDay(1)

                # check if you are trying to forecast "Saturday" or "Sunday"
                if any(elem in set(datum.index.day_name().to_list()) for elem in ["Saturday", "Sunday"]):
                    logger.warning("you are trying to forecast Saturday or Sunday")

                forecasts["reference_date"].append(index)
                forecasts["forecast"].append(datum)
            forecasts = pd.DataFrame(forecasts)
            forecasts.set_index("reference_date", inplace=True)
            forecasts.sort_index(inplace=True)
        except:
            raise RuntimeError("forecast fails!")
        return forecasts

    # ========Private methods================
    def _store_training_state(self, fr) -> FitResult:
        """
        extract information from training
        :param fr: raw fit result
        :return:
        """
        fit_results = FitResult()
        fit_results.fit_instance = fr
        fit_results.criterion = "str(fr.model.criterion)"
        fit_results.best_model_path = "str(fr.trainer.checkpoint_callback.best_model_path)"
        return fit_results