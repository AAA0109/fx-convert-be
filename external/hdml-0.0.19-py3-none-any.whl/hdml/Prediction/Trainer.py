import uuid
from pathlib import Path
from typing import List, Optional, Dict

import pandas as pd

from hdml.Models.Factory.Model import ModelFactory
from hdml.Models.Forecaster import Forecaster
from hdml.Models.ForecasterConfig import ForecasterConfig
from hdml.Tuning.Factory import TunnerFactory
from hdml.Tuning.HyperTuner import TunedResult
from hdml.Utils.FileSystem import FileSystem
from hdml.Utils.Result import FitResult


class TrainerContainer(object):
    def __init__(self,
                 model: Forecaster,
                 fit_result: FitResult,
                 identifier: Dict[str, str],
                 tunner_result: Optional[TunedResult] = None,
                 ):
        self.model = model
        self.fit_result = fit_result
        self.identifier = identifier
        self.tunner_result = tunner_result


class Trainer(object):
    def __init__(self,
                 input_features: List[str],
                 target_features: List[str],
                 model_config: ForecasterConfig,
                 checkpoint_dir: Path,
                 ):
        """
        Train a model for a given time period
        :param input_features: list of input features
        :param target_features: list of target features
        :param model_config: model config
        :param checkpoint_dir: checkpoint directory
        """
        self._input_features = input_features
        self._target_features = target_features
        self._model_config = model_config
        self._checkpoint_dir = checkpoint_dir

    def run_trainer(self, df: pd.DataFrame) -> TrainerContainer:
        if not all(col in df.columns for col in list(set(self._input_features + self._target_features))):
            raise ValueError("Not all columns exist in the DataFrame")

        X_fit = df[self._input_features]
        y_fit = df[self._target_features]

        # set checkpoint directory and reset ai
        fs = FileSystem(path=self._checkpoint_dir / "checkpoint" / f"{uuid.uuid4()}" / "ai_checkpoint.pkl")
        self._model_config.work_dir = fs.dir_path
        model = ModelFactory(self._model_config).model()

        tunner_result = None
        hyper_tuner = TunnerFactory(model_config=self._model_config).tunner() if self._model_config.tunner_on else None
        if hyper_tuner:
            tunner_result = hyper_tuner.set_model(model=model).tune(X_fit, y_fit)
            model = ModelFactory(tunner_result.optimal_config).model()

        fit_result = model.fit(X_fit, y_fit)

        # remove checkpoint
        fs.delete_dir_path()

        return TrainerContainer(model=model, fit_result=fit_result, identifier={}, tunner_result=tunner_result)
