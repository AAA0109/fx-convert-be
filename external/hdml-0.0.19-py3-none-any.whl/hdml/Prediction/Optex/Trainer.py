import pandas as pd

from hdml.Optex.Algorithms import OptexAlgorithm
from hdml.Optex.ExecutionStrategy import ExecutionStrategy


class TrainerContainer(object):
    def __init__(self, model: ExecutionStrategy):
        self.model = model
        self.name = model.name()


class Trainer(object):
    def __init__(self, model_config: dict):
        """
        Train a model for a given time period
        :param model_config: model config
        """

        self._model_config = model_config

    def run_trainer(self, df: pd.DataFrame) -> TrainerContainer:
        se = OptexAlgorithm.get(self._model_config)
        se.fit_strategy(df=df)
        return TrainerContainer(model=se)
