from typing import List

import pandas as pd

from hdml.Models.Forecaster import Forecaster


class Predictor(object):
    def __init__(self,
                 input_features: List[str],
                 model: Forecaster,
                 ):
        """
        Calcualte predictions for a given model and input features
        :param input_features: list of input features
        :param model: ai model
        """
        self._input_features = input_features
        self._model = model

    def run_predictor(self, df: pd.DataFrame) -> pd.DataFrame:
        if not all(col in df.columns for col in self._input_features):
            raise ValueError("Not all columns exist in the DataFrame")
        X = df[self._input_features]
        lookback = self._model.model_config.lookback
        forecasts = self._model.forecast(X.iloc[-lookback:])
        return forecasts
